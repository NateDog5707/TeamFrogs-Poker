#ifndef COMMUNICATION_WITH_SERVER_H

    #define COMMUNICATION_WITH_SERVER_H

    #define SHUTDOWN_MESSAGE "SHUTDOWN"

    extern char *program_name_gbl;
    extern char server_gbl[50];
    extern char port_num_as_str_gbl[50];

    extern const char *Program ; /* program name for descriptive diagonostics */
    extern int l, n;
    extern int SocketFD, PortNo; /* socket file descriptor and port number */
    extern struct sockaddr_in ServerAddress; /* server address we connect with */
    extern struct hostent *Server; /* server host */
    extern char SendBuf[256]; /* message buffer for sending a message */
    extern char RecvBuf[256]; /* message buffer for receiving a response */
    extern int communication_configuration_values_count;
    extern char *communication_configuration_values[3];

    void set_program_name(char *program_name);
    void set_server(char *server_name);
    void set_port_num(char *port_num_as_str);

    void input_server_and_port_num();

    // initiates one round of sending a message and receiving a message
    void init_communication_session(char *message_to_send);

    void init_communication_session_append_player_to_message(char *message_to_send_without_player);

    void init_communication_session_append_player_then_value_to_message(char *message_to_send_without_player, int value);

    void get_thirteen_cards_from_server();

    void beta_test_case_show_cards();

#endif