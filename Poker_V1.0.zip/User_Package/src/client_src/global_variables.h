#ifndef GLOBAL_VARIABLES_H

    #define GLOBAL_VARIABLES_H

    #include "constants.h"
    #include "card.h"
    #include "list_of_cards.h"
    #include "gtk_widget_structures.h"
    #include "player.h"
    #include "timer.h"
    #include "list_of_players.h"
    #include <gtk/gtk.h>

    // this array supports messages sent up to 6 words
    // pointers to the individual words will occupy indexes in the order that they appear in the message
    extern char **parsed_message_from_server;
    extern t_card *reference_cards[NUM_UNIQUE_CARDS];
    extern char *reference_cards_image_paths[NUM_UNIQUE_CARDS];
    // index 0 is the width, index 1 is the height
    extern int resized_card_dimensions[2];
    extern _Bool connection_successful;
    extern _Bool seat_granted;

    // global variable declarations
    extern GtkWidget *main_window;
    extern GtkWidget *login_window;
    extern GtkWidget *login_window_v_box;
    extern GtkWidget *login_window_image;
    extern GtkWidget *login_window_error_label;
    extern GtkWidget *login_window_server_label;
    extern GtkWidget *login_window_server_combo_box;
    extern GtkWidget *login_window_port_label;
    extern GtkWidget *login_window_port_combo_box;
    extern GtkWidget *login_window_name_label;
    extern GtkWidget *login_window_name_entry;
    extern GtkWidget *login_window_seat_label;
    extern GtkWidget *login_window_seat_entry;
    extern GtkWidget *login_window_submit_button;
    extern GtkWidget *waiting_room_window;
    extern GtkWidget *waiting_room_v_box;
    extern GtkWidget *waiting_room_title;
    extern GtkWidget *waiting_room_image;
    extern GtkWidget *waiting_room_label;
    extern GtkWidget *waiting_room_ready_button;
    extern GtkWidget *waiting_room_start_game_label;
    extern GtkWidget *waiting_room_start_game_button;
    // this will be the top level widget that packs together the actions UI widget and "poker table and seatings" widget
    extern top_level_widget_t *top_level_widget;
    extern poker_table_and_seatings_widget_t *poker_table_and_seatings_widget;
    extern poker_table_widget_t *poker_table_widget;
    extern community_cards_widget_t *community_cards_widget;
    extern t_cardList *community_cards;
    extern actions_UI_widget_t *actions_UI_widget;

    extern GtkWidget *raise_window;
    extern GtkWidget *raise_window_v_box;
    extern GtkWidget *raise_window_label;
    extern GtkWidget *raise_window_hscale;
    extern GtkAdjustment *raise_hscale_adjustment;
    extern GtkWidget *raise_window_button;

    extern GtkWidget *end_game_window;
    extern GtkWidget *end_game_window_v_box;
    extern GtkWidget *end_game_image;

    // 13 card array
    extern int thirteen_card_array_index;
    extern t_card *thirteen_card_array[13];

    // player global variable declarations
    extern player_t *player_1;
    extern player_t *player_2;
    extern player_t *player_3;
    extern player_t *player_4;

    extern player_list_t *player_list;

    extern player_t *current_client_player;

    extern unsigned int current_bet;
    extern unsigned int main_pot;

    extern timer_type *idle_timer;
    // this time limit is in seconds
    extern double idle_timer_limit;
    extern guint idle_handler_id;
    // flag used to stop idle thread
    extern gboolean stop_thread;
    extern _Bool high_frequency_state;

    /*

    extern pocket_cards_widget_t *player_1_pocket_cards_widget;
    extern pocket_cards_widget_t *player_2_pocket_cards_widget;
    extern pocket_cards_widget_t *player_3_pocket_cards_widget;
    extern pocket_cards_widget_t *player_4_pocket_cards_widget;

    */

    extern t_cardList *player_1_pocket_cards;
    extern t_cardList *player_2_pocket_cards;
    extern t_cardList *player_3_pocket_cards;
    extern t_cardList *player_4_pocket_cards;

    extern player_widget_t *player_1_widget;
    extern player_widget_t *player_2_widget;
    extern player_widget_t *player_3_widget;
    extern player_widget_t *player_4_widget;

    // player list global variable definition
    extern player_list_t *player_list;

    // initializes the global reference_cards array with all the poker cards
    void initialize_reference_cards();

#endif