#include "gtk_abstract_functions.h"
#include "constants.h"
#include "global_variables.h"
#include "player.h"
#include "list_of_cards.h"

#include <gtk/gtk.h>
#include <stdbool.h>

GtkWidget *init_table_widget(unsigned int rows, unsigned int columns, gboolean homogeneous)
{
    // have to specify the rows and columns beforehand (# rows and # columns are static)
    GtkWidget *new_table = gtk_table_new(rows, columns, homogeneous);

    // sets the row and column spacings of the widgets (which is pre-defined in the constants module)
    gtk_table_set_col_spacings(GTK_TABLE(new_table), TABLE_COL_SPACING);
    gtk_table_set_row_spacings(GTK_TABLE(new_table), TABLE_ROW_SPACING);

    return new_table;
}

void add_to_one_cell_table_widget(GtkWidget *table, GtkWidget *child_widget, unsigned int row, unsigned int column)
{
    gtk_table_attach_defaults(GTK_TABLE(table), child_widget, column, column + 1, row, row + 1);
}

void show_main_window()
{
    gtk_widget_show_all(main_window);
}

void show_login_window()
{
    gtk_widget_show_all(login_window);
}

void close_login_window()
{
    gtk_widget_hide_all(login_window);
}

void show_waiting_room_window()
{
    gtk_widget_show_all(waiting_room_window);
}

void close_waiting_room_window()
{
    gtk_widget_hide_all(waiting_room_window);
}

void show_raise_window()
{
    gtk_widget_show_all(raise_window);
}

void close_raise_window()
{
    gtk_widget_hide_all(raise_window);
}

void determine_resized_image_dimensions(char *image_path, double resize_percentage)
{
    // getting the original dimensions first
    GdkPixbuf *card_pixbuf_orig = gdk_pixbuf_new_from_file(image_path, NULL);
    int orig_width, orig_height;
    orig_width = gdk_pixbuf_get_width(card_pixbuf_orig);
    orig_height = gdk_pixbuf_get_height(card_pixbuf_orig);
    // acquiring the new dimensions (the original scaled by a percentage)
    int resized_width, resized_height;
    resized_width = (int) ((double) orig_width * resize_percentage);
    resized_height = (int) ((double) orig_height * resize_percentage);

    resized_card_dimensions[0] = resized_width;
    resized_card_dimensions[1] = resized_height;
}

void resize_image(GtkWidget *image, gint new_width, gint new_height) {
    GdkPixbuf *pixbuf = gtk_image_get_pixbuf(GTK_IMAGE(image));
    GdkPixbuf *resized_pixbuf = gdk_pixbuf_scale_simple(pixbuf, new_width, new_height, GDK_INTERP_BILINEAR);
    gtk_image_set_from_pixbuf(GTK_IMAGE(image), resized_pixbuf);
    g_object_unref(resized_pixbuf);
}

void change_bg_color_of_widget(GtkWidget* widget, char *rgb_color)
{
    GdkColor color;
    gdk_color_parse(rgb_color, &color);
    gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void change_fg_color_of_widget(GtkWidget* widget, char *rgb_color)
{
    GdkColor color;
    gdk_color_parse(rgb_color, &color);
    gtk_widget_modify_fg(widget, GTK_STATE_NORMAL, &color);
}

void set_player_cards_facedown(player_number_t player_number)
{
    if(player_number == P1)
    {
        set_cards_in_cardList_facedown(player_1_pocket_cards);
        update_card_images_in_pocket_cards_widget(P1);
    }
    else if(player_number == P2)
    {
        set_cards_in_cardList_facedown(player_2_pocket_cards);
        update_card_images_in_pocket_cards_widget(P2);
    }
    else if(player_number == P3)
    {
        set_cards_in_cardList_facedown(player_3_pocket_cards);
        update_card_images_in_pocket_cards_widget(P3);
    }
    else if(player_number == P4)
    {
        set_cards_in_cardList_facedown(player_4_pocket_cards);
        update_card_images_in_pocket_cards_widget(P4);
    }
}

void set_player_cards_faceup(player_number_t player_number)
{
    if(player_number == P1)
    {
        set_cards_in_cardList_faceup(player_1_pocket_cards);
        update_card_images_in_pocket_cards_widget(P1);
    }
    else if(player_number == P2)
    {
        set_cards_in_cardList_faceup(player_2_pocket_cards);
        update_card_images_in_pocket_cards_widget(P2);
    }
    else if(player_number == P3)
    {
        set_cards_in_cardList_faceup(player_3_pocket_cards);
        update_card_images_in_pocket_cards_widget(P3);
    }
    else if(player_number == P4)
    {
        set_cards_in_cardList_faceup(player_4_pocket_cards);
        update_card_images_in_pocket_cards_widget(P4);
    }
}

void set_all_other_players_cards_facedown()
{
    if(current_client_player == player_1)
    {
        set_player_cards_facedown(P2);
        set_player_cards_facedown(P3);
        set_player_cards_facedown(P4);
    }
    else if(current_client_player == player_2)
    {
        set_player_cards_facedown(P1);
        set_player_cards_facedown(P3);
        set_player_cards_facedown(P4);
    }
    else if(current_client_player == player_3)
    {
        set_player_cards_facedown(P1);
        set_player_cards_facedown(P2);
        set_player_cards_facedown(P4);
    }
    else if(current_client_player == player_4)
    {
        set_player_cards_facedown(P1);
        set_player_cards_facedown(P2);
        set_player_cards_facedown(P3);
    }
}

void set_active_player(player_number_t player_number)
{
    // reset all the label colors to black initially
    change_fg_color_of_widget(player_1_widget->label_name, "black");
    change_fg_color_of_widget(player_2_widget->label_name, "black");
    change_fg_color_of_widget(player_3_widget->label_name, "black");
    change_fg_color_of_widget(player_4_widget->label_name, "black");

    if(player_number == P1)
    {
        change_fg_color_of_widget(player_1_widget->label_name, "blue");
    }
    else if(player_number == P2)
    {
        change_fg_color_of_widget(player_2_widget->label_name, "blue");
    }
    else if(player_number == P3)
    {
        change_fg_color_of_widget(player_3_widget->label_name, "blue");
    }
    else if(player_number == P4)
    {
        change_fg_color_of_widget(player_4_widget->label_name, "blue");
    }
}

void set_initial_sb_bb()
{
    player_1->role = SB;
    player_2->role = BB;
    gtk_label_set_text(GTK_LABEL(player_1_widget->label_sb_bb), "Small Blind");
    gtk_label_set_text(GTK_LABEL(player_2_widget->label_sb_bb), "Big Blind");
}

void set_player_as_SB(player_number_t player_number)
{
    if(player_number == P1)
    {
        player_1->role = SB;
        gtk_label_set_text(GTK_LABEL(player_1_widget->label_sb_bb), "Small Blind");
    }
    else if(player_number == P2)
    {
        player_2->role = SB;
        gtk_label_set_text(GTK_LABEL(player_2_widget->label_sb_bb), "Small Blind");
    }
    else if(player_number == P3)
    {
        player_3->role = SB;
        gtk_label_set_text(GTK_LABEL(player_3_widget->label_sb_bb), "Small Blind");
    }
    else if(player_number == P4)
    {
        player_4->role = SB;
        gtk_label_set_text(GTK_LABEL(player_4_widget->label_sb_bb), "Small Blind");
    }
}

void remove_player_as_SB(player_number_t player_number)
{
    if(player_number == P1)
    {
        player_1->role = GENERIC;
        gtk_label_set_text(GTK_LABEL(player_1_widget->label_sb_bb), "");
    }
    else if(player_number == P2)
    {
        player_2->role = GENERIC;
        gtk_label_set_text(GTK_LABEL(player_2_widget->label_sb_bb), "");
    }
    else if(player_number == P3)
    {
        player_3->role = GENERIC;
        gtk_label_set_text(GTK_LABEL(player_3_widget->label_sb_bb), "");
    }
    else if(player_number == P4)
    {
        player_4->role = GENERIC;
        gtk_label_set_text(GTK_LABEL(player_4_widget->label_sb_bb), "");
    }
}

void set_player_as_BB(player_number_t player_number)
{
    if(player_number == P1)
    {
        player_1->role = BB;
        gtk_label_set_text(GTK_LABEL(player_1_widget->label_sb_bb), "Big Blind");
    }
    else if(player_number == P2)
    {
        player_2->role = BB;
        gtk_label_set_text(GTK_LABEL(player_2_widget->label_sb_bb), "Big Blind");
    }
    else if(player_number == P3)
    {
        player_3->role = BB;
        gtk_label_set_text(GTK_LABEL(player_3_widget->label_sb_bb), "Big Blind");
    }
    else if(player_number == P4)
    {
        player_4->role = BB;
        gtk_label_set_text(GTK_LABEL(player_4_widget->label_sb_bb), "Big Blind");
    }
}

void remove_player_as_BB(player_number_t player_number)
{
    if(player_number == P1)
    {
        player_1->role = GENERIC;
        gtk_label_set_text(GTK_LABEL(player_1_widget->label_sb_bb), "");
    }
    else if(player_number == P2)
    {
        player_2->role = GENERIC;
        gtk_label_set_text(GTK_LABEL(player_2_widget->label_sb_bb), "");
    }
    else if(player_number == P3)
    {
        player_3->role = GENERIC;
        gtk_label_set_text(GTK_LABEL(player_3_widget->label_sb_bb), "");
    }
    else if(player_number == P4)
    {
        player_4->role = GENERIC;
        gtk_label_set_text(GTK_LABEL(player_4_widget->label_sb_bb), "");
    }
}

void shift_sb_bb()
{
    player_list_entry_t *current_player_list_entry = player_list->first;
    _Bool SB_shifted = false;
    _Bool BB_shifted = false;

    while(current_player_list_entry != NULL)
    {
        // BB has to always come first
        if(current_player_list_entry->player->role == BB)
        {
            current_player_list_entry->player->role = GENERIC;
            remove_player_as_BB(current_player_list_entry->player->player_number);
            
            if(current_player_list_entry->next != NULL)
            {
                current_player_list_entry->next->player->role = BB;
                set_player_as_BB(current_player_list_entry->next->player->player_number);
            }
            else if(current_player_list_entry->next == NULL)
            {
                player_list->first->player->role = BB;
                set_player_as_BB(player_list->first->player->player_number);
            }
            
            BB_shifted = true;
        }

        if(BB_shifted)
        {
            break;
        }

        current_player_list_entry = current_player_list_entry->next;
    }

    current_player_list_entry = player_list->first;
    while(current_player_list_entry != NULL)
    {

        if(current_player_list_entry->player->role == SB)
        {
            current_player_list_entry->player->role = GENERIC;
            remove_player_as_SB(current_player_list_entry->player->player_number);
            
            if(current_player_list_entry->next != NULL)
            {
                current_player_list_entry->next->player->role = SB;
                set_player_as_SB(current_player_list_entry->next->player->player_number);
            }
            else if(current_player_list_entry->next == NULL)
            {
                player_list->first->player->role = SB;
                set_player_as_SB(player_list->first->player->player_number);
            }
            
            SB_shifted = true;
        }

        if(SB_shifted)
        {
            break;
        }

        current_player_list_entry = current_player_list_entry->next;
    }
}