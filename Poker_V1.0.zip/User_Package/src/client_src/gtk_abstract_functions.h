/* gtk_abstract_functions.h */

#ifndef GTK_ABSTRACT_FUNCTIONS_H

    #define GTK_ABSTRACT_FUNCTIONS_H

    #include <gtk/gtk.h>
    #include "player.h"

    void add_child_widget_to_container(GtkWidget *container, GtkWidget *child);

    void widget_change_bg_color(GtkWidget* widget, const char *color_str);

    GtkWidget *init_table_widget(unsigned int rows, unsigned int columns, gboolean homogeneous);

    void add_to_one_cell_table_widget(GtkWidget *table, GtkWidget *child_widget, unsigned int row, unsigned int column);

    void show_main_window();

    void show_login_window();

    void close_login_window();

    void show_waiting_room_window();

    void close_waiting_room_window();

    void show_raise_window();

    void close_raise_window();

    void determine_resized_image_dimensions(char *image_path, double resize_percentage);

    void resize_image(GtkWidget *image, gint new_width, gint new_height);

    void change_bg_color_of_widget(GtkWidget* widget, char *rgb_color);

    void change_fg_color_of_widget(GtkWidget* widget, char *rgb_color);

    void set_player_cards_facedown(player_number_t player_number);

    void set_player_cards_faceup(player_number_t player_number);

    // relies on a player being pointed to by the current_client_player global variable
    void set_all_other_players_cards_facedown();

    void set_active_player(player_number_t player_number);

    void set_initial_sb_bb();

    void shift_sb_bb();

    void set_player_as_SB(player_number_t player_number);

    void remove_player_as_SB(player_number_t player_number);

    void set_player_as_BB(player_number_t player_number);

    void remove_player_as_BB(player_number_t player_number);

#endif