#include "list_of_cards.h"
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

t_cardList_entry *init_cardList_entry(t_cardList *cardList, t_card *card);
void delete_cardList_entry(t_cardList_entry *cardList_entry);

t_cardList *init_cardList()
{
    t_cardList *new_cardList = malloc(sizeof(t_cardList));
	new_cardList->first = NULL;
	new_cardList->last = NULL;
	new_cardList->length = 0;

	return new_cardList;
}

void delete_cardList(t_cardList *cardList)
{
    if(cardList == NULL)
    {
        printf("Warning: cardList pointer value is NULL");
    }
    else
    {
        while(cardList->length > 0)
        {
            pop_from_cardList(cardList);
        }
    }

    free(cardList);
}

t_cardList_entry *init_cardList_entry(t_cardList *cardList, t_card *card)
{
	t_cardList_entry *new_cardList_entry = NULL;
    new_cardList_entry = malloc(sizeof(t_cardList_entry));
	new_cardList_entry->prev = NULL;
	new_cardList_entry->next = NULL;
	new_cardList_entry->card = card;
    new_cardList_entry->card_list = cardList;
  
  return new_cardList_entry;
}

void delete_cardList_entry(t_cardList_entry *cardList_entry)
{
    if(cardList_entry == NULL)
    {
        printf("Warning: cardList_entry pointer value is NULL");
    }
    else
    {
        delete_card(cardList_entry->card);
    }
    free(cardList_entry);
}

void push_to_cardList(t_cardList *cardList, t_card *card)
{
    assert(cardList != NULL);
    assert(card != NULL);

    t_cardList_entry *new_cardList_entry = init_cardList_entry(cardList, card);

    if(cardList->length == 0)
    {
        cardList->first = new_cardList_entry;
        cardList->last = new_cardList_entry;
    }
    else if(cardList->length > 0)
    {
        t_cardList_entry *current_last_entry = cardList->last;
        assert(current_last_entry != NULL);
        current_last_entry->next = new_cardList_entry;
        new_cardList_entry->prev = current_last_entry;
        cardList->last = new_cardList_entry;
    }

    cardList->length++;
}

void pop_from_cardList(t_cardList *cardList)
{
    assert(cardList != NULL);
    if(cardList->length == 0)
    {
        printf("The card list is empty. Nothing to pop");
    }
    else
    {
        t_cardList_entry *current_last_entry = cardList->last;
        
        if(cardList->length == 1)
        {
            delete_cardList_entry(current_last_entry);
            cardList->first = NULL;
            cardList->last = NULL;
        }
        else if(cardList->length > 1)
        {
            current_last_entry->prev->next = NULL;
            cardList->last = current_last_entry->prev;

            delete_cardList_entry(current_last_entry);
        }

        cardList->length--;
    }
}

void flip_cards_in_cardList(t_cardList *cardList)
{
    t_cardList_entry *current_cardList_entry = cardList->first;

    while(current_cardList_entry != NULL)
    {
        flip_card(current_cardList_entry->card);

        current_cardList_entry = current_cardList_entry->next;
    }
}

void set_cards_in_cardList_facedown(t_cardList *cardList)
{
    t_cardList_entry *current_cardList_entry = cardList->first;

    while(current_cardList_entry != NULL)
    {
        current_cardList_entry->card->is_faced_up = false;

        current_cardList_entry = current_cardList_entry->next;
    }
}

void set_cards_in_cardList_faceup(t_cardList *cardList)
{
    t_cardList_entry *current_cardList_entry = cardList->first;

    while(current_cardList_entry != NULL)
    {
        current_cardList_entry->card->is_faced_up = true;

        current_cardList_entry = current_cardList_entry->next;
    }
}