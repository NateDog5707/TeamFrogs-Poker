#include "list_of_players.h"
#include "player.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

player_list_entry_t *init_player_list_entry(player_list_t *player_list, player_t *player);

void delete_player_list_entry(player_list_entry_t *player_list_entry);

player_list_t *init_player_list()
{
    player_list_t *new_player_list = malloc(sizeof(player_list_t));
    new_player_list->length = 0;
    new_player_list->first = NULL;
    new_player_list->last = NULL;

    return new_player_list;
}

void empty_player_list(player_list_t *player_list)
{
    if(player_list == NULL)
    {
        printf("Warning: player list pointer value is NULL");
    }
    else
    {
        while(player_list->length > 0)
        {
            pop_from_player_list(player_list);
        }
    }
}

void delete_player_list(player_list_t *player_list)
{
    if(player_list == NULL)
    {
        printf("Warning: player list pointer value is NULL");
    }
    else
    {
        while(player_list->length > 0)
        {
            pop_from_player_list(player_list);
        }
    }

    free(player_list);
}

void push_to_player_list(player_list_t *player_list, player_t *player)
{
    assert(player_list != NULL);
    assert(player != NULL);

    player_list_entry_t *new_player_list_entry = init_player_list_entry(player_list, player);

    if(player_list->length == 0)
    {
        player_list->first = new_player_list_entry;
        player_list->last = new_player_list_entry;
    }
    else if(player_list->length > 0)
    {
        player_list_entry_t *current_last_entry = player_list->last;
        assert(current_last_entry != NULL);
        current_last_entry->next = new_player_list_entry;
        new_player_list_entry->prev = current_last_entry;
        player_list->last = new_player_list_entry;
    }

    player_list->length++;
}

void pop_from_player_list(player_list_t *player_list)
{
    assert(player_list != NULL);
    if(player_list->length == 0)
    {
        printf("The player list is empty. Nothing to pop");
    }
    else
    {
        player_list_entry_t *current_last_entry = player_list->last;

        if(player_list->length == 1)
        {
            delete_player_list_entry(current_last_entry);
            player_list->first = NULL;
            player_list->last = NULL;
        }
        else if(player_list->length > 1)
        {
            current_last_entry->prev->next = NULL;
            player_list->last = current_last_entry->prev;

            delete_player_list_entry(current_last_entry);
        }

        player_list->length--;
    }
}

player_list_entry_t *init_player_list_entry(player_list_t *player_list, player_t *player)
{
    assert(player_list != NULL);
    assert(player != NULL);

    player_list_entry_t *new_player_list_entry = malloc(sizeof(player_list_entry_t));
    new_player_list_entry->player_list = player_list;
    new_player_list_entry->player = player;
    new_player_list_entry->next = NULL;
    new_player_list_entry->prev = NULL;

    return new_player_list_entry;
}

void delete_player_list_entry(player_list_entry_t *player_list_entry)
{
    if(player_list_entry == NULL)
    {
        printf("Warning: player_list_entry pointer value is NULL");
    }
    else
    {
        delete_player(player_list_entry->player);
    }

    free(player_list_entry);
}