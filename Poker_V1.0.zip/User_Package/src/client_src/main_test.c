#include "constants.h"
#include "timer.h"
#include "gtk_abstract_functions.h"
#include "gtk_widget_structures.h"
#include "list_of_cards.h"
#include "card.h"
#include "player.h"
#include "global_variables.h"
#include "list_of_players.h"
#include "communication_with_server.h"
#include "message_process.h"
#include "parse.h"

#include <gtk/gtk.h>
#include <time.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#define TEST_CARDS_ARRAY_SIZE 5
#define CONNECT_TO_SERVER
// #define SHOW_ALL_WINDOWS

/***************************************************************/
// Function declarations for the functions defined at the end of this file
void test_distribute_cards();

gboolean idle_thread_function(gpointer data);

void test_frequency_state_with_counter(int counter_limit);

/***************************************************************/

/***************************************************************/
// Callback function definitions

static void end_gtk_program(GtkWidget *widget, gpointer data)
{
    gtk_main_quit();
}

static void destroy_argument_widget(GtkWidget *widget, gpointer data)
{
    gtk_widget_destroy(GTK_WIDGET(data));
}

static void login_submit_button_callback(GtkWidget *widget, gpointer data)
{
    gtk_label_set_text(GTK_LABEL(login_window_error_label), "");
    _Bool login_window_name_input_valid = false;
    _Bool login_window_seat_input_valid = false;
    _Bool login_window_server_selected = false;
    _Bool login_window_port_selected = false;

    #ifdef CONNECT_TO_SERVER

        // Testing connection first
        
        const gchar *server_combo_box_selected_item = gtk_combo_box_get_active_text(GTK_COMBO_BOX(login_window_server_combo_box));
        if(server_combo_box_selected_item == NULL) // if no item is selected, will return null
        {
            gtk_label_set_text(GTK_LABEL(login_window_error_label), "Server is not selected");
            return;
        }
        else
        {
            login_window_server_selected = true;
        }

        const gchar *port_combo_box_selected_item = gtk_combo_box_get_active_text(GTK_COMBO_BOX(login_window_port_combo_box));
        if(port_combo_box_selected_item == NULL) // if no item is selected, will return null
        {
            gtk_label_set_text(GTK_LABEL(login_window_error_label), "Port is not selected");
            return;
        }
        else
        {
            login_window_port_selected = true;
        }

        if(login_window_server_selected && login_window_port_selected)
        {
            program_name_gbl = "Poker Program";
            set_program_name(program_name_gbl);
            strcpy(server_gbl, server_combo_box_selected_item);
            strcpy(port_num_as_str_gbl, port_combo_box_selected_item);
            
            set_program_name(program_name_gbl);
            set_server(server_gbl);
            set_port_num(port_num_as_str_gbl);

            RecvBuf[0] = '\0';

            init_communication_session("TEST");
            if(RecvBuf[0] != '\0')
            {
                execute_server_message();
            }
            
            if(connection_successful != true)
            {
                gtk_label_set_text(GTK_LABEL(login_window_error_label), "Could not establish connection with server");
            }
        }

    #endif

    #ifndef CONNECT_TO_SERVER
        // just set it equal to true for testing purposes
        connection_successful = true;
    #endif

    if(connection_successful == true)
    {

        const gchar *login_window_name_input = gtk_entry_get_text(GTK_ENTRY(login_window_name_entry));
        guint16 login_window_name_input_length = gtk_entry_get_text_length(GTK_ENTRY(login_window_name_entry));
        const gchar *login_window_seat_input = gtk_entry_get_text(GTK_ENTRY(login_window_seat_entry));
        
        char request_seat_message_to_send[50];
        strcpy(request_seat_message_to_send, "REQUEST SEAT ");

        if(strcmp(login_window_seat_input, "S1") == 0)
        {
            login_window_seat_input_valid = true;
            strcat(request_seat_message_to_send, "1 ");
            // current_client_player = player_1;
            // set_all_other_players_cards_facedown();
        }
        else if(strcmp(login_window_seat_input, "S2") == 0)
        {
            login_window_seat_input_valid = true;
            strcat(request_seat_message_to_send, "2 ");
            // current_client_player = player_2;
            // set_all_other_players_cards_facedown();
        }
        else if(strcmp(login_window_seat_input, "S3") == 0)
        {
            login_window_seat_input_valid = true;
            strcat(request_seat_message_to_send, "3 ");
            // current_client_player = player_3;
            // set_all_other_players_cards_facedown();
        }
        else if(strcmp(login_window_seat_input, "S4") == 0)
        {
            login_window_seat_input_valid = true;
            strcat(request_seat_message_to_send, "4 ");
            // current_client_player = player_4;
            // set_all_other_players_cards_facedown();
        }

        if(login_window_name_input_length != 0)
        {
            login_window_name_input_valid = true;
            strcat(request_seat_message_to_send, login_window_name_input);
        }

        if(login_window_name_input_valid && login_window_seat_input_valid)
        {
            g_print("Both inputs are valid. Sending message to server");
            init_communication_session(request_seat_message_to_send);
            execute_server_message();
        }
        else
        {
            gtk_label_set_text(GTK_LABEL(login_window_error_label), "Name and/or Seat Invalid");
        }

        if(seat_granted == true)
        {
            // this if block is to assign the correct player to current_client_player
            // does not set all the other player's cards facedown yet
            if(strcmp(login_window_seat_input, "S1") == 0)
            {
                current_client_player = player_1;
            }
            else if(strcmp(login_window_seat_input, "S2") == 0)
            {
                current_client_player = player_2;
            }
            else if(strcmp(login_window_seat_input, "S3") == 0)
            {
                current_client_player = player_3;
            }
            else if(strcmp(login_window_seat_input, "S4") == 0)
            {
                current_client_player = player_4;
            }

            close_login_window();
            show_waiting_room_window();
        }
        else
        {
            gtk_label_set_text(GTK_LABEL(login_window_error_label), "Seat unavailable, please try again.");
        }
    }
}

static void waiting_room_button_callback(GtkWidget *widget, gpointer data)
{
    change_bg_color_of_widget(waiting_room_ready_button, "green");

    #ifdef CONNECT_TO_SERVER

        char message_to_send[50];
        strcpy(message_to_send, "READYUP ");

        if(current_client_player->player_number == P1)
        {
            strcat(message_to_send, "1");
        }
        else if(current_client_player->player_number == P2)
        {
            strcat(message_to_send, "2");
        }
        else if(current_client_player->player_number == P3)
        {
            strcat(message_to_send, "3");
        }
        else if(current_client_player->player_number == P4)
        {
            strcat(message_to_send, "4");
        }

        init_communication_session(message_to_send);
        execute_server_message();

    #endif

    // normally we would get a message from the server that says the game has begun
    // which triggers the closing of the waiting room window and the showing of the main game window
    // but, for testing, we will just automatically go to the main window screen
    // close_waiting_room_window();
    // the idle thread will be created after the player presses the ready up button
    // idle_handler_id = gtk_idle_add(idle_thread_function, NULL);
    // show_main_window();
    
}

static void waiting_room_start_game_button_callback(GtkWidget *widget, gpointer data)
{
    #ifdef CONNECT_TO_SERVER
        // init_communication_session_append_player_to_message("START GAME");
        init_communication_session("STARTGAME");
        execute_server_message();
    #endif


}

static void call_button_callback(GtkWidget *widget, gpointer data)
{
    #ifdef CONNECT_TO_SERVER
        init_communication_session_append_player_to_message("ACTION CALL");
    #endif
    #ifndef CONNECT_TO_SERVER
        printf("Placehold print message since not connecting to server");
    #endif
}

static void fold_button_callback(GtkWidget *widget, gpointer data)
{
    #ifdef CONNECT_TO_SERVER
        init_communication_session_append_player_to_message("ACTION FOLD");
    #endif
    #ifndef CONNECT_TO_SERVER
        printf("Placehold print message since not connecting to server");
    #endif
}

static void main_window_raise_button_callback(GtkWidget *widget, gpointer data)
{
    // update the scale range
    printf("%p\n", raise_hscale_adjustment);
    gtk_adjustment_set_lower(raise_hscale_adjustment, 0);
    gtk_adjustment_set_upper(raise_hscale_adjustment, current_client_player->balance);
    //gtk_adjustment_configure(raise_hscale_adjustment, -50.0, 0.0, 150.0, 1.0, 10.0, 0.0);

    show_raise_window();
}

static void check_button_callback(GtkWidget *widget, gpointer data)
{
    #ifdef CONNECT_TO_SERVER
        init_communication_session_append_player_to_message("ACTION CHECK");
    #endif
    #ifndef CONNECT_TO_SERVER
        printf("Placehold print message since not connecting to server");
    #endif
}

void raise_window_button_callback(GtkWidget *widget, gpointer data)
{
    #ifdef CONNECT_TO_SERVER
        GtkRange *range = GTK_RANGE(raise_window_hscale);
        int value = (gint) gtk_range_get_value(range);
        init_communication_session_append_player_then_value_to_message("ACTION RAISE", value);
    #endif

    close_raise_window();
}


gboolean idle_thread_function(gpointer data)
{
    static _Bool timer_is_initialized = false;

    if(timer_is_initialized == false)
    {
        idle_timer = init_timer(idle_timer_limit);
        timer_is_initialized = true;
    }

    if(timer_is_finished(idle_timer) == true)
    {
        // perform the function when the timer is up
        if(high_frequency_state == true)
        {
            printf("High frequency state is on\n");
        }
        else if(high_frequency_state == false)
        {
            printf("High frequency state is off\n");
        }

        // test_frequency_state_with_counter(5);

        #ifdef CONNECT_TO_SERVER

            char message_to_send[50];
            strcpy(message_to_send, "UPDATE");

            // if(current_client_player->player_number == P1)
            // {
            //     strcat(message_to_send, " 1");
            // }
            // else if(current_client_player->player_number == P2)
            // {
            //     strcat(message_to_send, " 2");
            // }
            // else if(current_client_player->player_number == P3)
            // {
            //     strcat(message_to_send, " 3");
            // }
            // else if(current_client_player->player_number == P4)
            // {
            //     strcat(message_to_send, " 4");
            // }

            init_communication_session_append_player_to_message(message_to_send);
            execute_server_message();

        #endif

        reset_timer(idle_timer);
    }
    else if(timer_is_finished(idle_timer) == false)
    {
        // updates the timer
        update_timer(idle_timer);
    }

    if(stop_thread == TRUE)
    {
        // will terminate the idle thread
        return FALSE;
    }
    else
    {
        // will cotinue the idle thread
        return TRUE;
    }
}

int main(int argc, char *argv[])
{   
    /***************************************************************/
    // Don't modify this
    // This is some GTK setup stuff
    gtk_init(&argc, &argv);

    // This has to be done because not done during compiler time
    initialize_reference_cards();
    /***************************************************************/
    // Initial program setup (setting up the main window widget)

    // initialize actions UI widget
    actions_UI_widget = init_actions_UI_widget();

    // initialize community cards doubly linked list
    community_cards = init_cardList();
    // after the community_cards list is initialized, initialize the community cards widget
    community_cards_widget = init_community_cards_widget(community_cards);
    // the card images in the community cards widget have to be updated using a separate function
    update_card_images_in_community_cards_widget();

    // initialize the player pocket cards doubly linked list
    player_1_pocket_cards = init_cardList();
    player_2_pocket_cards = init_cardList();
    player_3_pocket_cards = init_cardList();
    player_4_pocket_cards = init_cardList();
    // initialize the player objects
    player_1 = init_player("Empty", 1000, player_1_pocket_cards, P1);
    player_2 = init_player("Empty", 1000, player_2_pocket_cards, P2);
    player_3 = init_player("Empty", 1000, player_3_pocket_cards, P3);
    player_4 = init_player("Empty", 1000, player_4_pocket_cards, P4);

    player_list = init_player_list();
    push_to_player_list(player_list, player_1);
    push_to_player_list(player_list, player_2);
    push_to_player_list(player_list, player_3);
    push_to_player_list(player_list, player_4);

    // initialize the player widgets
    // NOTE: this will initialize the pocket cards widget but will have placeholder cards so have to use the corresponding function to update the widgets
    init_player_widget(player_1);
    init_player_widget(player_2);
    init_player_widget(player_3);
    init_player_widget(player_4);

    // this will update the pocket cards widget, but there won't be any cards at this point because the pocket cards doubly linked lists are empty at this point
    update_card_images_in_pocket_cards_widget(P1);
    update_card_images_in_pocket_cards_widget(P2);
    update_card_images_in_pocket_cards_widget(P3);
    update_card_images_in_pocket_cards_widget(P4);

    // after the community_cards_widget is initialized, initialize the poker table widget (which the community cards widget is a part of)
    poker_table_widget = init_poker_table_widget();

    // initialize poker table and seatings
    init_poker_table_and_seatings_widget();

    // initialize the window object
    main_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(main_window), MAIN_WINDOW_WIDTH, MAIN_WINDOW_HEIGHT);

    init_top_level_widget();

    // pack the top level widget to the window
    gtk_container_add(GTK_CONTAINER(main_window), top_level_widget->overall_v_box_widget);
    
    // modify background color of main window
    GdkColor color;
    gdk_color_parse("#A2BC89", &color);
    gtk_widget_modify_bg(main_window, GTK_STATE_NORMAL, &color);


    #ifdef SHOW_ALL_WINDOWS
        show_main_window();
    #endif

    /***************************************************************/
    // Initial program setup (setting up the login window widget)

    login_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

    login_window_v_box = gtk_vbox_new(FALSE, 10);
    login_window_image = gtk_image_new_from_file(CARD_BACK_PATH);
    login_window_error_label = gtk_label_new("");
    change_fg_color_of_widget(login_window_error_label, "red");
    login_window_server_label = gtk_label_new("Choose server: ");

    login_window_server_combo_box = gtk_combo_box_new_text();
    gtk_combo_box_append_text(GTK_COMBO_BOX(login_window_server_combo_box), "laguna");
    gtk_combo_box_append_text(GTK_COMBO_BOX(login_window_server_combo_box), "bondi");

    login_window_port_label = gtk_label_new("Choose port number: ");

    login_window_port_combo_box = gtk_combo_box_new_text();
    gtk_combo_box_append_text(GTK_COMBO_BOX(login_window_port_combo_box), "10180");
    gtk_combo_box_append_text(GTK_COMBO_BOX(login_window_port_combo_box), "10181");
    gtk_combo_box_append_text(GTK_COMBO_BOX(login_window_port_combo_box), "10182");
    gtk_combo_box_append_text(GTK_COMBO_BOX(login_window_port_combo_box), "10183");
    gtk_combo_box_append_text(GTK_COMBO_BOX(login_window_port_combo_box), "10184");
    gtk_combo_box_append_text(GTK_COMBO_BOX(login_window_port_combo_box), "10185");
    gtk_combo_box_append_text(GTK_COMBO_BOX(login_window_port_combo_box), "10186");
    gtk_combo_box_append_text(GTK_COMBO_BOX(login_window_port_combo_box), "10187");
    gtk_combo_box_append_text(GTK_COMBO_BOX(login_window_port_combo_box), "10188");
    gtk_combo_box_append_text(GTK_COMBO_BOX(login_window_port_combo_box), "10189");

    login_window_name_label = gtk_label_new("Choose your name for the game: ");
    login_window_name_entry = gtk_entry_new();
    login_window_seat_label = gtk_label_new("Choose the seat you want to occupy (S1, S2, S3, or S4): ");
    login_window_seat_entry = gtk_entry_new();
    login_window_submit_button = gtk_button_new_with_label("Submit");

    gtk_container_add(GTK_CONTAINER(login_window_v_box), login_window_image);
    gtk_container_add(GTK_CONTAINER(login_window_v_box), login_window_error_label);
    gtk_container_add(GTK_CONTAINER(login_window_v_box), login_window_server_label);
    gtk_container_add(GTK_CONTAINER(login_window_v_box), login_window_server_combo_box);
    gtk_container_add(GTK_CONTAINER(login_window_v_box), login_window_port_label);
    gtk_container_add(GTK_CONTAINER(login_window_v_box), login_window_port_combo_box);
    gtk_container_add(GTK_CONTAINER(login_window_v_box), login_window_name_label);
    gtk_container_add(GTK_CONTAINER(login_window_v_box), login_window_name_entry);
    gtk_container_add(GTK_CONTAINER(login_window_v_box), login_window_seat_label);
    gtk_container_add(GTK_CONTAINER(login_window_v_box), login_window_seat_entry);
    gtk_container_add(GTK_CONTAINER(login_window_v_box), login_window_submit_button);

    gtk_container_add(GTK_CONTAINER(login_window), login_window_v_box);

    
    show_login_window();

    #ifdef SHOW_ALL_WINDOWS
        show_login_window();
    #endif

    /***************************************************************/
    // Initial program setup (setting up the waiting room window widget)

    waiting_room_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

    waiting_room_v_box = gtk_vbox_new(FALSE, 5);
    waiting_room_title = gtk_label_new("Waiting Room: ");
    //waiting_room_image = gtk_image_new_from_file(CARD_BACK_PATH);
    waiting_room_image = gtk_image_new_from_file(WAITING_SCREEN_IMAGE_PATH);
    waiting_room_label = gtk_label_new("When all connected players ready up, the game will start.\nUnfilled seats will become occupied by bots");
    waiting_room_ready_button = gtk_button_new_with_label("Ready Up");
    waiting_room_start_game_label = gtk_label_new("You can only start the game after everyone has pressed the ready up button.");
    waiting_room_start_game_button = gtk_button_new_with_label("Start Game");

    gtk_container_add(GTK_CONTAINER(waiting_room_v_box), waiting_room_title);
    gtk_container_add(GTK_CONTAINER(waiting_room_v_box), waiting_room_image);
    gtk_container_add(GTK_CONTAINER(waiting_room_v_box), waiting_room_label);
    gtk_container_add(GTK_CONTAINER(waiting_room_v_box), waiting_room_ready_button);
    gtk_container_add(GTK_CONTAINER(waiting_room_v_box), waiting_room_start_game_label);
    gtk_container_add(GTK_CONTAINER(waiting_room_v_box), waiting_room_start_game_button);

    gtk_container_add(GTK_CONTAINER(waiting_room_window), waiting_room_v_box);

    #ifdef SHOW_ALL_WINDOWS
        gtk_widget_show_all(waiting_room_window);
    #endif

    /***************************************************************/
    // Initial program setup (setting up the raise window widget)

    raise_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    raise_window_v_box = gtk_vbox_new(FALSE, 5);
    raise_window_label = gtk_label_new("Please choose the amount you want to raise to: ");
    
    raise_hscale_adjustment = GTK_ADJUSTMENT(gtk_adjustment_new(0.0, 0.0, 100.0, 1.0, 10.0, 0.0));
    raise_window_hscale = gtk_hscale_new(raise_hscale_adjustment);
    gtk_scale_set_digits(GTK_SCALE(raise_window_hscale), 0);
    // gtk_range_set_value(GTK_RANGE(raise_window_hscale), 0.0);  
    // gtk_scale_set_digits(GTK_SCALE(raise_window_hscale), 0);    
    // gtk_scale_set_draw_value(GTK_SCALE(raise_window_hscale), TRUE); 
    
    raise_window_button = gtk_button_new_with_label("Submit");

    gtk_container_add(GTK_CONTAINER(raise_window_v_box), raise_window_label);
    gtk_container_add(GTK_CONTAINER(raise_window_v_box), raise_window_hscale);
    gtk_container_add(GTK_CONTAINER(raise_window_v_box), raise_window_button);
    gtk_container_add(GTK_CONTAINER(raise_window), raise_window_v_box);

    #ifdef SHOW_ALL_WINDOWS
        gtk_widget_show_all(raise_window);
    #endif

    /***************************************************************/
    // Initial program setup (setting up the end game window widget)

    end_game_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    end_game_window_v_box = gtk_vbox_new(FALSE, 5);
    end_game_image = gtk_image_new_from_file(CARD_BACK_PATH);

    gtk_container_add(GTK_CONTAINER(end_game_window_v_box), end_game_image);
    gtk_container_add(GTK_CONTAINER(end_game_window), end_game_window_v_box);

    #ifdef SHOW_ALL_WINDOWS
        gtk_widget_show_all(end_game_window);
    #endif
     /***************************************************************/
    // Testing
    // this is for the connection between the client and server

    // input_server_and_port_num();

    // set_program_name(program_name_gbl);
    // set_server(server_gbl);
    // set_port_num(port_num_as_str_gbl);

    // init_communication_session("SHUTDOWN");

    /***************************************************************/

    // Player and Player List Testing

    {

        // // initializing first test player
        // char *test_player_1_name = "Harold";
        // t_card *test_card_1 = init_card(JACK, CLUBS);
        // t_card *test_card_2 = init_card(QUEEN, CLUBS);
        // t_cardList *test_pocket_cards_1 = init_cardList();
        // push_to_cardList(test_pocket_cards_1, test_card_1);
        // push_to_cardList(test_pocket_cards_1, test_card_2);

        // player_t *test_player_1 = init_player(test_player_1_name, 100, test_pocket_cards_1 ,P1);

        // // initializing second test player
        // char *test_player_2_name = "John";
        // t_card *test_card_3 = init_card(KING, CLUBS);
        // t_card *test_card_4 = init_card(SEVEN, CLUBS);
        // t_cardList *test_pocket_cards_2 = init_cardList();
        // push_to_cardList(test_pocket_cards_2, test_card_3);
        // push_to_cardList(test_pocket_cards_2, test_card_4);

        // player_t *test_player_2 = init_player(test_player_2_name, 500, test_pocket_cards_2, P2);

        // // adding test players to player list
        // player_list_t *test_player_list = init_player_list();
        // push_to_player_list(test_player_list, test_player_1);
        // push_to_player_list(test_player_list, test_player_2);

        // return 0;

    }

    /***************************************************************/

    // Main GUI Testing
    {
        // testing community flop, turn, and river functions
        // as well as the dealing of pocket cards

        // thirteen_card_array[0] = init_card(ACE, CLUBS);
        // thirteen_card_array[1] = init_card(TWO, CLUBS);
        // thirteen_card_array[2] = init_card(THREE, CLUBS);
        // thirteen_card_array[3] = init_card(FOUR, CLUBS);
        // thirteen_card_array[4] = init_card(FIVE, CLUBS);
        // thirteen_card_array[5] = init_card(SIX, CLUBS);
        // thirteen_card_array[6] = init_card(SEVEN, CLUBS);
        // thirteen_card_array[7] = init_card(EIGHT, CLUBS);
        // thirteen_card_array[8] = init_card(NINE, CLUBS);
        // thirteen_card_array[9] = init_card(TEN, CLUBS);
        // thirteen_card_array[10] = init_card(JACK, CLUBS);
        // thirteen_card_array[11] = init_card(QUEEN, CLUBS);
        // thirteen_card_array[12] = init_card(KING, CLUBS);
        
        // community_flop();
        // community_turn();
        // community_river();

        // deal_pocket();

        // t_card arrays in which the cards will be pushed to the community cards doubly linked list
        // t_card *test_cards_array_pocket[2] = {init_card(QUEEN, CLUBS), init_card(QUEEN, CLUBS)};

        // t_card *test_cards_array_community[TEST_CARDS_ARRAY_SIZE] = {init_card(JACK, CLUBS), init_card(QUEEN, CLUBS), init_card(KING, CLUBS), init_card(ACE, CLUBS), init_card(SEVEN, CLUBS)};

        // for (int i = 0; i < TEST_CARDS_ARRAY_SIZE; i++)
        // {
        //     push_to_cardList(community_cards, test_cards_array_community[i]);
        // }

        // update_card_images_in_community_cards_widget();

        // for (int i = 0; i < 2; i++)
        // {
        //     push_to_cardList(player_1_pocket_cards, test_cards_array_pocket[i]);
        //     push_to_cardList(player_2_pocket_cards, test_cards_array_pocket[i]);
        //     push_to_cardList(player_3_pocket_cards, test_cards_array_pocket[i]);
        //     push_to_cardList(player_4_pocket_cards, test_cards_array_pocket[i]);
        // }

        // update_card_images_in_pocket_cards_widget(P1);
        // update_card_images_in_pocket_cards_widget(P2);
        // update_card_images_in_pocket_cards_widget(P3);
        // update_card_images_in_pocket_cards_widget(P4);
    }

    // update_player_pot(player_1_widget, 200);
    // update_player_pot(player_2_widget, 200);
    // update_player_pot(player_3_widget, 200);
    // update_player_pot(player_4_widget, 200);
    // update_main_pot(500);

    // action_fold(1);
    // action_call(2);
    // action_raise(3, 100);
    // action_check(4);

    /***************************************************************/
    // Don't modify this
    // Creation of gui events

    // FOR THE LOGIN WINDOW:
    g_signal_connect(login_window, "destroy", G_CALLBACK(end_gtk_program), NULL);
    g_signal_connect(login_window_submit_button, "clicked", G_CALLBACK(login_submit_button_callback), NULL);

    // FOR THE WAITING ROOM WINDOW:
    g_signal_connect(waiting_room_ready_button, "clicked", G_CALLBACK(waiting_room_button_callback), NULL);
    g_signal_connect(waiting_room_start_game_button, "clicked", G_CALLBACK(waiting_room_start_game_button_callback), NULL);

    // FOR THE MAIN WINDOW:
    // event to terminate the running gtk program
    g_signal_connect(main_window, "destroy", G_CALLBACK(end_gtk_program), NULL);
    
    g_signal_connect(top_level_widget->actions_UI_widget->button_call, "clicked", G_CALLBACK(call_button_callback), NULL);
    g_signal_connect(top_level_widget->actions_UI_widget->button_raise, "clicked", G_CALLBACK(main_window_raise_button_callback), NULL);
    g_signal_connect(top_level_widget->actions_UI_widget->button_fold, "clicked", G_CALLBACK(fold_button_callback), NULL);
    g_signal_connect(top_level_widget->actions_UI_widget->button_check, "clicked", G_CALLBACK(check_button_callback), NULL);

    g_signal_connect(raise_window_button, "clicked", G_CALLBACK(raise_window_button_callback), NULL);

    // test creation of one of the 13 cards case from process request
    // char *test_processed_message[6] = {"CARD", "QUEEN", "CLUBS", NULL, NULL, NULL};
    // char *msg_to_be_put_in_recv_buffer = "CARD QUEEN CLUBS";
    // strcpy(RecvBuf, msg_to_be_put_in_recv_buffer);
    // execute_server_message();

    // community_flop();
    // community_turn();
    // community_river();
    // deal_pocket();


    // we only need to run this one command, the functions of community_flop(), community_turn(), etc. are called internally
    // test_distribute_cards();
    // set_player_cards_facedown(P1);
    // set_player_cards_facedown(P2);
    // set_player_cards_facedown(P3);
    // set_player_cards_facedown(P4);
    // set_player_cards_faceup(P1);
    // set_player_cards_faceup(P2);
    // set_player_cards_faceup(P3);
    // set_player_cards_faceup(P4);

    // these two lines of code are for testing purposes
    // current_client_player = player_1;
    // set_all_other_players_cards_facedown();

    // set_active_player(P1);

    // set_initial_sb_bb();
    
    // shift_sb_bb();



    /***************************************************************/

    // program_name_gbl = "Client Test";
    
    // char *server_name_str = "laguna";
    // strcpy(server_gbl, server_name_str);

    // char *port_number_as_str = "10183";
    // strcpy(port_num_as_str_gbl, port_number_as_str);

    // input_server_and_port_num();

    // set_program_name(program_name_gbl);
    // set_server(server_gbl);
    // set_port_num(port_num_as_str_gbl);

    // get_thirteen_cards_from_server();
    // beta_test_case_show_cards();

    


    /***************************************************************/
    
    gtk_main();
    /***************************************************************/

    return 0;
}

void test_distribute_cards()
{

    char *simulated_server_messages[17] = {"CARD THREE CLUBS", "CARD KING CLUBS", "CARD SIX DIAMONDS", "CARD NINE CLUBS",
                                      "CARD ACE SPADES", "CARD EIGHT DIAMONDS", "CARD THREE HEARTS", "CARD NINE DIAMONDS",
                                      "CARD FIVE SPADES", "CARD TEN HEARTS", "CARD SEVEN SPADES", "CARD SIX HEARTS", "CARD NINE SPADES",
                                      "COMMUNITY FLOP", "COMMUNITY TURN", "COMMUNITY RIVER", "DEAL"};                             

    for(int i = 0; i < 13; i++)
    {
        strcpy(RecvBuf, simulated_server_messages[i]);
        execute_server_message();
    }

    for(int i = 13; i < 17; i++)
    {
        strcpy(RecvBuf, simulated_server_messages[i]);
        execute_server_message();
    }
}

// once the counter limit is reached, it will switch to the other frequency state
// this should be used in the idle function
void test_frequency_state_with_counter(int counter_limit)
{
    static int counter = 0;

    if(high_frequency_state == true)
	{
		if(counter == counter_limit - 1)
		{
			disable_high_frequency_state_for_idle_timer();

            counter = 0;
            return;
        }
	}
	else if(high_frequency_state == false)
	{
		if(counter == counter_limit - 1)
		{
			enable_high_frequency_state_for_idle_timer();

            counter = 0;
            return;
        }
	}

    counter++;
}