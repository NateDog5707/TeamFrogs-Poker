/* message_process.c */

#include "message_process.h"
#include "global_variables.h"
#include "communication_with_server.h"
#include "gtk_abstract_functions.h"
#include "card.h"
#include "parse.h"

// button clicked

	// init communication :client to serv
	// receive the server buffer
	// message process

//init_communication_session(char *message_to_send);

gboolean idle_thread_function(gpointer data);

// receive server buffer
void execute_server_message()
{
	// assuming that the server's message is in received buffer at this point
	parsed_message_from_server = mallocParsed(parsed_message_from_server);
	parsed_message_from_server = parseString(RecvBuf, parsed_message_from_server); 

	message_processing(parsed_message_from_server);

	freeParsed(parsed_message_from_server);
}

// parsing server messages
void message_processing(char **parsed) 
{
	int amount = 0;
	int player_num = 0;
	
	if(strcmp(parsed[0], "SUCCESS") == 0)
	{
		printf("Test Success\n");
		connection_successful = true;
	}
	else if(strcmp(parsed[0], "CARD") == 0)
	{
		t_rank rank = convert_rank_str_to_enum(parsed[1]);
		t_suit suit = convert_suit_str_to_enum(parsed[2]);
		thirteen_card_array[thirteen_card_array_index] = init_card(rank, suit);
		thirteen_card_array_index++;
	}
	else if(strcmp(parsed[0], "DEAL") == 0)
	{
		deal_pocket();
		set_all_other_players_cards_facedown();
	}
	else if(strcmp(parsed[0], "COMMUNITY") == 0)
	{
		if(strcmp(parsed[1], "PREFLOP") == 0)
		{
			community_preflop();    // no cards shown
		}
		else if(strcmp(parsed[1], "FLOP") == 0)
		{
			community_flop();   // first three community cards shown
		}
		else if(strcmp(parsed[1], "TURN") == 0)
		{
			community_turn(); // fourth community card shown
		}
		else if(strcmp(parsed[1], "RIVER") == 0)
		{
			community_river();  // fifth community card shown
		}
		else
		{
			printf("Unknown Command\n");
		}	
	}
	else if(strcmp(parsed[0], "UPDATE") == 0)
	{
		if(strcmp(parsed[1], "POT") == 0)
		{
			if(strcmp(parsed[2], "MAIN") == 0)
			{
				amount = convertToInt(parsed[3]);
				update_main_pot(amount);
			}
			else if(strcmp(parsed[2], "PLAYER_1") == 0)
			{
				//converting amount from string to int
				amount = convertToInt(parsed[3]);
				
				//updating the player's balance
				player_1 -> balance = amount;
				//updating pot widget
				update_player_pot(player_1_widget, amount); 
			}
			else if(strcmp(parsed[2], "PLAYER_2") == 0)
			{
				amount = convertToInt(parsed[3]);
				
				player_2 -> balance = amount;
				update_player_pot(player_2_widget, amount);
			}
			else if(strcmp(parsed[2], "PLAYER_3") == 0)
			{
				amount = convertToInt(parsed[3]);
				
				player_3 -> balance = amount;
				update_player_pot(player_3_widget, amount); 
			}
			else if(strcmp(parsed[2], "PLAYER_4") == 0)
			{
				amount = convertToInt(parsed[3]);
				
				player_4 -> balance = amount;
				update_player_pot(player_4_widget, amount); 
			}
			else
			{
				printf("Unknown Player Number\n");
			}
		}
		else
		{
			printf("Unknown Command\n");
		}
	}
	else if(strcmp(parsed[0], "ACTION") == 0)
	{
		if(strcmp(parsed[2], "PLAYER_1") == 0)
		{
			player_num = 1;
		}
		else if(strcmp(parsed[2], "PLAYER_2") == 0)
		{
			player_num = 2;
		}
		else if(strcmp(parsed[2], "PLAYER_3") == 0)
		{
			player_num = 3;
		}
		else if(strcmp(parsed[2], "PLAYER_4") == 0)
		{
			player_num = 4;
		}
		else
		{
			printf("Unknown Player Number for Fold\n");
		}

		if(strcmp(parsed[1], "FOLD") == 0)
		{
			// pop up message that tells that the player has done this action
			action_fold(player_num);
		}
		else if(strcmp(parsed[1], "CALL") == 0)
		{
			action_call(player_num);
		}
		else if(strcmp(parsed[1], "RAISE") == 0)
		{
			amount = convertToInt(parsed[3]);
			action_raise(player_num, amount);
		}
		else if(strcmp(parsed[1], "CHECK") == 0)
		{	
			action_check(player_num);
		}
		else
		{
			printf("Unknown Command\n");
		}
	}
	else if(strcmp(parsed[0], "REQUEST") == 0)
	{		
		if(strcmp(parsed[1], "SEAT") == 0)
		{
			int seat;
			seat = convertToInt(parsed[3]);

			char player_name[55] = "";
			
			switch(seat)
			{
				case 1:
					strcpy(player_name, "P1: ");
					strcat(player_name, parsed[2]);

					strcpy(player_1 -> name, parsed[2]);
					gtk_label_set_text(GTK_LABEL(player_1_widget -> label_name), player_name);
					break;
				case 2:
					strcpy(player_name, "P2: ");
					strcat(player_name, parsed[2]);
					
					strcpy(player_2 -> name, parsed[2]);
					gtk_label_set_text(GTK_LABEL(player_2_widget -> label_name), player_name);
					break;
				case 3:
					strcpy(player_name, "P3: ");
					strcat(player_name, parsed[2]);

					strcpy(player_3 -> name, parsed[2]);
					gtk_label_set_text(GTK_LABEL(player_3_widget -> label_name), player_name);
					break;
				case 4:
					strcpy(player_name, "P4: ");
					strcat(player_name, parsed[2]);

					strcpy(player_4 -> name, parsed[2]);
					gtk_label_set_text(GTK_LABEL(player_4_widget -> label_name), player_name);
					break;
				default:
					printf("Unknown Player Number\n");
					break;
			}

			/*
			if(strcmp(parsed[2], "PLAYER_1") == 0)
			{
				request_seat(player_1, seat);
			}
			else if(strcmp(parsed[2], "PLAYER_2") == 0)
			{
				request_seat(player_2, seat);
			}
			else if(strcmp(parsed[2], "PLAYER_3") == 0)
			{
				request_seat(player_3, seat);
			}
			else if(strcmp(parsed[2], "PLAYER_4") == 0)
			{
				request_seat(player_4, seat);
			}
			else
			{
				printf("Unknown Player Number\n");
			}
			*/
		}
		else if(strcmp(parsed[1], "LEAVE") == 0)
		{	
			if(strcmp(parsed[2], "PLAYER_1") == 0)
			{
				request_leave(player_1);
			}
			else if(strcmp(parsed[2], "PLAYER_2") == 0)
			{
				request_leave(player_2);
			}
			else if(strcmp(parsed[2], "PLAYER_3") == 0)
			{
				request_leave(player_3);
			}
			else if(strcmp(parsed[2], "PLAYER_4") == 0)
			{
				request_leave(player_4);
			}
			else
			{
				printf("Unknown Player Number\n");
			}
		}
		else
		{
			printf("Unknown Command\n");
		}
	}
	else if(strcmp(parsed[0], "SEAT") == 0)
	{
		if(strcmp(parsed[1], "GRANTED") == 0)
		{
			seat_granted = true;
		}
	}
	else if(strcmp(parsed[0], "READYUP") == 0)
	{
		if(strcmp(parsed[1], "CONFIRMED") == 0)
		{
			printf("Starting the idle thread\n");
			idle_handler_id = gtk_idle_add(idle_thread_function, NULL);
		}
	}
	else if(strcmp(parsed[0], "STARTEDGAME") == 0)
	{
		close_waiting_room_window();
		show_main_window();
	}
	else if(strcmp(parsed[0], "NOUPDATE") == 0)
	{
		printf("No update so won't do anything\n");
	}
	else
	{
		printf("Unknown Command\n");
	}

	if(idle_timer != NULL)
	{
		if(high_frequency_state == true)
		{
			if(strcmp(RecvBuf, "NOUPDATE") == 0)
			{
				disable_high_frequency_state_for_idle_timer();
			}
		}
		else if(high_frequency_state == false)
		{
			if(strcmp(RecvBuf, "NOUPDATE") != 0)
			{
				enable_high_frequency_state_for_idle_timer();
			}
		}
	}
} 

// showing community cards
void community_preflop()
{
	// no cards
	thirteen_card_array_index = 0;
	update_card_images_in_community_cards_widget();
}
    
void community_flop()
{
	// first three cards
	push_to_cardList(community_cards, thirteen_card_array[8]);
	push_to_cardList(community_cards, thirteen_card_array[9]);
	push_to_cardList(community_cards, thirteen_card_array[10]);
	
	update_card_images_in_community_cards_widget();
}


void community_turn()
{
	// fourth card
	push_to_cardList(community_cards, thirteen_card_array[11]);
	
	update_card_images_in_community_cards_widget();

}

void community_river()
{
	// fifth card
	push_to_cardList(community_cards, thirteen_card_array[12]);
	
	update_card_images_in_community_cards_widget();
} 

// dealing pocket cards
void deal_pocket()
{
	// player 1 pocket cards
	push_to_cardList(player_1_pocket_cards, thirteen_card_array[0]);
	push_to_cardList(player_1_pocket_cards, thirteen_card_array[1]);

	// player 2 pocket cards
	push_to_cardList(player_2_pocket_cards, thirteen_card_array[2]);
	push_to_cardList(player_2_pocket_cards, thirteen_card_array[3]);

	// player 3 pocket cards
	push_to_cardList(player_3_pocket_cards, thirteen_card_array[4]);
	push_to_cardList(player_3_pocket_cards, thirteen_card_array[5]);

	// player 4 pocket cards
	push_to_cardList(player_4_pocket_cards, thirteen_card_array[6]);
	push_to_cardList(player_4_pocket_cards, thirteen_card_array[7]);

	// updating images
	update_card_images_in_pocket_cards_widget(P1);
    update_card_images_in_pocket_cards_widget(P2);
    update_card_images_in_pocket_cards_widget(P3);
    update_card_images_in_pocket_cards_widget(P4);
}

// updating pots
void update_player_pot(player_widget_t *player_widget, int amount)
{
	GtkWidget *pot_label = player_widget -> label_pot; 
	assert(pot_label);
	char updated_amount[30];
	sprintf(updated_amount, "%d", amount);
	gtk_label_set_text(GTK_LABEL(pot_label), updated_amount);
}

void update_main_pot(int amount)
{
	main_pot = amount;
	GtkWidget *main_pot = poker_table_and_seatings_widget -> main_pot_label;
	assert(main_pot);
	char updated_amount[30];
	char main_pot_amount[30] = "Main Pot: ";
	sprintf(updated_amount, "%d", amount);
	strcat(main_pot_amount, updated_amount);
	gtk_label_set_text(GTK_LABEL(main_pot), main_pot_amount);
}

// actions
void action_fold(int player_num)
{
	GtkWidget *action_label;

	char player_action[20] = "";

	switch(player_num)
	{
		case 1:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_1_activity_label;
			strcpy(player_action, "P1: Folded");
			break;
		case 2:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_2_activity_label;
			strcpy(player_action, "P2: Folded");
			break;
		case 3:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_3_activity_label;
			strcpy(player_action, "P3: Folded");
			break;
		case 4:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_4_activity_label;
			strcpy(player_action, "P4: Folded");
			break;
	}
	
	gtk_label_set_text(GTK_LABEL(action_label), player_action);
}

void action_call(int player_num)
{
	GtkWidget *action_label;

	char player_action[20] = "";
	int new_pot = 0;

	switch(player_num)
	{
		case 1:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_1_activity_label;
			new_pot = player_1 -> balance - current_bet;
			update_player_pot(player_1_widget, new_pot);
			player_1 -> balance = new_pot;
			update_main_pot(main_pot + current_bet);
			strcpy(player_action, "P1: Called");
			break;
		case 2:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_2_activity_label;
			new_pot = player_2 -> balance - current_bet;
			update_player_pot(player_2_widget, new_pot);
			player_2 -> balance = new_pot;
			update_main_pot(main_pot + current_bet);
			strcpy(player_action, "P2: Called");
			break;
		case 3:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_3_activity_label;
			new_pot = player_3 -> balance - current_bet;
			update_player_pot(player_3_widget, new_pot);
			player_3 -> balance = new_pot;
			update_main_pot(main_pot + current_bet);
			strcpy(player_action, "P3: Called");
			break;
		case 4:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_4_activity_label;
			new_pot = player_4 -> balance - current_bet;
			update_player_pot(player_4_widget, new_pot);
			player_4 -> balance = new_pot;
			update_main_pot(main_pot + current_bet);
			strcpy(player_action, "P4: Called");
			break;
	}
	
	gtk_label_set_text(GTK_LABEL(action_label), player_action);
}

void action_raise(int player_num, int amount)
{
	GtkWidget *action_label;

	char player_action[20] = "";
	char raise_amount[30] = "";
	
	int new_pot;

	switch(player_num)
	{
		case 1:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_1_activity_label;
			new_pot = player_1 -> balance - amount;
			update_player_pot(player_1_widget, new_pot);
			player_1 -> balance = new_pot;
			update_main_pot(main_pot + amount); 
			current_bet = amount;
			strcpy(player_action, "P1: Raised ");
			break;
		case 2:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_2_activity_label;
			new_pot = player_2 -> balance - amount;
			update_player_pot(player_2_widget, new_pot);
			player_2 -> balance = new_pot;
			update_main_pot(main_pot + amount);
			current_bet = amount;
			strcpy(player_action, "P2: Raised ");
			break;
		case 3:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_3_activity_label;
			new_pot = player_3 -> balance - amount;
			update_player_pot(player_3_widget, new_pot);
			player_3 -> balance = new_pot;
			update_main_pot(main_pot + amount);
			current_bet = amount;
			strcpy(player_action, "P3: Raised ");
			break;
		case 4:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_4_activity_label;
			new_pot = player_4 -> balance - amount;
			update_player_pot(player_4_widget, new_pot);
			player_4 -> balance = new_pot;
			update_main_pot(main_pot + amount);
			current_bet = amount;
			strcpy(player_action, "P4: Raised ");
			break;
	}
	
	sprintf(raise_amount, "%d", amount);
	strcat(player_action, raise_amount);
	gtk_label_set_text(GTK_LABEL(action_label), player_action);
}

void action_check(int player_num)
{
	GtkWidget *action_label;

	char player_action[20] = "";

	switch(player_num)
	{
		case 1:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_1_activity_label;
			strcpy(player_action, "P1: Checked");
			break;
		case 2:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_2_activity_label;
			strcpy(player_action, "P2: Checked");
			break;
		case 3:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_3_activity_label;
			strcpy(player_action, "P3: Checked");
			break;
		case 4:
			action_label = poker_table_and_seatings_widget -> activity_widget -> player_4_activity_label;
			strcpy(player_action, "P4: Checked");
			break;
	}
	
	gtk_label_set_text(GTK_LABEL(action_label), player_action);
}

// requests 
void request_seat(player_t *player, int seat_number)
{
	// request seat
}

void request_leave(player_t *player)
{

}


int convertToInt(char *num)
{
	int converted = atoi(num);
	return converted;
}