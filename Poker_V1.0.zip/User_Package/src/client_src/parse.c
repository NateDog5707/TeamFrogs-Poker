#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "parse.h"

// char** parsed = NULL;

//SIXTH TRY
char ** parseString(char* RecvBuf, char **parsed){

	int i = 0;
	int ctr = 0;
	char temp[128];
	// int size = strlen(RecvBuf);
	char delim[] = " ";
	

	strcpy(temp, RecvBuf);
	
	char *ptr = strtok(temp, delim);

//	printf("\nExternal.c: printing as initializing into parsed array\n");
	while(ptr != NULL)	
	{	
//		printf("ptr: '%s'\n", ptr);

//printf("Z\n");
	 	strcpy(parsed[i], ptr);
	 	i++;
		ctr++;
//printf("A\n");
		ptr = strtok(NULL, delim);
//printf("B\n");
	}
/*

//MORE DEBUG

	for (int k = 0; k < size; k++){
		printf("%d ", temp[k]);
	}	*/
	
/*
	printf("\nNow I will print from the parsed array\n");

	//debug
	int j = 0;
	while (parsed[j] != NULL){
		printf("parsed[%d] : %s\n", j, parsed[j]);
		j++;
	}
	j = 0;
*/
	
	return parsed;
}

char** mallocParsed(char** parsed){

	parsed = malloc(sizeof(char*) * 6);
	assert(parsed);
	if (!parsed){
		return NULL;
	}
	for (int i = 0; i < 6; i++){
		parsed[i] = (char*)malloc(sizeof(char) * 16);
	}
	return parsed;
}

void freeParsed(char** parsed){

	for(int i = 0; i < 6; i++)
	{
		free(parsed[i]);
	}


	if (parsed)
	{
		free(parsed);
	}
}

