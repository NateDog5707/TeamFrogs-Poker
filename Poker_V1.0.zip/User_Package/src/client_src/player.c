#include "player.h"
#include "list_of_cards.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

player_t *init_player(char *name, unsigned int balance, t_cardList *pocket_cards, player_number_t player_number)
{
    assert(name != NULL);
    assert(pocket_cards != NULL);

    player_t *new_player_object = malloc(sizeof(player_t));
    assert(new_player_object != NULL);
    
    // initializing the newly created object

    // we don't need to initialize every element in the name array to zero (I think)
    strcpy(new_player_object->name, name);
    new_player_object->balance = balance;
    new_player_object->has_folded = false;
    new_player_object->role = GENERIC;
    new_player_object->pocket_cards = pocket_cards;
    new_player_object->player_number = player_number;

    return new_player_object;
}

void delete_player(player_t *player)
{
    if(player == NULL)
    {
        printf("Warning: player pointer value is NULL");
    }

    delete_cardList(player->pocket_cards);
    free(player);
}