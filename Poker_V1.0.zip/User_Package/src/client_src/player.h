/* player.h */

#ifndef PLAYER_H

    #define PLAYER_H

    #include "list_of_cards.h"
    #include "constants.h"

    typedef enum role_t{
        GENERIC,
        SB,
        BB
    } role_t;

    typedef enum player_number_t{
        P1,
        P2,
        P3,
        P4
    } player_number_t;

    typedef struct player_t{
        char name[SLEN];
        unsigned int balance;
        _Bool has_folded;
        role_t role;
        t_cardList *pocket_cards;
        player_number_t player_number;
    } player_t;

    // char name[SLEN] will be initialized with all null characters at player object creation
    // the string provided in the char *name argument will be copied into the char name[SLEN] array
    player_t *init_player(char *name, unsigned int balance, t_cardList *pocket_cards, player_number_t player_number);
    void delete_player(player_t *player);


#endif