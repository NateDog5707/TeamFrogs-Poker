#include "timer.h"
#include "global_variables.h"

#include <stdio.h>
#include <time.h>
#include <stdbool.h>
#include <stdlib.h>
#include <assert.h>

timer_type *init_timer(double time_limit)
{
    timer_type *new_timer_object = malloc(sizeof(timer_type));
    assert(new_timer_object != NULL);

    new_timer_object->time_initial = clock();
    new_timer_object->time_final = clock();
    new_timer_object->elapsed_time = 0.0;
    new_timer_object->time_limit = time_limit;

    return new_timer_object;
}

void delete_timer(timer_type *timer)
{
    if(timer == NULL)
    {
        printf("Warning: pointer value is NULL");
    }

    free(timer);
}

void update_timer(timer_type *timer)
{
    timer->time_final = clock();
    // difftime() returns the time difference in seconds
    timer->elapsed_time = (double) (timer->time_final - timer->time_initial) / (double) (CLOCKS_PER_SEC);
}

_Bool timer_is_finished(timer_type *timer)
{
    // timer is finished
    if(timer->elapsed_time > timer->time_limit)
    {
        return true;
    }
    // timer is not finished
    else
    {
        return false;
    }
}

void reset_timer(timer_type *timer)
{
    timer->time_initial = clock();
    timer->time_final = clock();
    timer->elapsed_time = 0.0;
}

void enable_high_frequency_state_for_idle_timer()
{
    if(high_frequency_state == false)
	{
        idle_timer_limit = 0.01; // the delay for the high frequency state
        high_frequency_state = true;
        idle_timer->time_limit = idle_timer_limit;
    }
}

void disable_high_frequency_state_for_idle_timer()
{
    if(high_frequency_state == true)
	{
        idle_timer_limit = 1; // the delay for the low frequency state
        high_frequency_state = false;
        idle_timer->time_limit = idle_timer_limit;
    }
}