Team Frogs
Christopher Wan, Tyler Chew, Nathan Yan, Katherine Hsu, Johnel Torrejas, Ivan Tran

Version: 
Poker Beta Version

Date: 
06/04/2023

General Instructions:
To install, follow the instructions in INSTALL.txt
1. Download Poker_Beta_src.tar.gz
2. Use command "tar -xvzf Poker_Beta_src.tar.gz"
3. Use command "cd Source_Package"
4. Use command "make"

To play the poker game:
1. In one terminal, use command "./bin/PokerServer 10180" to launch the server executable
2. In a seperate terminal, use command "./bin/poker_client.exe" to launch the client executable
3. Repeat (2.) as needed for multiple clients

Upon launching ./bin/poker_client.exe
1. When prompted for "Input server: ", enter the server host where the PokerServer is hosted
2. When prompted for "Input port number: ", enter the port number which was used to execute PokerServer (enter 10180, if following instructions in order)

To run test commands:
1. In parent directory, use commands "make test", "make test-gui", "make test-comm", as desired


For more detailed instructions, refer to Poker_UserManual.pdf
