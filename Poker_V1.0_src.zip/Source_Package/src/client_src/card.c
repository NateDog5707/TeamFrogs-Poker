#include "card.h"
#include "constants.h"
#include "global_variables.h"
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

t_card *init_card(t_rank rank, t_suit suit)
{
    t_card *new_card = malloc(sizeof(t_card));
    assert(new_card != NULL);
    new_card->rank = rank;
    new_card->suit = suit;
    new_card->is_faced_up = true;

    return new_card;
}

void delete_card(t_card *card)
{
    if(card == NULL)
    {
        printf("Warning: card pointer value is NULL");
    }
    
    free(card);
}

char *get_corresponding_card_image_path(t_card *card)
{
    // this will keep track of the index of the card that matches the passed in card
    // in the reference cards array
    int index;

    for(int i = 0; i < NUM_UNIQUE_CARDS; i++)
    {
        t_card *current_card = reference_cards[i];

        if(current_card == NULL)
        {
            printf("Reference cards array not initialized (use the corresponding function to do so)\n");
            return NULL;
        }
        else
        {
            if(current_card->rank == card->rank)
            {
                if(current_card->suit == card->suit)
                {
                    index = i;
                    break;
                }
            }
        }
    }

    return reference_cards_image_paths[index];
}

void flip_card(t_card *card)
{
    if(card->is_faced_up == true)
    {
        card->is_faced_up = false;
    }
    else if(card->is_faced_up == false)
    {
        card->is_faced_up = true;
    }
}

t_rank convert_rank_str_to_enum(char *rank_str)
{
    t_rank rank;

    if(strcmp(rank_str, "ACE") == 0)
    {
        rank = ACE;
    }
    else if(strcmp(rank_str, "TWO") == 0)
    {
        rank = TWO;
    }
    else if(strcmp(rank_str, "THREE") == 0)
    {
        rank = THREE;
    }
    else if(strcmp(rank_str, "FOUR") == 0)
    {
        rank = FOUR;
    }
    else if(strcmp(rank_str, "FIVE") == 0)
    {
        rank = FIVE;
    }   
    else if(strcmp(rank_str, "SIX") == 0)
    {
        rank = SIX;
    }
    else if(strcmp(rank_str, "SEVEN") == 0)
    {
        rank = SEVEN;
    }
    else if(strcmp(rank_str, "EIGHT") == 0)
    {
        rank = EIGHT;
    }
    else if(strcmp(rank_str, "NINE") == 0)
    {
        rank = NINE;
    }
    else if(strcmp(rank_str, "TEN") == 0)
    {
        rank = TEN;
    }
    else if(strcmp(rank_str, "JACK") == 0)
    {
        rank = JACK;
    }
    else if(strcmp(rank_str, "QUEEN") == 0)
    {
        rank = QUEEN;
    }
    else if(strcmp(rank_str, "KING") == 0)
    {
        rank = KING;
    }

    return rank;
}

t_suit convert_suit_str_to_enum(char *suit_str)
{
    t_suit suit;

    if(strcmp(suit_str, "CLUBS") == 0)
    {
        suit = CLUBS;
    }
    else if(strcmp(suit_str, "DIAMONDS") == 0)
    {
        suit = DIAMONDS;
    }
    else if(strcmp(suit_str, "SPADES") == 0)
    {
        suit = SPADES;
    }
    else if(strcmp(suit_str, "HEARTS") == 0)
    {
        suit = HEARTS;
    }

    return suit;
}