/* card.h */

#ifndef CARD_H

    #define CARD_H

    #include <stdbool.h>

    typedef enum t_rank{
        TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN,
        JACK, QUEEN, KING, ACE, 
        ARBITRARY_RANK
    } t_rank;

    typedef enum t_suit{
        SPADES,
        HEARTS,
        DIAMONDS,
        CLUBS,
        ARBITRARY_SUIT
    } t_suit;

    typedef struct t_card{
        t_rank rank;
        t_suit suit;
        _Bool is_faced_up;
    } t_card;

    t_card *init_card(t_rank rank, t_suit suit);
    void delete_card(t_card *card);

    char *get_corresponding_card_image_path(t_card *card);

    // if the card is faced up, will face down
    // if the card is faced down, will face up
    void flip_card(t_card *card);

    t_rank convert_rank_str_to_enum(char *rank_str);
    t_suit convert_suit_str_to_enum(char *suit_str);

#endif