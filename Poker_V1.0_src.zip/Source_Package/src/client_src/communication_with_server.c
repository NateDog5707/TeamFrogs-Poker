#include "communication_with_server.h"
#include "message_process.h"
#include "global_variables.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>

/*** global variables ****************************************************/

char *program_name_gbl = "client_test.exe";
char server_gbl[50];
char port_num_as_str_gbl[50];

const char *Program = NULL; /* program name for descriptive diagnostics */
int l, n;
int SocketFD, PortNo; /* socket file descriptor and port number */
struct sockaddr_in ServerAddress; /* server address we connect with */
struct hostent *Server; /* server host */
char SendBuf[256]; /* message buffer for sending a message */
char RecvBuf[256]; /* message buffer for receiving a response */
// communication_configuration_values[0] = Client Program Name, communication_configuration_values[1] = Server Name (e.g., bondi, laguna), communication_configuration_values[2] = Port Number
int communication_configuration_values_count = 0;
char *port_num_as_str = NULL;
char *communication_configuration_values[3] = {NULL, NULL, NULL}; // we will use this in replacement of char *argv[] to support usage in this program

/*** global functions ****************************************************/

// this function writes to the standard error spring when a fatal error occurs
void FatalError(const char *ErrorMsg)
{
    fputs(Program, stderr);
    fputs(": ", stderr);
    perror(ErrorMsg);
    fputs(Program, stderr);
    fputs(": Exiting!\n", stderr);
    exit(20);
}

// initiates one round of sending a message and receiving a message
void init_communication_session(char *message_to_send)
{
    Program = communication_configuration_values[0]; /* publish program name (for diagnostics) */

    #ifdef DEBUG
        printf("%s: Starting...\n", communication_configuration_values[0]);
    #endif

    if(communication_configuration_values_count < 3)
    {
        fprintf(stderr, "%s: missing one or more of the arguments (server or port number)\n", Program);
        exit(10);
    }
    Server = gethostbyname(communication_configuration_values[1]);
    if(Server == NULL)
    {
        fprintf(stderr, "%s: no such host named '%s'\n", Program, communication_configuration_values[1]);
        printf("Connection failed\n");
        return;
        // exit(10);
    }
    PortNo = atoi(communication_configuration_values[2]);
    if(PortNo <= 2000)
    {
        fprintf(stderr, "%s: invalid port number %d, should be >2000\n", Program, PortNo);
        printf("Connection failed\n");
        return;
        // exit(10);
    }
    ServerAddress.sin_family = AF_INET;
    ServerAddress.sin_port = htons(PortNo);
    ServerAddress.sin_addr = *(struct in_addr*)Server->h_addr_list[0];
    
    // do
    // {
        // Depending on the communication protocol, these commands can be updated accordingly
        // printf("%s: Enter a command to send to the poker server:\n"
        //     "         'BYE' to quit this client, or\n"
        //     "         'SHUTDOWN' to terminate the server\n"
        //     "command: ", communication_configuration_values[0]);

        // fgets(SendBuf, sizeof(SendBuf), stdin); /* no longer using this function */
        // replaced with: 
        strcpy(SendBuf, message_to_send);
        l = strlen(SendBuf);

        if (SendBuf[l-1] == '\n')
        {   
            SendBuf[--l] = 0;
        }
        if (0 == strcmp("BYE", SendBuf))
        {
            // break;
            printf("%s: Exiting...\n", Program);
            exit(10);
        }
        // this if corresponds with any message that isn't "BYE"
        if (l)
        {   
            SocketFD = socket(AF_INET, SOCK_STREAM, 0);
            if (SocketFD < 0)
            {   
                FatalError("socket creation failed");
            }
            
            printf("%s: Connecting to the server at port %d...\n", Program, PortNo);
            if (connect(SocketFD, (struct sockaddr*)&ServerAddress, sizeof(ServerAddress)) < 0)
            {   
                FatalError("connecting to server failed");
            }
            
            printf("%s: Sending message '%s'...\n", Program, SendBuf);
            n = write(SocketFD, SendBuf, l);
            if (n < 0)
            {   
                FatalError("writing to socket failed");
            }
            #ifdef DEBUG
                    printf("%s: Waiting for response...\n", Program);
            #endif
            n = read(SocketFD, RecvBuf, sizeof(RecvBuf)-1);
            if (n < 0) 
            {   
                FatalError("reading from socket failed");
            }
            RecvBuf[n] = 0;
            printf("%s: Received response: %s\n", Program, RecvBuf);
            #ifdef DEBUG
                    printf("%s: Closing the connection...\n", Program);
            #endif
            close(SocketFD);
        }
    // } while(0 != strcmp("SHUTDOWN", SendBuf));
}

void init_communication_session_append_player_to_message(char *message_to_send_without_player)
{
    assert(current_client_player != NULL);

    player_number_t current_client_player_number = current_client_player->player_number;
    char *player_number_str;

    if(current_client_player_number == P1)
    {
        player_number_str = " PLAYER_1";
    }
    else if(current_client_player_number == P2)
    {
        player_number_str = " PLAYER_2";
    }
    else if(current_client_player_number == P3)
    {
        player_number_str = " PLAYER_3";
    }
    else if(current_client_player_number == P4)
    {
        player_number_str = " PLAYER_4";
    }
    
    char message_to_send[50];
    strcpy(message_to_send, message_to_send_without_player);
    strcat(message_to_send, player_number_str);

    printf("Message that will be sent to server: %s\n", message_to_send);

    // will have to add the init_communication_session() function call here passing in message_to_send as an argument
    init_communication_session(message_to_send);
}

void init_communication_session_append_player_then_value_to_message(char *message_to_send_without_player, int value)
{
    char value_turned_into_str[50];
    sprintf(value_turned_into_str, "%d", value);

    player_number_t current_client_player_number = current_client_player->player_number;
    char *player_number_str;

    if(current_client_player_number == P1)
    {
        player_number_str = " [PLAYER_1]";
    }
    else if(current_client_player_number == P2)
    {
        player_number_str = " [PLAYER_2]";
    }
    else if(current_client_player_number == P3)
    {
        player_number_str = " [PLAYER_3]";
    }
    else if(current_client_player_number == P4)
    {
        player_number_str = " [PLAYER_4]";
    }

    char message_to_send[50];


    strcpy(message_to_send, "ACTION RAISE");
    strcat(message_to_send, player_number_str);
    strcat(message_to_send, " ");
    strcat(message_to_send, value_turned_into_str);

    printf("%s\n", message_to_send);
}

void set_program_name(char *program_name)
{
    communication_configuration_values[0] = program_name;
    communication_configuration_values_count++;
}

void set_server(char *server_name)
{
    communication_configuration_values[1] = server_name;
    communication_configuration_values_count++;
}

void set_port_num(char *port_num_as_str)
{
    communication_configuration_values[2] = port_num_as_str;
    communication_configuration_values_count++;
}

void input_server_and_port_num()
{
    printf("Input server: ");
    scanf("%s%*c", server_gbl);
    printf("Input port number: ");
    scanf("%s%*c", port_num_as_str_gbl);
}

void get_thirteen_cards_from_server()
{
    for(int i = 0; i < 13; i++)
    {
        int card_num = i + 1;
        char card_num_as_str[50];
        char message_to_send[50];

        char *first_part_of_message = "GIVE CARD ";
        sprintf(card_num_as_str, "%d", card_num);

        strcpy(message_to_send, first_part_of_message);
        strcat(message_to_send, card_num_as_str);
        
        init_communication_session(message_to_send);
        execute_server_message();
    }
}

void beta_test_case_show_cards()
{
    char *beta_test_case_messages[] = {"SHOW FLOP", "SHOW TURN", "SHOW RIVER", "SHOW DEAL"};

    for (int i = 0; i < 4; i++)
    {
        init_communication_session(beta_test_case_messages[i]);
        execute_server_message();
    }
    
}
