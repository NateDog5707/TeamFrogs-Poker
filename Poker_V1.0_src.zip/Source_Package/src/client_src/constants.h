/* constants.h */

#ifndef CONSTANTS_H

    #include "card.h"

    #define CONSTANTS_H

    #define WINDOW_WIDTH 500
    #define WINDOW_HEIGHT 500
    #define TABLE_COL_SPACING 5
    #define TABLE_ROW_SPACING 5
    #define SLEN 50
    #define NUM_UNIQUE_CARDS 52
    #define POKER_TABLE_RESIZE_PERCENTAGE 1
    #define POCKET_CARD_RESIZE_PERCENTAGE 0.625
    #define COMMUNITY_CARD_RESIZE_PERCENTAGE 0.7
    #define AVATAR_RESIZE_PERCENTAGE 0.3
    #define BUTTON_RESIZE_PERCENTAGE 0.4
    #define MAIN_WINDOW_WIDTH 250
    #define MAIN_WINDOW_HEIGHT 100

    // Player Avatar Image Paths
    #define PLAYER_1_AVATAR_IMAGE_PATH "assets/avatar_1.png"
    #define PLAYER_2_AVATAR_IMAGE_PATH "assets/avatar_2.png"
    #define PLAYER_3_AVATAR_IMAGE_PATH "assets/avatar_3.png"
    #define PLAYER_4_AVATAR_IMAGE_PATH "assets/avatar_4.png"

    // Poker Table Image
    //#define POKER_TABLE_IMAGE_PATH "assets/poker_table.png"
		#define POKER_TABLE_IMAGE_PATH "assets/table_test.png"
		
		// Button Image Path
		#define FOLD_BUTTON_IMAGE_PATH "assets/fold_button.png"
		#define CHECK_BUTTON_IMAGE_PATH "assets/check_button.png"
		#define RAISE_BUTTON_IMAGE_PATH "assets/raise_button.png"
		#define CALL_BUTTON_IMAGE_PATH "assets/call_button.png"
		
		// Waiting Screen Image Path
		#define WAITING_SCREEN_IMAGE_PATH "assets/waiting_screen.png"

    // Placeholder Card Image Path
    #define PLACEHOLDER_CARD_IMAGE_PATH "assets/placeholder_card.png"

    // Card Back Image Path
    #define CARD_BACK_PATH "assets/card_back.png"

    // Spade Card Image Paths
    #define SPADES_TWO_IMAGE_PATH "assets/spades_two.png"
    #define SPADES_THREE_IMAGE_PATH "assets/spades_three.png" 
    #define SPADES_FOUR_IMAGE_PATH "assets/spades_four.png" 
    #define SPADES_FIVE_IMAGE_PATH "assets/spades_five.png" 
    #define SPADES_SIX_IMAGE_PATH "assets/spades_six.png" 
    #define SPADES_SEVEN_IMAGE_PATH "assets/spades_seven.png" 
    #define SPADES_EIGHT_IMAGE_PATH "assets/spades_eight.png"
    #define SPADES_NINE_IMAGE_PATH "assets/spades_nine.png" 
    #define SPADES_TEN_IMAGE_PATH "assets/spades_ten.png" 
    #define SPADES_JACK_IMAGE_PATH "assets/spades_jack.png" 
    #define SPADES_QUEEN_IMAGE_PATH "assets/spades_queen.png"
    #define SPADES_KING_IMAGE_PATH "assets/spades_king.png" 
    #define SPADES_ACE_IMAGE_PATH "assets/spades_ace.png" 

    // Heart Card Image Paths
    #define HEARTS_TWO_IMAGE_PATH "assets/hearts_two.png" 
    #define HEARTS_THREE_IMAGE_PATH "assets/hearts_three.png" 
    #define HEARTS_FOUR_IMAGE_PATH "assets/hearts_four.png" 
    #define HEARTS_FIVE_IMAGE_PATH "assets/hearts_five.png" 
    #define HEARTS_SIX_IMAGE_PATH "assets/hearts_six.png" 
    #define HEARTS_SEVEN_IMAGE_PATH "assets/hearts_seven.png" 
    #define HEARTS_EIGHT_IMAGE_PATH "assets/hearts_eight.png" 
    #define HEARTS_NINE_IMAGE_PATH "assets/hearts_nine.png" 
    #define HEARTS_TEN_IMAGE_PATH "assets/hearts_ten.png" 
    #define HEARTS_JACK_IMAGE_PATH "assets/hearts_jack.png" 
    #define HEARTS_QUEEN_IMAGE_PATH "assets/hearts_queen.png" 
    #define HEARTS_KING_IMAGE_PATH "assets/hearts_king.png" 
    #define HEARTS_ACE_IMAGE_PATH "assets/hearts_ace.png" 

    // Diamond Card Image Paths
    #define DIAMONDS_TWO_IMAGE_PATH "assets/diamonds_two.png" 
    #define DIAMONDS_THREE_IMAGE_PATH "assets/diamonds_three.png" 
    #define DIAMONDS_FOUR_IMAGE_PATH "assets/diamonds_four.png" 
    #define DIAMONDS_FIVE_IMAGE_PATH "assets/diamonds_five.png" 
    #define DIAMONDS_SIX_IMAGE_PATH "assets/diamonds_six.png" 
    #define DIAMONDS_SEVEN_IMAGE_PATH "assets/diamonds_seven.png" 
    #define DIAMONDS_EIGHT_IMAGE_PATH "assets/diamonds_eight.png" 
    #define DIAMONDS_NINE_IMAGE_PATH "assets/diamonds_nine.png" 
    #define DIAMONDS_TEN_IMAGE_PATH "assets/diamonds_ten.png" 
    #define DIAMONDS_JACK_IMAGE_PATH "assets/diamonds_jack.png" 
    #define DIAMONDS_QUEEN_IMAGE_PATH "assets/diamonds_queen.png" 
    #define DIAMONDS_KING_IMAGE_PATH "assets/diamonds_king.png" 
    #define DIAMONDS_ACE_IMAGE_PATH "assets/diamonds_ace.png" 

    // Clubs Card Image Paths
    #define CLUBS_TWO_IMAGE_PATH "assets/clubs_two.png" 
    #define CLUBS_THREE_IMAGE_PATH "assets/clubs_three.png" 
    #define CLUBS_FOUR_IMAGE_PATH "assets/clubs_four.png" 
    #define CLUBS_FIVE_IMAGE_PATH "assets/clubs_five.png" 
    #define CLUBS_SIX_IMAGE_PATH "assets/clubs_six.png" 
    #define CLUBS_SEVEN_IMAGE_PATH "assets/clubs_seven.png" 
    #define CLUBS_EIGHT_IMAGE_PATH "assets/clubs_eight.png" 
    #define CLUBS_NINE_IMAGE_PATH "assets/clubs_nine.png" 
    #define CLUBS_TEN_IMAGE_PATH "assets/clubs_ten.png" 
    #define CLUBS_JACK_IMAGE_PATH "assets/clubs_jack.png" 
    #define CLUBS_QUEEN_IMAGE_PATH "assets/clubs_queen.png" 
    #define CLUBS_KING_IMAGE_PATH "assets/clubs_king.png" 
    #define CLUBS_ACE_IMAGE_PATH "assets/clubs_ace.png"

#endif