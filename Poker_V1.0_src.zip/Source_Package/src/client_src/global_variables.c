#include "global_variables.h"

#include "constants.h"
#include "card.h"
#include "gtk_widget_structures.h"
#include "player.h"
#include "list_of_players.h"
#include "timer.h"
#include <stdlib.h>
#include <gtk/gtk.h>

// global variable definitions
char **parsed_message_from_server = NULL;
GtkWidget *main_window = NULL;
GtkWidget *login_window = NULL;
GtkWidget *login_window_v_box = NULL;
GtkWidget *login_window_image = NULL;
GtkWidget *login_window_error_label = NULL;
GtkWidget *login_window_server_label = NULL;
GtkWidget *login_window_server_combo_box = NULL;
GtkWidget *login_window_port_label = NULL;
GtkWidget *login_window_port_combo_box = NULL;
GtkWidget *login_window_name_label = NULL;
GtkWidget *login_window_name_entry = NULL;
GtkWidget *login_window_seat_label = NULL;
GtkWidget *login_window_seat_entry = NULL;
GtkWidget *login_window_submit_button = NULL;
GtkWidget *waiting_room_window = NULL;
GtkWidget *waiting_room_v_box = NULL;
GtkWidget *waiting_room_title = NULL;
GtkWidget *waiting_room_image = NULL;
GtkWidget *waiting_room_label = NULL;
GtkWidget *waiting_room_ready_button = NULL;
GtkWidget *waiting_room_start_game_label = NULL;
GtkWidget *waiting_room_start_game_button = NULL;
top_level_widget_t *top_level_widget = NULL;
poker_table_and_seatings_widget_t *poker_table_and_seatings_widget = NULL;
poker_table_widget_t *poker_table_widget = NULL;
community_cards_widget_t *community_cards_widget = NULL;
t_cardList *community_cards = NULL;
int resized_card_dimensions[2];
_Bool connection_successful = false;
_Bool seat_granted = false;
actions_UI_widget_t *actions_UI_widget = NULL;

GtkWidget *raise_window = NULL;
GtkWidget *raise_window_v_box = NULL;
GtkWidget *raise_window_label = NULL;
GtkWidget *raise_window_hscale = NULL;
GtkAdjustment *raise_hscale_adjustment = NULL;
GtkWidget *raise_window_button = NULL;

GtkWidget *end_game_window = NULL;
GtkWidget *end_game_window_v_box = NULL;
GtkWidget *end_game_image = NULL;

// 13 card array
int thirteen_card_array_index = 0;
t_card *thirteen_card_array[13] = {NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL};

// player global variable dfinitions
player_t *player_1 = NULL;
player_t *player_2 = NULL;
player_t *player_3 = NULL;
player_t *player_4 = NULL;

player_t *current_client_player = NULL;

// pocket_cards_widget_t *player_1_pocket_cards_widget = NULL;
// pocket_cards_widget_t *player_2_pocket_cards_widget = NULL;
// pocket_cards_widget_t *player_3_pocket_cards_widget = NULL;
// pocket_cards_widget_t *player_4_pocket_cards_widget = NULL;

t_cardList *player_1_pocket_cards = NULL;
t_cardList *player_2_pocket_cards = NULL;
t_cardList *player_3_pocket_cards = NULL;
t_cardList *player_4_pocket_cards = NULL;

player_widget_t *player_1_widget = NULL;
player_widget_t *player_2_widget = NULL;
player_widget_t *player_3_widget = NULL;
player_widget_t *player_4_widget = NULL;

unsigned int current_bet = 45;
unsigned int main_pot = 45;

// player list global variable definition
player_list_t *player_list = NULL;

timer_type *idle_timer = NULL;
double idle_timer_limit = 1;
guint idle_handler_id = 0;
// flag used to stop idle thread
gboolean stop_thread = FALSE;
_Bool high_frequency_state = false;

// reference_cards is initially empty, have to initialize it
t_card *reference_cards[NUM_UNIQUE_CARDS];
char *reference_cards_image_paths[NUM_UNIQUE_CARDS] = {
    SPADES_TWO_IMAGE_PATH,
    SPADES_THREE_IMAGE_PATH,
    SPADES_FOUR_IMAGE_PATH,
    SPADES_FIVE_IMAGE_PATH,
    SPADES_SIX_IMAGE_PATH,
    SPADES_SEVEN_IMAGE_PATH,
    SPADES_EIGHT_IMAGE_PATH,
    SPADES_NINE_IMAGE_PATH,
    SPADES_TEN_IMAGE_PATH,
    SPADES_JACK_IMAGE_PATH,
    SPADES_QUEEN_IMAGE_PATH,
    SPADES_KING_IMAGE_PATH,
    SPADES_ACE_IMAGE_PATH,

    HEARTS_TWO_IMAGE_PATH,
    HEARTS_THREE_IMAGE_PATH,
    HEARTS_FOUR_IMAGE_PATH,
    HEARTS_FIVE_IMAGE_PATH,
    HEARTS_SIX_IMAGE_PATH,
    HEARTS_SEVEN_IMAGE_PATH,
    HEARTS_EIGHT_IMAGE_PATH,
    HEARTS_NINE_IMAGE_PATH,
    HEARTS_TEN_IMAGE_PATH,
    HEARTS_JACK_IMAGE_PATH,
    HEARTS_QUEEN_IMAGE_PATH,
    HEARTS_KING_IMAGE_PATH,
    HEARTS_ACE_IMAGE_PATH,

    DIAMONDS_TWO_IMAGE_PATH,
    DIAMONDS_THREE_IMAGE_PATH,
    DIAMONDS_FOUR_IMAGE_PATH,
    DIAMONDS_FIVE_IMAGE_PATH,
    DIAMONDS_SIX_IMAGE_PATH,
    DIAMONDS_SEVEN_IMAGE_PATH,
    DIAMONDS_EIGHT_IMAGE_PATH,
    DIAMONDS_NINE_IMAGE_PATH,
    DIAMONDS_TEN_IMAGE_PATH,
    DIAMONDS_JACK_IMAGE_PATH,
    DIAMONDS_QUEEN_IMAGE_PATH,
    DIAMONDS_KING_IMAGE_PATH,
    DIAMONDS_ACE_IMAGE_PATH,

    CLUBS_TWO_IMAGE_PATH,
    CLUBS_THREE_IMAGE_PATH,
    CLUBS_FOUR_IMAGE_PATH,
    CLUBS_FIVE_IMAGE_PATH,
    CLUBS_SIX_IMAGE_PATH,
    CLUBS_SEVEN_IMAGE_PATH,
    CLUBS_EIGHT_IMAGE_PATH,
    CLUBS_NINE_IMAGE_PATH,
    CLUBS_TEN_IMAGE_PATH,
    CLUBS_JACK_IMAGE_PATH,
    CLUBS_QUEEN_IMAGE_PATH,
    CLUBS_KING_IMAGE_PATH,
    CLUBS_ACE_IMAGE_PATH,
};

void initialize_reference_cards()
{
    // enum order reference:
    // rank:
        // TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN,
        // JACK, QUEEN, KING, ACE
    // suit:
        // SPADES,
        // HEARTS,
        // DIAMONDS,
        // CLUBS

    int index = 0;

    // for the suit enum
    for(int i = 0; i < 4; i++)
    {
        // for the rank enum
        for(int j = 0; j < 13; j++)
        {
            reference_cards[index] = init_card(j, i);
            index++;
        }
    }
}