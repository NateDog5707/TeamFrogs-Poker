#include "gtk_widget_structures.h"
#include "gtk_abstract_functions.h"
#include "global_variables.h"
#include "constants.h"
#include <stdlib.h>
#include <assert.h>
#include <gtk/gtk.h>
#include <stdio.h>

void init_top_level_widget()
{
    top_level_widget = malloc(sizeof(top_level_widget_t));

    // initialize the attributes
    top_level_widget->actions_UI_widget = actions_UI_widget;
    top_level_widget->poker_table_and_seatings = poker_table_and_seatings_widget;
    top_level_widget->overall_v_box_widget = gtk_vbox_new(FALSE, 10);

    gtk_container_add(GTK_CONTAINER(top_level_widget->overall_v_box_widget), top_level_widget->poker_table_and_seatings->overall_table_widget);
    gtk_container_add(GTK_CONTAINER(top_level_widget->overall_v_box_widget), top_level_widget->actions_UI_widget->overall_h_box_widget);
}

void init_poker_table_and_seatings_widget()
{
    poker_table_and_seatings_widget = malloc(sizeof(poker_table_and_seatings_widget_t));

    poker_table_and_seatings_widget->poker_table_widget = poker_table_widget;

    poker_table_and_seatings_widget->player_1_widget = player_1_widget;
    poker_table_and_seatings_widget->player_2_widget = player_2_widget;
    poker_table_and_seatings_widget->player_3_widget = player_3_widget;
    poker_table_and_seatings_widget->player_4_widget = player_4_widget;

    // initialize the activity widget
    poker_table_and_seatings_widget->activity_widget = init_activity_widget();

    // initialize the main pot label widget
    poker_table_and_seatings_widget->main_pot_label = gtk_label_new("Main Pot: 45");
    
    // modify font size of the label (main pot)
    PangoFontDescription *fontMainPot = gtk_widget_get_style(poker_table_and_seatings_widget->main_pot_label)->font_desc;
    pango_font_description_set_size(fontMainPot, 20 * PANGO_SCALE);
    gtk_widget_modify_font(poker_table_and_seatings_widget->main_pot_label, fontMainPot);

    // initialize the overall table widget and pack the child widgets into it
    poker_table_and_seatings_widget->overall_table_widget = init_table_widget(3, 3, TRUE);
    gtk_table_attach_defaults(GTK_TABLE(poker_table_and_seatings_widget->overall_table_widget), poker_table_and_seatings_widget->poker_table_widget->overall_table_widget, 1, 2, 1, 2);
    gtk_table_attach_defaults(GTK_TABLE(poker_table_and_seatings_widget->overall_table_widget), poker_table_and_seatings_widget->player_1_widget->overall_table_widget, 1, 2, 2, 3);
    gtk_table_attach_defaults(GTK_TABLE(poker_table_and_seatings_widget->overall_table_widget), poker_table_and_seatings_widget->player_2_widget->overall_table_widget, 0, 1, 1, 2);
    gtk_table_attach_defaults(GTK_TABLE(poker_table_and_seatings_widget->overall_table_widget), poker_table_and_seatings_widget->player_3_widget->overall_table_widget, 1, 2, 0, 1);
    gtk_table_attach_defaults(GTK_TABLE(poker_table_and_seatings_widget->overall_table_widget), poker_table_and_seatings_widget->player_4_widget->overall_table_widget, 2, 3, 1, 2);

    gtk_table_attach_defaults(GTK_TABLE(poker_table_and_seatings_widget->overall_table_widget), poker_table_and_seatings_widget->main_pot_label, 0, 1, 0, 1);
    gtk_table_attach_defaults(GTK_TABLE(poker_table_and_seatings_widget->overall_table_widget), poker_table_and_seatings_widget->activity_widget->overall_v_box_widget, 2, 3, 0, 1);
}

void init_player_widget(player_t *player)
{
    player_widget_t *new_player_widget = malloc(sizeof(player_widget_t));
    assert(new_player_widget != NULL);

    // initialize the overall table widget (current is 2 by 3)
    new_player_widget->overall_table_widget = init_table_widget(2, 3, TRUE);


    // initialize label widget for the pot (initial value will be based on the player argument)
    int player_balance = player->balance;
    char player_balance_as_str[SLEN];
    sprintf(player_balance_as_str, "%d", player_balance);
    new_player_widget->label_pot = gtk_label_new(player_balance_as_str);
    
    // modify font size of the label (pot)
    PangoFontDescription *fontPot = gtk_widget_get_style(new_player_widget->label_pot)->font_desc;
    pango_font_description_set_size(fontPot, 15 * PANGO_SCALE);
    gtk_widget_modify_font(new_player_widget->label_pot, fontPot);

    // initialize label widget for player name
    new_player_widget->label_name = gtk_label_new(player->name);
    
    // modify font size of the label (player name)
    PangoFontDescription *fontName = gtk_widget_get_style(new_player_widget->label_name)->font_desc;
    pango_font_description_set_size(fontName, 15 * PANGO_SCALE);
    gtk_widget_modify_font(new_player_widget->label_name, fontName);

    // initialize label widget for small blind or big blind
    new_player_widget->label_sb_bb = gtk_label_new("");
    
    // modify font size of the label (sb bb)
    PangoFontDescription *fontBlind = gtk_widget_get_style(new_player_widget->label_sb_bb)->font_desc;
    pango_font_description_set_size(fontBlind, 15 * PANGO_SCALE);
    gtk_widget_modify_font(new_player_widget->label_sb_bb, fontBlind);

    // pack the newly created label widgets
    gtk_table_attach_defaults(GTK_TABLE(new_player_widget->overall_table_widget), new_player_widget->label_name, 0, 1, 0, 1);
    gtk_table_attach_defaults(GTK_TABLE(new_player_widget->overall_table_widget), new_player_widget->label_pot, 2, 3, 0, 1);
    gtk_table_attach_defaults(GTK_TABLE(new_player_widget->overall_table_widget), new_player_widget->label_sb_bb, 2, 3, 1, 2);

    // initialize the horizontal box widget for the pocket cards
    // note that the pocket cards will have placeholders for now, therefore, we must use the corresponding function to update the pocket cards at some point after the overall function is called
    new_player_widget->pocket_cards = init_pocket_cards_widget();
    gtk_table_attach_defaults(GTK_TABLE(new_player_widget->overall_table_widget), new_player_widget->pocket_cards->overall_h_box_widget, 1, 2, 1, 2);


    determine_resized_image_dimensions(PLAYER_1_AVATAR_IMAGE_PATH, AVATAR_RESIZE_PERCENTAGE);
    int resized_width = resized_card_dimensions[0];
    int resized_height = resized_card_dimensions[1];

    /***************************************************************/
    // depending on the player number that the passed-in player has, will assign to the appropriate global variable
    if(player->player_number == P1)
    {
        player_1_widget = new_player_widget;
        player_1_widget->avatar = gtk_image_new_from_file(PLAYER_1_AVATAR_IMAGE_PATH);

        resize_image(player_1_widget->avatar, resized_width, resized_height);

        gtk_table_attach_defaults(GTK_TABLE(player_1_widget->overall_table_widget), player_1_widget->avatar, 1, 2, 0, 1);
    }
    else if(player->player_number == P2)
    {
        player_2_widget = new_player_widget;
        player_2_widget->avatar = gtk_image_new_from_file(PLAYER_2_AVATAR_IMAGE_PATH);

        resize_image(player_2_widget->avatar, resized_width, resized_height);

        gtk_table_attach_defaults(GTK_TABLE(player_2_widget->overall_table_widget), player_2_widget->avatar, 1, 2, 0, 1);
    }
    else if(player->player_number == P3)
    {
        player_3_widget = new_player_widget;
        player_3_widget->avatar = gtk_image_new_from_file(PLAYER_3_AVATAR_IMAGE_PATH);

        resize_image(player_3_widget->avatar, resized_width, resized_height);

        gtk_table_attach_defaults(GTK_TABLE(player_3_widget->overall_table_widget), player_3_widget->avatar, 1, 2, 0, 1);
    }
    else if(player->player_number == P4)
    {
        player_4_widget = new_player_widget;
        player_4_widget->avatar = gtk_image_new_from_file(PLAYER_4_AVATAR_IMAGE_PATH);

        resize_image(player_4_widget->avatar, resized_width, resized_height);

        gtk_table_attach_defaults(GTK_TABLE(player_4_widget->overall_table_widget), player_4_widget->avatar, 1, 2, 0, 1);
    }

    /***************************************************************/
}

pocket_cards_widget_t *init_pocket_cards_widget()
{
    pocket_cards_widget_t *new_pocket_cards_widget = malloc(sizeof(pocket_cards_widget_t));
    assert(new_pocket_cards_widget != NULL);

    // initialize the overall table widget
    new_pocket_cards_widget->overall_h_box_widget = gtk_hbox_new(TRUE, 5);

    // initialize the individual image widgets
    new_pocket_cards_widget->pocket_card_1_image = gtk_image_new_from_file(PLACEHOLDER_CARD_IMAGE_PATH);
    new_pocket_cards_widget->pocket_card_2_image = gtk_image_new_from_file(PLACEHOLDER_CARD_IMAGE_PATH);

    // initialize the individual image widgets array with the just-initialized individual image widgets above
    new_pocket_cards_widget->pocket_card_widgets_array[0] = new_pocket_cards_widget->pocket_card_1_image;
    new_pocket_cards_widget->pocket_card_widgets_array[1] = new_pocket_cards_widget->pocket_card_2_image;

    determine_resized_image_dimensions(PLACEHOLDER_CARD_IMAGE_PATH, POCKET_CARD_RESIZE_PERCENTAGE);
    int resized_width = resized_card_dimensions[0];
    int resized_height = resized_card_dimensions[1];

    // the actual act of resizing the images
    for(int i = 0; i < 2; i++)
    {
        resize_image(new_pocket_cards_widget->pocket_card_widgets_array[i], resized_width, resized_height);
    }

    // initialize the image paths array to NULL (since just initialized and doesn't account for any cards in the community cards list yet)
    for(int i = 0; i < 2; i++)
    {
        new_pocket_cards_widget->pocket_cards_image_paths[i] = NULL;
    }

    // will pack all the individual images into the horizontal box here
    gtk_container_add(GTK_CONTAINER(new_pocket_cards_widget->overall_h_box_widget), new_pocket_cards_widget->pocket_card_1_image);
    gtk_container_add(GTK_CONTAINER(new_pocket_cards_widget->overall_h_box_widget), new_pocket_cards_widget->pocket_card_2_image);

    gtk_widget_set_child_visible(new_pocket_cards_widget->pocket_card_1_image, FALSE);
    gtk_widget_set_child_visible(new_pocket_cards_widget->pocket_card_2_image, FALSE);

    return new_pocket_cards_widget;
}

void update_card_images_in_pocket_cards_widget(player_number_t player_number)
{
    // first put the player widgets and players in an array so it is easier to manipulate
    // this means that we have to initialize all the players and their pocket card widgets in order to test
    pocket_cards_widget_t *pocket_cards_widgets_array[] = {player_1_widget->pocket_cards, player_2_widget->pocket_cards, player_3_widget->pocket_cards, player_4_widget->pocket_cards};
    t_cardList *players_pocket_cards_array[] = {player_1->pocket_cards, player_2->pocket_cards, player_3->pocket_cards, player_4->pocket_cards};
    // this will keep track of which player widget we're updating and the corresponding player we're updating it with
    int index = 0;

    if(player_number == P1)
    {
        index = 0;
    }
    else if(player_number == P2)
    {
        index = 1;
    }
    else if(player_number == P3)
    {
        index = 2;
    }
    else if(player_number == P4)
    {
        index = 3;
    }

    pocket_cards_widget_t *pocket_cards_widget_updating = pocket_cards_widgets_array[index];
    t_cardList *pocket_cards_list_updating_with = players_pocket_cards_array[index];

    // first reset the image paths array
    for(int i = 0; i < 2; i++)
    {
        pocket_cards_widget_updating->pocket_cards_image_paths[i] = NULL;
    }

    t_cardList_entry *current_cardList_entry = pocket_cards_list_updating_with->first;
    int index_2 = 0;

    while(current_cardList_entry != NULL)
    {
        if(current_cardList_entry->card->is_faced_up == false)
        {
            pocket_cards_widget_updating->pocket_cards_image_paths[index_2] = CARD_BACK_PATH;
            gtk_image_set_from_file(GTK_IMAGE(pocket_cards_widget_updating->pocket_card_widgets_array[index_2]), CARD_BACK_PATH);
        
            // make the image widget visible since it corresponds with an actual card
            gtk_widget_set_child_visible(pocket_cards_widget_updating->pocket_card_widgets_array[index_2], TRUE);
        }
        else if(current_cardList_entry->card->is_faced_up == true)
        {
            char *current_card_image_path = get_corresponding_card_image_path(current_cardList_entry->card);

            pocket_cards_widget_updating->pocket_cards_image_paths[index_2] = current_card_image_path;
            gtk_image_set_from_file(GTK_IMAGE(pocket_cards_widget_updating->pocket_card_widgets_array[index_2]), current_card_image_path);

            // make the image widget visible since it corresponds with an actual card
            gtk_widget_set_child_visible(pocket_cards_widget_updating->pocket_card_widgets_array[index_2], TRUE);
        }

        current_cardList_entry = current_cardList_entry->next;
        index_2++;
    }

    // for the individual image widgets that don't have a card to correspond to, will set their paths to NULL and hide
    for(int i = 0; i < 2; i++)
    {
        if(pocket_cards_widget_updating->pocket_cards_image_paths[i] == NULL)
        {
            gtk_image_set_from_file(GTK_IMAGE(pocket_cards_widget_updating->pocket_card_widgets_array[i]), PLACEHOLDER_CARD_IMAGE_PATH);
            gtk_widget_set_child_visible(pocket_cards_widget_updating->pocket_card_widgets_array[i], FALSE);
        }
    }

    // resizing the images
    determine_resized_image_dimensions(PLACEHOLDER_CARD_IMAGE_PATH, POCKET_CARD_RESIZE_PERCENTAGE);
    int resized_width = resized_card_dimensions[0];
    int resized_height = resized_card_dimensions[1];

    // the actual act of resizing the images
    for(int i = 0; i < 2; i++)
    {
        resize_image(pocket_cards_widget_updating->pocket_card_widgets_array[i], resized_width, resized_height);
    }
}

poker_table_widget_t *init_poker_table_widget()
{
    poker_table_widget_t *new_poker_table_widget = malloc(sizeof(poker_table_widget_t));
    assert(new_poker_table_widget != NULL);

    // initialize the overall table widget (current is 3 by 3)
    new_poker_table_widget->overall_table_widget = init_table_widget(2, 2, TRUE);

    /***************************************************************/
    // initialize the poker table image widget (will span the whole table)
    new_poker_table_widget->poker_table_image = gtk_image_new_from_file(POKER_TABLE_IMAGE_PATH);
    
    // resizing the poker table widget
    // getting the original dimensions first
    // GdkPixbuf *poker_table_pixbuf_orig = gdk_pixbuf_new_from_file(POKER_TABLE_IMAGE_PATH, NULL);
    // int orig_width, orig_height;
    // orig_width = gdk_pixbuf_get_width(poker_table_pixbuf_orig);
    // orig_height = gdk_pixbuf_get_height(poker_table_pixbuf_orig);

    // // acquiring the new dimensions (the original scaled by a percentage)
    // int resized_width, resized_height;
    // resized_width = (int) ((double) orig_width * POKER_TABLE_RESIZE_PERCENTAGE);
    // resized_height = (int) ((double) orig_height * POKER_TABLE_RESIZE_PERCENTAGE);

    determine_resized_image_dimensions(POKER_TABLE_IMAGE_PATH, POKER_TABLE_RESIZE_PERCENTAGE);
    int resized_width = resized_card_dimensions[0];
    int resized_height = resized_card_dimensions[1];

    resize_image(new_poker_table_widget->poker_table_image, resized_width, resized_height);
    /***************************************************************/

    /***************************************************************/
    // assign the community cards widget to the corresponding attribute
    new_poker_table_widget->community_cards = community_cards_widget;
    // definiing useful variables
    GtkWidget *community_cards_overall_h_box = community_cards_widget->overall_h_box_widget;
    /***************************************************************/

    /***************************************************************/
    // packing of the widgets to the overall table
    // the order matters (subsequent packed widgets go behind the previous packed widget on the screen)

    // pack community cards horizontal box to the overall table widget
    gtk_table_attach_defaults(GTK_TABLE(new_poker_table_widget->overall_table_widget), community_cards_overall_h_box, 0, 2, 0, 2);

    // attaching the poker table image to the overall table widget
    // for the arguments (..., 0, 3, 0, 3), this means that it starts at the top left square and takes up 3 squares down and 3 squares right
    gtk_table_attach_defaults(GTK_TABLE(new_poker_table_widget->overall_table_widget), new_poker_table_widget->poker_table_image, 0, 2, 0, 2);
    /***************************************************************/

    return new_poker_table_widget;
}

// this will create the community cards GUI element based on the passed in doubly linked card list
community_cards_widget_t *init_community_cards_widget()
{
    community_cards_widget_t *new_community_cards_widget = malloc(sizeof(community_cards_widget_t));
    assert(new_community_cards_widget != NULL);
    
    // initialize the overall horizontal box widget
    new_community_cards_widget->overall_h_box_widget = gtk_hbox_new(TRUE, 5);

    // initialize the individual image widgets
    new_community_cards_widget->community_card_1_image = gtk_image_new_from_file(PLACEHOLDER_CARD_IMAGE_PATH);
    new_community_cards_widget->community_card_2_image = gtk_image_new_from_file(PLACEHOLDER_CARD_IMAGE_PATH);
    new_community_cards_widget->community_card_3_image = gtk_image_new_from_file(PLACEHOLDER_CARD_IMAGE_PATH);
    new_community_cards_widget->community_card_4_image = gtk_image_new_from_file(PLACEHOLDER_CARD_IMAGE_PATH);
    new_community_cards_widget->community_card_5_image = gtk_image_new_from_file(PLACEHOLDER_CARD_IMAGE_PATH);

    // initialize the individual image widgets array with the just-initialized individual image widgets above
    new_community_cards_widget->community_card_widgets_array[0] = new_community_cards_widget->community_card_1_image;
    new_community_cards_widget->community_card_widgets_array[1] = new_community_cards_widget->community_card_2_image;
    new_community_cards_widget->community_card_widgets_array[2] = new_community_cards_widget->community_card_3_image;
    new_community_cards_widget->community_card_widgets_array[3] = new_community_cards_widget->community_card_4_image;
    new_community_cards_widget->community_card_widgets_array[4] = new_community_cards_widget->community_card_5_image;

    // resize the images
    
    determine_resized_image_dimensions(PLACEHOLDER_CARD_IMAGE_PATH, COMMUNITY_CARD_RESIZE_PERCENTAGE);
    int resized_width = resized_card_dimensions[0];
    int resized_height = resized_card_dimensions[1];

    // the actual act of resizing the images
    for(int i = 0; i < 5; i++)
    {
        resize_image(new_community_cards_widget->community_card_widgets_array[i], resized_width, resized_height);
    }

    // initialize the image paths array to NULL (since just initialized and doesn't account for any cards in the community cards list yet)
    for(int i = 0; i < 5; i++)
    {
        new_community_cards_widget->community_cards_image_paths[i] = NULL;
    }

    // will pack all the individual images into the horizontal box here
    gtk_container_add(GTK_CONTAINER(new_community_cards_widget->overall_h_box_widget), new_community_cards_widget->community_card_1_image);
    gtk_container_add(GTK_CONTAINER(new_community_cards_widget->overall_h_box_widget), new_community_cards_widget->community_card_2_image);
    gtk_container_add(GTK_CONTAINER(new_community_cards_widget->overall_h_box_widget), new_community_cards_widget->community_card_3_image);
    gtk_container_add(GTK_CONTAINER(new_community_cards_widget->overall_h_box_widget), new_community_cards_widget->community_card_4_image);
    gtk_container_add(GTK_CONTAINER(new_community_cards_widget->overall_h_box_widget), new_community_cards_widget->community_card_5_image);

    // we can't use the gtk_widget_hide function because we can only use that when the widget isn't a child widget (in other words, is an isolated widget)
    gtk_widget_set_child_visible(new_community_cards_widget->community_card_1_image, FALSE);
    gtk_widget_set_child_visible(new_community_cards_widget->community_card_2_image, FALSE);
    gtk_widget_set_child_visible(new_community_cards_widget->community_card_3_image, FALSE);
    gtk_widget_set_child_visible(new_community_cards_widget->community_card_4_image, FALSE);
    gtk_widget_set_child_visible(new_community_cards_widget->community_card_5_image, FALSE);

    return new_community_cards_widget;
}

// this will update the global community cards widget with the current state of the community cards cardList
void update_card_images_in_community_cards_widget()
{
    // first reset the image paths array
    for(int i = 0; i < 5; i++)
    {
        community_cards_widget->community_cards_image_paths[i] = NULL;
    }

    t_cardList_entry *current_cardList_entry = community_cards->first;
    int index = 0;

    // this is iterating through the community cards cardList so that it can determine what the current community cards are
    while(current_cardList_entry != NULL)
    {
        // there are two cases, either the card is faced down or faced up

        // if the card in the cardList is faced down, then update the image path
        if(current_cardList_entry->card->is_faced_up == false)
        {
            community_cards_widget->community_cards_image_paths[index] = CARD_BACK_PATH;
            gtk_image_set_from_file(GTK_IMAGE(community_cards_widget->community_card_widgets_array[index]), CARD_BACK_PATH);

            // make the image widget visible since it corresponds with an actual card
            gtk_widget_set_child_visible(community_cards_widget->community_card_widgets_array[index], TRUE);
        }
        else if(current_cardList_entry->card->is_faced_up == true)
        {
            char *current_card_image_path = get_corresponding_card_image_path(current_cardList_entry->card);

            community_cards_widget->community_cards_image_paths[index] = current_card_image_path;
            gtk_image_set_from_file(GTK_IMAGE(community_cards_widget->community_card_widgets_array[index]), current_card_image_path);

            // make the image widget visible since it corresponds with an actual card
            gtk_widget_set_child_visible(community_cards_widget->community_card_widgets_array[index], TRUE);
        }

        current_cardList_entry = current_cardList_entry->next;
        index++;
    }

    // for the individual image widgets that don't have a card to correspond to, will set their paths to NULL and hide
    for(int i = 0; i < 5; i++)
    {
        if(community_cards_widget->community_cards_image_paths[i] == NULL)
        {
            gtk_image_set_from_file(GTK_IMAGE(community_cards_widget->community_card_widgets_array[i]), PLACEHOLDER_CARD_IMAGE_PATH);
            gtk_widget_set_child_visible(community_cards_widget->community_card_widgets_array[i], FALSE);
        }
    }

    // resizing
    determine_resized_image_dimensions(PLACEHOLDER_CARD_IMAGE_PATH, COMMUNITY_CARD_RESIZE_PERCENTAGE);
    int resized_width = resized_card_dimensions[0];
    int resized_height = resized_card_dimensions[1];

    // the actual act of resizing the images
    for(int i = 0; i < 5; i++)
    {
        resize_image(community_cards_widget->community_card_widgets_array[i], resized_width, resized_height);
    }
}

actions_UI_widget_t *init_actions_UI_widget()
{
    actions_UI_widget_t *new_actions_UI_widget = malloc(sizeof(actions_UI_widget_t));
    assert(new_actions_UI_widget != NULL);

    // initialize the overall horizontal box widget
    //new_actions_UI_widget->overall_h_box_widget = gtk_hbox_new(TRUE, 10);
    new_actions_UI_widget->overall_h_box_widget = gtk_fixed_new();
    
    // initialize button images
    GtkWidget *call_button_image = gtk_image_new_from_file(CALL_BUTTON_IMAGE_PATH);
    GtkWidget *raise_button_image = gtk_image_new_from_file(RAISE_BUTTON_IMAGE_PATH);
    GtkWidget *check_button_image = gtk_image_new_from_file(CHECK_BUTTON_IMAGE_PATH);
    GtkWidget *fold_button_image = gtk_image_new_from_file(FOLD_BUTTON_IMAGE_PATH);
    
    // resizing the images
    determine_resized_image_dimensions(CALL_BUTTON_IMAGE_PATH, BUTTON_RESIZE_PERCENTAGE);
    int resized_width = resized_card_dimensions[0];
    int resized_height = resized_card_dimensions[1];
    
    resize_image(call_button_image, resized_width, resized_height);
    resize_image(raise_button_image, resized_width, resized_height);
    resize_image(check_button_image, resized_width, resized_height);
    resize_image(fold_button_image, resized_width, resized_height);

    // initialize the button widgets
    //new_actions_UI_widget->button_call = gtk_button_new_with_label("CALL");
    //new_actions_UI_widget->button_raise = gtk_button_new_with_label("RAISE");
    //new_actions_UI_widget->button_check = gtk_button_new_with_label("CHECK");
    //new_actions_UI_widget->button_fold = gtk_button_new_with_label("FOLD");
    
    new_actions_UI_widget->button_call = gtk_button_new();
    new_actions_UI_widget->button_raise = gtk_button_new();
    new_actions_UI_widget->button_check = gtk_button_new();
    new_actions_UI_widget->button_fold = gtk_button_new();
    
    gtk_button_set_image(GTK_BUTTON(new_actions_UI_widget->button_call), call_button_image);
    gtk_button_set_image(GTK_BUTTON(new_actions_UI_widget->button_raise), raise_button_image);
    gtk_button_set_image(GTK_BUTTON(new_actions_UI_widget->button_check), check_button_image);
    gtk_button_set_image(GTK_BUTTON(new_actions_UI_widget->button_fold), fold_button_image);
    

    // pack the button widgets into the horizontal box
    //gtk_container_add(GTK_CONTAINER(new_actions_UI_widget->overall_h_box_widget), new_actions_UI_widget->button_call);
    //gtk_container_add(GTK_CONTAINER(new_actions_UI_widget->overall_h_box_widget), new_actions_UI_widget->button_raise);
    //gtk_container_add(GTK_CONTAINER(new_actions_UI_widget->overall_h_box_widget), new_actions_UI_widget->button_check);
    //gtk_container_add(GTK_CONTAINER(new_actions_UI_widget->overall_h_box_widget), new_actions_UI_widget->button_fold);
    gtk_fixed_put(GTK_FIXED(new_actions_UI_widget->overall_h_box_widget), new_actions_UI_widget->button_call, 390, 10);
    gtk_fixed_put(GTK_FIXED(new_actions_UI_widget->overall_h_box_widget), new_actions_UI_widget->button_raise, 690, 10);
    gtk_fixed_put(GTK_FIXED(new_actions_UI_widget->overall_h_box_widget), new_actions_UI_widget->button_check, 990, 10);
    gtk_fixed_put(GTK_FIXED(new_actions_UI_widget->overall_h_box_widget), new_actions_UI_widget->button_fold, 1290, 10);

    return new_actions_UI_widget;
}

activity_widget_t *init_activity_widget()
{
    activity_widget_t *new_activity_widget = malloc(sizeof(activity_widget_t));
    assert(new_activity_widget != NULL);

    // initializes the overall v box widget
    new_activity_widget->overall_v_box_widget = gtk_vbox_new(TRUE, 30);

    // initialize the individual label widgets with the initial values
    new_activity_widget->player_1_activity_label = gtk_label_new("P1: No Action");
    new_activity_widget->player_2_activity_label = gtk_label_new("P2: No Action");
    new_activity_widget->player_3_activity_label = gtk_label_new("P3: No Action");
    new_activity_widget->player_4_activity_label = gtk_label_new("P4: No Action");
    
    // modify font size of the label (activity labels)
    PangoFontDescription *fontActivity = gtk_widget_get_style(new_activity_widget->player_1_activity_label)->font_desc;
    pango_font_description_set_size(fontActivity, 17 * PANGO_SCALE);
    gtk_widget_modify_font(new_activity_widget->player_1_activity_label, fontActivity);
    gtk_widget_modify_font(new_activity_widget->player_2_activity_label, fontActivity);
    gtk_widget_modify_font(new_activity_widget->player_3_activity_label, fontActivity);
    gtk_widget_modify_font(new_activity_widget->player_4_activity_label, fontActivity);

    // set the alignments of the labels
    gtk_misc_set_alignment(GTK_MISC(new_activity_widget->player_1_activity_label), 0.0, 0.5);
    gtk_misc_set_alignment(GTK_MISC(new_activity_widget->player_2_activity_label), 0.0, 0.5);
    gtk_misc_set_alignment(GTK_MISC(new_activity_widget->player_3_activity_label), 0.0, 0.5);
    gtk_misc_set_alignment(GTK_MISC(new_activity_widget->player_4_activity_label), 0.0, 0.5);

    // pack the label widgets into the overall v box widget
    gtk_container_add(GTK_CONTAINER(new_activity_widget->overall_v_box_widget), new_activity_widget->player_1_activity_label);
    gtk_container_add(GTK_CONTAINER(new_activity_widget->overall_v_box_widget), new_activity_widget->player_2_activity_label);
    gtk_container_add(GTK_CONTAINER(new_activity_widget->overall_v_box_widget), new_activity_widget->player_3_activity_label);
    gtk_container_add(GTK_CONTAINER(new_activity_widget->overall_v_box_widget), new_activity_widget->player_4_activity_label);

    return new_activity_widget;
}