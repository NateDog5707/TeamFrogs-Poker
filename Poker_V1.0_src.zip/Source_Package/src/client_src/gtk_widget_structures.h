/* gtk_widget_structures.h */

#ifndef GTK_WIDGET_STRUCTURES_H

    #define GTK_WIDGET_STRUCTURES_H

    #include <gtk/gtk.h>
    #include "player.h"

    typedef struct player_widget_t player_widget_t;
    typedef struct actions_UI_widget_t actions_UI_widget_t;
    typedef struct poker_table_widget_t poker_table_widget_t;
    typedef struct poker_table_and_seatings_widget_t poker_table_and_seatings_widget_t;
    typedef struct community_cards_widget_t community_cards_widget_t;
    typedef struct pocket_cards_widget_t pocket_cards_widget_t;
    typedef struct activity_widget_t activity_widget_t;

    // this will be the widget that will be packed in the main window shown to the user
    typedef struct top_level_widget_t{
        
        GtkWidget *overall_v_box_widget;
        
        poker_table_and_seatings_widget_t *poker_table_and_seatings;
        actions_UI_widget_t *actions_UI_widget;

    } top_level_widget_t;

    typedef struct poker_table_and_seatings_widget_t{
        
        GtkWidget *overall_table_widget;
        
        poker_table_widget_t *poker_table_widget;

        // the players are the seatings
        player_widget_t *player_1_widget;
        player_widget_t *player_2_widget;
        player_widget_t *player_3_widget;
        player_widget_t *player_4_widget;

        // this is the activity widget that shows all the players actions for the current round as they are being made
        activity_widget_t *activity_widget;

        // this label is just for the total pot
        GtkWidget *main_pot_label;

    } poker_table_and_seatings_widget_t;

    // we need this type so that we can quickly reference sub-widgets w/i the player widget as well as the overall widget itself
    typedef struct player_widget_t{
        
        GtkWidget *overall_table_widget;
        
        GtkWidget *label_pot;
        GtkWidget *label_name;
        GtkWidget *label_sb_bb;
        pocket_cards_widget_t *pocket_cards;
        GtkWidget *avatar;

    } player_widget_t;

    // this will be very similar to the community cards widget type
    struct pocket_cards_widget_t{

        GtkWidget *overall_h_box_widget;
        GtkWidget *pocket_card_1_image;
        GtkWidget *pocket_card_2_image;

        // this array is just so that I can access the GtkWidget objects above contiguously
        GtkWidget *pocket_card_widgets_array[2];

        // we will iterate through the community cards cardList object and set the image paths accordingly
        // if there are less than 5 community cards then the widget will just hide itself (e.g., if NULL then hide)
        char *pocket_cards_image_paths[2];

    };

    // will hold the widget that includes all the buttons for what the player can do (the player on the running client)
    typedef struct actions_UI_widget_t{
        GtkWidget *overall_h_box_widget;
        
        GtkWidget *button_call;
        GtkWidget *button_raise;
        GtkWidget *button_check;
        GtkWidget *button_fold;

        gboolean call_is_enabled;
        gboolean raise_is_enabled;
        gboolean check_is_enabled;
        gboolean fold_is_enabled;

    } actions_UI_widget_t;

    typedef struct poker_table_widget_t{
        
        // will be a 3x3 table widget
        GtkWidget *overall_table_widget;
        // will be the image widget of the poker table that spans the whole overall table widget
        GtkWidget *poker_table_image;
        // will be a horizontal box that includes the community cards
        community_cards_widget_t *community_cards;
        // will be an image widget of a deck of cards (located on the top left of the overall table widget on top of the poker table image)
        GtkWidget *deck_of_cards_image;

    } poker_table_widget_t;

    typedef struct community_cards_widget_t{
        
        // these GtkWidget objects will never be deleted once initialized, only modified
        GtkWidget *overall_h_box_widget;
        GtkWidget *community_card_1_image;
        GtkWidget *community_card_2_image;
        GtkWidget *community_card_3_image;
        GtkWidget *community_card_4_image;
        GtkWidget *community_card_5_image;
        // this array is just so that I can access the GtkWidget objects above contiguously
        GtkWidget *community_card_widgets_array[5];

        // we will iterate through the community cards cardList object and set the image paths accordingly
        // if there are less than 5 community cards then the widget will just hide itself (e.g., if NULL then hide)
        char *community_cards_image_paths[5];

    } community_cards_widget_t;

    struct activity_widget_t{

        GtkWidget *overall_v_box_widget;

        GtkWidget *player_1_activity_label;
        GtkWidget *player_2_activity_label;
        GtkWidget *player_3_activity_label;
        GtkWidget *player_4_activity_label;
    };


    void init_top_level_widget();

    void init_poker_table_and_seatings_widget();

    // from the passed in player object, all the sub widgets of the player widget will be initialized using data from it
    void init_player_widget(player_t *player);
    // NOTE: We have to use special gtk functions to properly delete GtkWidget objects
    void delete_player_widget(player_widget_t *player_widget);

    // the default state of the buttons will be enabled
    actions_UI_widget_t *init_actions_UI_widget();
    void delete_actions_UI_widget(actions_UI_widget_t *actions_UI_widget);

    // will return an uninitialized poker_table_widget_t object pointer
    poker_table_widget_t *init_poker_table_widget();
    void delete_poker_table_widget(poker_table_widget_t *poker_table_widget);

    community_cards_widget_t *init_community_cards_widget();
    void delete_community_cards_widget(community_cards_widget_t *community_cards);

    void update_card_images_in_community_cards_widget();

    pocket_cards_widget_t *init_pocket_cards_widget();
    // have to provide the player number so it knows which player's pocket cards to update
    void update_card_images_in_pocket_cards_widget(player_number_t player_number);

    activity_widget_t *init_activity_widget();

#endif