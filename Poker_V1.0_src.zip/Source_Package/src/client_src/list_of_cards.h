/* list_of_cards.h */

#ifndef LIST_OF_CARDS_H

    #define LIST_OF_CARDS_H

    #include "card.h"

    typedef struct t_cardList_entry t_cardList_entry;
    typedef struct t_cardList t_cardList;

    typedef struct t_cardList_entry{
        t_cardList *card_list;
        t_cardList_entry *next;
        t_cardList_entry *prev;
        t_card *card;
    } t_cardList_entry;

    typedef struct t_cardList{
        unsigned int length;
        t_cardList_entry *first;
        t_cardList_entry *last;
    } t_cardList;

    t_cardList *init_cardList();
    void delete_cardList(t_cardList *cardList);
    void empty_cardList(t_cardList *cardList);
    void pop_from_cardList(t_cardList *cardList);
    void push_to_cardList(t_cardList *cardList, t_card *card);
    void flip_cards_in_cardList(t_cardList *cardList);
    void set_cards_in_cardList_facedown(t_cardList *cardList);
    void set_cards_in_cardList_faceup(t_cardList *cardList);

#endif
