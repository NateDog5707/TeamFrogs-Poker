#ifndef LIST_OF_PLAYERS_H

    #define LIST_OF_PLAYERS_H

    #include "player.h"

    typedef struct player_list_entry_t player_list_entry_t;
    typedef struct player_list_t player_list_t;

    struct player_list_entry_t{
        player_list_t *player_list;
        player_list_entry_t *next;
        player_list_entry_t *prev;
        player_t *player;
    };

    struct player_list_t{
        unsigned int length;
        player_list_entry_t *first;
        player_list_entry_t *last;
    };

    player_list_t *init_player_list();
    void delete_player_list(player_list_t *player_list);

    void empty_player_list(player_list_t *player_list);

    void pop_from_player_list(player_list_t *player_list);

    void push_to_player_list(player_list_t *player_list, player_t *player);

#endif