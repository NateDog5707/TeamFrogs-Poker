#include "constants.h"
#include "timer.h"
#include "gtk_abstract_functions.h"
#include "gtk_widget_structures.h"
#include "list_of_cards.h"
#include "card.h"
#include "global_variables.h"

#include <gtk/gtk.h>
#include <time.h>
#include <stdbool.h>
#include <stdio.h>

void widget_change_bg_color(GtkWidget* widget, const char *color_str);

// create idle_handler_id in global scope so can reference anywhere
// we would have multiple variations of these variables if we have multiple idle threads
guint idle_handler_id = 0;
// flag used to stop idle thread
gboolean stop_thread = FALSE;

double timer_limit = 0.5;
timer_type *timer = NULL;

gboolean idle_thread_function(gpointer data)
{
    static _Bool timer_is_initialized = false;

    if(timer_is_initialized == false)
    {
        timer = init_timer(timer_limit);
        timer_is_initialized = true;
    }

    if(timer_is_finished(timer) == true)
    {
        // perform the function when the timer is up
        g_print("Hello World\n");

        reset_timer(timer);
    }
    else if(timer_is_finished(timer) == false)
    {
        // updates the timer
        update_timer(timer);
    }

    if(stop_thread == TRUE)
    {
        // will terminate the idle thread
        return FALSE;
    }
    else
    {
        // will cotinue the idle thread
        return TRUE;
    }
}

static void hello(GtkWidget* widget, gpointer data)
{
    char *text = "button has been pressed";
    gtk_button_set_label(GTK_BUTTON(widget), text);
    gtk_widget_hide(widget);

    stop_thread = TRUE;
}

static void call_button_callback(GtkWidget* widget, gpointer data)
{

}

static gboolean delete_event(GtkWidget *widget, GdkEvent *event, gpointer data)
{
    g_print("delete event occured\n");

    // if this is the callback function of a delete event, then returning FALSE will trigger the destroy event
    return FALSE;
}

static void destroy(GtkWidget *widget, gpointer data)
{
    gtk_main_quit();
}

int main(int argc, char *argv[])
{
    /* Testing */

    initialize_reference_cards();
    t_card *test = reference_cards[0];

    /***********/

    GtkWidget *window;
    GtkWidget *button;
    GtkWidget *image_1;
    GtkWidget *image_2;
    GtkWidget *image_3;
    GtkWidget *image_4;
    GtkWidget *image_5;
    GtkWidget *image_6;
    GtkWidget *v_box;
    GtkWidget *h_box_1;
    GtkWidget *h_box_2;
    GtkWidget *table;
    GtkWidget *label;

    gtk_init(&argc, &argv);

    // initialize the top level window of the GTK application
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

    // changes the background color of the window widget
    widget_change_bg_color(window, "#4D9900");

    // configuring the newly created window
    gtk_window_set_title(GTK_WINDOW(window), "Poker Application");
    gtk_window_set_default_size(GTK_WINDOW(window), WINDOW_WIDTH, WINDOW_HEIGHT);

    // initialize a label widget
    label = gtk_label_new("Hello World");

    // initializes a button widget
    button = gtk_button_new_with_label("Hello World");

    // initializes image widgets
    image_1 = gtk_image_new_from_file("assets/banana.png");
    image_2 = gtk_image_new_from_file("assets/banana.png");
    image_3 = gtk_image_new_from_file("assets/banana.png");
    image_4 = gtk_image_new_from_file("assets/banana.png");
    image_5 = gtk_image_new_from_file("assets/banana.png");
    image_6 = gtk_image_new_from_file("assets/banana.png");

    // initialize horizontal box widgets
    // h_box_1 = gtk_hbox_new(FALSE, 10);
    // h_box_2 = gtk_hbox_new(FALSE, 10);

    // initializes vertical box widgets
    // v_box = gtk_vbox_new(FALSE, 10);

    // adds the button widget to the box widget
    // gtk_container_add(GTK_CONTAINER(box), button);
    // adds the image widget to the box widget
    // gtk_container_add(GTK_CONTAINER(h_box_1), image_1);
    // gtk_container_add(GTK_CONTAINER(h_box_1), image_2);
    // gtk_container_add(GTK_CONTAINER(h_box_1), image_3);

    // gtk_container_add(GTK_CONTAINER(h_box_2), image_4);
    // gtk_container_add(GTK_CONTAINER(h_box_2), image_5);
    // gtk_container_add(GTK_CONTAINER(h_box_2), image_6);

    // // adds the h_box widgets to the v_box
    // gtk_container_add(GTK_CONTAINER(v_box), h_box_1);
    // gtk_container_add(GTK_CONTAINER(v_box), h_box_2);

    // initializes a table widget
    table = init_table_widget(3, 3, TRUE);

    add_to_one_cell_table_widget(table, image_1, 1, 1);

    poker_table_widget_t *poker_table = init_poker_table_widget();

    // adds the v_box container widget to the window
    gtk_container_add(GTK_CONTAINER(window), poker_table->overall_table_widget);

    // show all the widgets and then configure the window's border width (padding)
    gtk_widget_show_all(window);
    gtk_container_set_border_width(GTK_CONTAINER(window), 50);

    /* initialize the events */

    // these two events go hand in hand, triggering delete event will lead to the destroy event occurring (given the right circumstances)
    g_signal_connect(window, "delete-event", G_CALLBACK(delete_event), NULL);
    g_signal_connect(window, "destroy", G_CALLBACK(destroy), NULL);
    g_signal_connect(button, "clicked", G_CALLBACK(hello), NULL);
    // g_signal_connect(button, "clicked", G_CALLBACK(gtk_widget_destroy), window);

    // initializing an idle thread
    idle_handler_id = gtk_idle_add(idle_thread_function, NULL);

    // run the GTK application
    gtk_main();

    return 0;
}