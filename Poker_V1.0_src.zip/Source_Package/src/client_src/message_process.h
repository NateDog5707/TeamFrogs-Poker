/* message_process.h */

#ifndef MESSAGE_PROCESS_H
#define MESSAGE_PROCESS_H

#include <gtk/gtk.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "player.h"
#include "global_variables.h"

// used after the function init_communication_session to make changes to the gui and data based on server's message
void execute_server_message();

// parsing server messages
void message_processing(char **parsed);

// showing community cards
void community_preflop();    // no cards shown
void community_flop();   // first three community cards shown
void community_turn(); // fourth community card shown
void community_river();  // fifth community card shown

// dealing pocket cards
void deal_pocket();

// updating pots
void update_player_pot(player_widget_t *player, int amount);
void update_main_pot(int amount);

// actions
void action_fold(int player_num);
void action_call(int player_num);
void action_raise(int player_num, int amount);
void action_check(int player_num);

// requests
void request_seat(player_t *player, int seat_number);
void request_leave(player_t *player);

// converts string into int (for amounts, etc.)
int convertToInt(char *num);


#endif