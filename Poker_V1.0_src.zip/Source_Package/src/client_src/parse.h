#include <stdio.h>
#include <string.h>


#ifndef PARSE_H
    #define PARSE_H


    //GLOBAL VARS
    // extern char** parsed;   //array of parsed strings, can be changed to hold more or less words.


    //parses a string(buffer) w/ delimineters as space ONLY. returns the list of parsed strings in 2nd parameter (which is a global var)
    char** parseString(char* buffer, char** parsed);

    // initialize the object for the parsed message before using the parseString
		char** mallocParsed(char** parsed);
    // delete the object of the parsed message
		void freeParsed(char** parsed);

#endif