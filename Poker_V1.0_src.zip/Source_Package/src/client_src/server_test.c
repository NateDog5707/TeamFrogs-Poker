#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include <time.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <assert.h>

/*** global variables ****************************************************/

const char *Program	/* program name for descriptive diagnostics */
	= NULL;
int Shutdown = 0;		/* keep running until Shutdown == 1 */
char ClockBuffer[26] = "";	/* current time in printable format */
char MessageBuffer[26] = "";

/*** global function declarations ****************************************************/

void FatalError(const char *ErrorMsg);		/* print error diagnostics and abort */

int MakeServerSocket(uint16_t PortNo);		/* create a socket on this server */

void PrintCurrentTime(void); /*  print/update the current real time */

void PrintTimeOutMessage(void);

void ProcessRequest(int DataSocketFD); /* process a time request by a client */

// ServSocketFD = server socket to wait on Timeout = timeout in microseconds
void ServerMainLoop(int ServSocketFD, int Timeout);

int main(int argc, char *argv[])
{
    int ServSocketFD;
    int PortNo;

    Program = argv[0];	/* publish program name (for diagnostics) */
    #ifdef DEBUG
        printf("%s: Starting...\n", Program);
    #endif

    if (argc < 2)
    {   
        fprintf(stderr, "Usage: %s port\n", Program);
	    exit(10);
    }
    PortNo = atoi(argv[1]);	/* get the port number */
    if (PortNo <= 2000)
    {   
        fprintf(stderr, "%s: invalid port number %d, should be >2000\n", Program, PortNo);
        exit(10);
    }
    #ifdef DEBUG
        printf("%s: Creating the server socket...\n", Program);
    #endif
    ServSocketFD = MakeServerSocket(PortNo);
    printf("%s: Waiting for connection at port %d...\n", Program, PortNo);
    ServerMainLoop(ServSocketFD, 250000);
    printf("\n%s: Shutting down.\n", Program);
    close(ServSocketFD);
    return 0;
}

void FatalError(const char *ErrorMsg) /* print error diagnostics and abort */
{
    fputs(Program, stderr);
    fputs(": ", stderr);
    perror(ErrorMsg);
    fputs(Program, stderr);
    fputs(": Exiting!\n", stderr);
    exit(20);
} /* end of FatalError */

int MakeServerSocket(uint16_t PortNo) /* create a socket on this server */
{
    int ServSocketFD;
    struct sockaddr_in ServSocketName;

    /* create the socket */
    ServSocketFD = socket(PF_INET, SOCK_STREAM, 0);
    if (ServSocketFD < 0)
    {   FatalError("service socket creation failed");
    }
    /* bind the socket to this server */
    ServSocketName.sin_family = AF_INET;
    ServSocketName.sin_port = htons(PortNo);
    ServSocketName.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(ServSocketFD, (struct sockaddr*)&ServSocketName,
		sizeof(ServSocketName)) < 0)
    {   FatalError("binding the server to a socket failed");
    }
    /* start listening to this socket */
    if (listen(ServSocketFD, 5) < 0)	/* max 5 clients in backlog */
    {   FatalError("listening on socket failed");
    }
    return ServSocketFD;
} /* end of MakeServerSocket */

void PrintCurrentTime(void)	/*  print/update the current real time */
{
    time_t CurrentTime; /* seconds since 1970 (see 'man 2 time') */
    char   *TimeString;	/* printable time string (see 'man ctime') */
    char   Wheel,
	   *WheelChars = "|/-\\";
    static int WheelIndex = 0;

    CurrentTime = time(NULL);	/* get current real time (in seconds) */
    TimeString = ctime(&CurrentTime);	/* convert to printable format */
    strncpy(ClockBuffer, TimeString, 25);
    ClockBuffer[24] = 0;	/* remove unwanted '/n' at the end */
    WheelIndex = (WheelIndex+1) % 4;
    Wheel = WheelChars[WheelIndex];
    printf("\rClock: %s %c",	/* print from beginning of current line */
	ClockBuffer, Wheel);	/* print time plus a rotating wheel */
    fflush(stdout);
} /* end of PrintCurrentTime */

void PrintTimeOutMessage(void)
{
    char   Wheel;
	char *WheelChars = "|/-\\";
    static int WheelIndex = 0;
    MessageBuffer[25] = 0;
    WheelIndex = (WheelIndex+1) % 4;
    Wheel = WheelChars[WheelIndex];
    printf("\rIdling...%c", Wheel);
    fflush(stdout);
}

void ProcessRequest(int DataSocketFD) /* process a time request by a client */
{
    int  l, n;
    char RecvBuf[256];	/* message buffer for receiving a message */
    char SendBuf[256];	/* message buffer for sending a response */

    n = read(DataSocketFD, RecvBuf, sizeof(RecvBuf)-1);
    if (n < 0) 
    {   FatalError("reading from data socket failed");
    }
    RecvBuf[n] = 0;
    #ifdef DEBUG
        printf("%s: Received message: %s\n", Program, RecvBuf);
    #endif
    
    if (0 == strcmp(RecvBuf, "SHUTDOWN"))
    {   
        Shutdown = 1;
        strncpy(SendBuf, "OK SHUTDOWN", sizeof(SendBuf)-1);
        SendBuf[sizeof(SendBuf)-1] = 0;
    }
    else
    {   
        strncpy(SendBuf, "ERROR unknown command ", sizeof(SendBuf)-1);
        SendBuf[sizeof(SendBuf)-1] = 0;
        strncat(SendBuf, RecvBuf, sizeof(SendBuf)-1-strlen(SendBuf));
    }
    
    l = strlen(SendBuf);
    
    #ifdef DEBUG
        printf("%s: Sending response: %s.\n", Program, SendBuf);
    #endif
    n = write(DataSocketFD, SendBuf, l);
    if (n < 0)
    {   
        FatalError("writing to data socket failed");
    }
} /* end of ProcessRequest */

void ServerMainLoop(int ServSocketFD, int Timeout)			
{
    int DataSocketFD;	/* socket for a new client */
    socklen_t ClientLen;
    struct sockaddr_in
	ClientAddress;	/* client address we connect with */
    fd_set ActiveFDs;	/* socket file descriptors to select from */
    fd_set ReadFDs;	/* socket file descriptors ready to read from */
    struct timeval TimeVal;
    int res, i;

    FD_ZERO(&ActiveFDs);		/* set of active sockets */
    FD_SET(ServSocketFD, &ActiveFDs);	/* server socket is active */
    
    while(!Shutdown)
    {   
        ReadFDs = ActiveFDs;
        TimeVal.tv_sec  = Timeout / 1000000;	/* seconds */
        TimeVal.tv_usec = Timeout % 1000000;	/* microseconds */
        
        /* block until input arrives on active sockets or until timeout */
        res = select(FD_SETSIZE, &ReadFDs, NULL, NULL, &TimeVal);
        if (res < 0)
        {   
            FatalError("wait for input or timeout (select) failed");
        }
        
        if (res == 0)	/* timeout occurred */
        {
            #ifdef DEBUG
                printf("Handling timeout\n");
            #endif
            PrintTimeOutMessage();
        }
        else		/* some FDs have data ready to read */
        {   for(i=0; i<FD_SETSIZE; i++)
            {   
                if (FD_ISSET(i, &ReadFDs))
                {   
                    if (i == ServSocketFD)
                    {	
                        /* connection request on server socket */
                        #ifdef DEBUG
                            printf("%s: Accepting new client %d...\n", Program, i);
                        #endif
                        
                        ClientLen = sizeof(ClientAddress);
                        DataSocketFD = accept(ServSocketFD, (struct sockaddr*)&ClientAddress, &ClientLen);
                        
                        if (DataSocketFD < 0)
                        {   
                            FatalError("data socket creation (accept) failed");
                        }

                        #ifdef DEBUG
                            printf("%s: Client %d connected from %s:%hu.\n",
                            Program, i,
                            inet_ntoa(ClientAddress.sin_addr),
                            ntohs(ClientAddress.sin_port));
                        #endif

                        FD_SET(DataSocketFD, &ActiveFDs);
                    }
                    else
                    {   /* active communication with a client */
                        #ifdef DEBUG
                        printf("%s: Dealing with client %d...\n", Program, i);
                        #endif
                        ProcessRequest(i);
                        #ifdef DEBUG
                        printf("%s: Closing client %d connection.\n", Program, i);
                        #endif
                        close(i);
                        FD_CLR(i, &ActiveFDs);
                    }
                }
            }
        }
    }
} /* end of ServerMainLoop */