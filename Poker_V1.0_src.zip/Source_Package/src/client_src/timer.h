/* timer.h */

#ifndef TIMER_H

    #define TIMER_H

    #include <time.h>
    #include <stdbool.h>

    typedef struct timer_type{
        clock_t time_initial;
        clock_t time_final;
        double elapsed_time;
        double time_limit; // time_limit will be in seconds
    } timer_type;

    // initializes a timer object
    timer_type *init_timer(double time_limit);

    // deallocates a timer object
    void delete_timer(timer_type *timer);

    // updates timer
    // specifically, it updates the attributes: time_final and elapsed_time
    void update_timer(timer_type *timer);

    // returns true if timer is finished, returns false if timer is still in progress
    _Bool timer_is_finished(timer_type *timer);

    // resets the timer
    // specifically, it updates the attributes: time_initial = time(NULL), time_final = time(NULL) at the same time, and elapsed_time = 0
    void reset_timer(timer_type *timer);

    void enable_high_frequency_state_for_idle_timer();

    void disable_high_frequency_state_for_idle_timer();

#endif