#include "Buffer.h"
#include <string.h>  
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

typedef struct messageEntry messageEntry;

//GLOBAL VAR DEFINITIONS

t_messageList* queueOne = NULL;
t_messageList* queueTwo = NULL;
t_messageList* queueThree = NULL;
t_messageList* queueFour = NULL;

char poppedMessage2[16];


void appendMessage(t_messageList *list, char *message) //void
{

  assert(list);
  t_message* temp1 = list->First;
  for(int i = 0; i < list->Length; i++){
  	printf("first print Message in queue: %s\n", temp1->Message);

  	temp1 = temp1->Next;
  }
  t_message* the = createMessageEntry(message); // dont look here
  assert(the);

  
  printf("the message in Buffer.c : %s\n", the->Message);
  
  the->List = list;
  the->Next = NULL;

  if(list->Last != NULL) //if there is an entry already inside the queue
  {
    list->Last->Next = the;
    the->Prev = list->Last;
    list->Last = the;
  }
  else //if there is no entry inside the queue
  {
    list->First = the;
    list->Last = the;
  }
  list->Length++;
  
  assert(list->Last->Message);
  printf("Appended message to queue: \"%s\"\n", list->Last->Message);
  printf("this should be the same: %s\n", the->Message);
  //debug, print the entire list
  printf("Length of the queue: %d\n", list->Length);
  t_message* temp = list->First;
  while (temp != NULL){
  	printf("Message in queue: %s\n", temp->Message);

  	temp = temp->Next;
  }
  
}

void appendMessageAll(char *message){
	assert(queueOne);
	assert(queueTwo);
	assert(queueThree);
	assert(queueFour);
	
	printf("adding to queue 1\n");
	appendMessage(queueOne, message);
	printf("adding to queue 2\n");
	appendMessage(queueTwo, message);
	printf("adding to queue 3\n");
	appendMessage(queueThree, message);
	printf("adding to queue 4\n");
	appendMessage(queueFour, message);
}

char* popMessage(t_messageList *list)
{
	char* poppedMessage = "";
	assert(list);
	//assert(list->First);
	if (list->First != NULL){
		t_message* temp = list->First;
		
		poppedMessage = temp->Message; 
    printf("poppedMessage in Buffer.c: %s\n", poppedMessage);
	printf("Length of the queue: %d\n", list->Length);
		
	  if(list->First->Next != NULL) // if there is another item in the list
	  {
	    list->First = list->First->Next;
	    list->First->Prev = NULL;
	  }
	  else // if this item is the only item in the list
	  {
	  	list->First = NULL;
			list->Last = NULL;
	  }
	  list->Length--;
		
		temp->Next = NULL;
		temp = NULL;
		
		//free(temp);
		//	assert(!temp);
		
		printf("inside popMessage: something to send back!\n");
	}
	else{ //if the list FIRST is NULL
		printf("inside popMessage: nothing to send back! Sending back \"NOUPDATE\".\n");
		strcpy(poppedMessage2, "NOUPDATE");
		//printf("hello\n");
		return poppedMessage2;
	}
	
	
	return poppedMessage;
  
}

t_message *createMessageEntry(char *message)
{
	t_message *newMessageEntry = (t_message *)malloc(sizeof(t_message));

	newMessageEntry->Message = malloc(sizeof(char) * 50);
	strcpy(newMessageEntry->Message, message);

	newMessageEntry->Next = NULL;
	newMessageEntry->Prev = NULL;
	newMessageEntry->List = NULL;
	return newMessageEntry;
}

t_messageList *createMessageList()
{
	t_messageList *list = (t_messageList *)malloc(sizeof(t_messageList));	
	list->First = NULL;
	list->Last = NULL;
	list->Length = 0;
 return list;
}

void deleteMessageEntry(t_message *message)
{
  assert(message);
  message->Prev = NULL;
  message->Next = NULL;
  message->Message = NULL;
  message->List = NULL;
	free(message);
  message = NULL;
}

void deleteMessageList(t_messageList *list)
{
	assert(list);
 t_message *iterator = list->First;
 t_message *next = NULL;
  while(iterator)
	{
		next = iterator->Next;
		deleteMessageEntry(iterator);
    iterator = next;
	}
 list->Length = 0;
 list->First = NULL;
 list->Last = NULL;  
	free(list);
}
/*
void print_messages_in_queue(t_messageList *message_list)
{
	printf("Printing all the messages in queue: ");

	messageEntry *current_message_entry = message_list->First;
  	while (current_message_entry != NULL){
		printf("\nMessage: %s", current_message_entry->Message);
		current_message_entry =current_message_entry->Next;
  	}

	printf("Printing addresses pointed to by the pointers");

	messageEntry *current_message_entry = message_list->First;
  	while (current_message_entry != NULL){
		printf("\nMessage pointer: %p", current_message_entry->Message);
		current_message_entry =current_message_entry->Next;
  	}
}
*/
/*
void cardToWrite(char* SendBuf, int shuffledIndex){
	printf("ayo we in cardToWrite\n");
	//use switch case to determine what card needs to show up
	//"CARD [RANK] [SUIT]"
	//rn it's "CARD "
	int pain_count = 1;
printf("shuffled length = %d\n", shuffled->Length);
	assert(shuffled);
printf("A\n");
	t_cardEntry *curr = shuffled->First;
	assert(curr);
printf("B\n");
	while (pain_count < shuffledIndex){
		assert(curr->Next);
		curr = curr->Next;
		pain_count++;
	}
printf("C\n");
	switch (curr->Card->rank){
		case 2:
			strcat(SendBuf, "TWO ");
			break;
		case 3:
			strcat(SendBuf, "THREE ");
			break;
		case 4:
			strcat(SendBuf, "FOUR ");
			break;
		case 5:
			strcat(SendBuf, "FIVE ");
			break;
		case 6:
			strcat(SendBuf, "SIX ");
			break;
		case 7:
			strcat(SendBuf, "SEVEN ");
			break;
		case 8:
			strcat(SendBuf, "EIGHT ");
			break;
		case 9:
			strcat(SendBuf, "NINE ");
			break;
		case 10:
			strcat(SendBuf, "TEN ");
			break;
		case 11:
			strcat(SendBuf, "JACK ");
			break;
		case 12:
			strcat(SendBuf, "QUEEN ");
			break;
		case 13:
			strcat(SendBuf, "KING ");
			break;
		case 14:
			strcat(SendBuf, "ACE ");
			break;
	}//switch rank end
	
	switch(curr->Card->suit){
		case 1:
			strcat(SendBuf, "SPADES");
			break;
		case 2:
			strcat(SendBuf, "DIAMONDS");
			break;
		case 3:
			strcat(SendBuf, "HEARTS");
			break;
		case 4:
			strcat(SendBuf, "CLUBS");
			break;
	}//switch suit end
	
}
*/
