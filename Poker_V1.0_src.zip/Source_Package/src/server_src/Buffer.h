#ifndef BUFFER_H
#define BUFFER_H

typedef struct messageEntry
  t_message;
  
typedef struct messageList
  t_messageList;
  
struct messageEntry
{
  t_messageList *List;
  t_message *Prev;
  t_message *Next;
  char *Message;
};

struct messageList
{
  int Length;
  t_message *First;
  t_message *Last;
};

//GLOBAL VARS, FOUR MESSAGELISTS FOR FOUR BUFFERS

extern t_messageList* queueOne;
extern t_messageList* queueTwo;
extern t_messageList* queueThree;
extern t_messageList* queueFour;

 extern char poppedMessage2[16];

void appendMessage(t_messageList *list, char *messageEntry);
void appendMessageAll(char *message);
char* popMessage(t_messageList *list);
t_message *createMessageEntry(char *message);
t_messageList *createMessageList();
void deleteMessageList(t_messageList *list);
void deleteMessageEntry(t_message *message);
void print_messages_in_queue(t_messageList *message_list);

//void cardToWrite(char* SendBuf, int shuffledIndex);
#endif
