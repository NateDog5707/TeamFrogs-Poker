#include "Identify_hand.h"
#include "List_of_cards.h"

#include <stdio.h>

int flush(t_player *player, t_cardList *list) 
{

  int clubs = 0;
  int hearts = 0;
  int diamonds = 0;
  int spades = 0;
  
  int highCard = 0;
  sortByRank(list);
  
  t_cardEntry *iterator = list->First;
  while(iterator != NULL)
  {
    switch(iterator->Card->suit)
    {
      case CLUBS:
        clubs++;
        if(clubs >= 5)
        {
        		player->Hand = Flush;
	        	highCard = iterator->Card->rank;
        }
      	break;
      case HEARTS:
        hearts++;
        if(hearts >= 5)
        {
        		player->Hand = Flush;
	        	highCard = iterator->Card->rank;
        }
      	break;
      case DIAMONDS:
        diamonds++;
        if(diamonds >= 5)
        {
        		player->Hand = Flush;
	        	highCard = iterator->Card->rank;
        }
      	break;
      case SPADES:
        spades++;
        if(spades >= 5)
        {
        		player->Hand = Flush;
	        	highCard = iterator->Card->rank;
        }
      	break;
    }
    iterator = iterator->Next;
  }
  
  return highCard;
}

int royalFlush(t_player *player, t_cardList *list) 
{
  int clubs = 0;
  int hearts = 0;
  int diamonds = 0;
  int spades = 0;
  sortByRank(list);
  
  t_cardEntry *iterator = list->First;
  
  while(iterator != NULL)
  {
    switch(iterator->Card->suit)
    {
      case CLUBS:
        clubs++;
      	break;
      case HEARTS:
        hearts++;
      	break;
      case DIAMONDS:
        diamonds++;
      	break;
      case SPADES:
        spades++;
      	break;
    }
    iterator = iterator->Next;
  }
  

  iterator = list->First;
  if(clubs == 5 || hearts == 5 || diamonds == 5 || spades == 5)
	{
		
		int checkForStraight = 0;
		if(clubs == 5)
		{
			while(iterator != NULL)
			{
				if(iterator->Card->suit == CLUBS)
				{
					//nathan: this works if we are only playing with 1 deck cuz there is no case for duplicates
					if(iterator->Card->rank == 10 || iterator->Card->rank == JACK || iterator->Card->rank == QUEEN || iterator->Card->rank == KING || iterator->Card->rank == ACE) 
					{ 
						checkForStraight++;
    	          if(checkForStraight == 5)
	            	{
	            		player->Hand = Royal_Flush;
          		  	return iterator->Card->rank;
	            	}   
					}
				}
			  iterator = iterator->Next;
			}	
		}
		else if(hearts == 5)
		{
      while(iterator != NULL)
			{
				if(iterator->Card->suit == HEARTS)
				{
					if(iterator->Card->rank == 10 || iterator->Card->rank == JACK || iterator->Card->rank == QUEEN || iterator->Card->rank == KING || iterator->Card->rank == ACE)
					{
						checkForStraight++;
   		          if(checkForStraight == 5)
	            	{
	            		player->Hand = Royal_Flush;
          		  	return iterator->Card->rank;
	            	}   
					}
				}
			  iterator = iterator->Next;
			}	
		}
		else if(diamonds == 5)
		{
      while(iterator != NULL)
			{
				if(iterator->Card->suit == DIAMONDS)
				{
					if(iterator->Card->rank == 10 || iterator->Card->rank == JACK || iterator->Card->rank == QUEEN || iterator->Card->rank == KING || iterator->Card->rank == ACE)
					{
						checkForStraight++;
   		          if(checkForStraight == 5)
	            	{
	            		player->Hand = Royal_Flush;
          		  	return iterator->Card->rank;
	            	}   
					}
				}
			  iterator = iterator->Next;
			}	
		}
		else if(spades == 5)
		{
      while(iterator != NULL)
			{
				if(iterator->Card->suit == SPADES)
				{
					if(iterator->Card->rank == 10 || iterator->Card->rank == JACK || iterator->Card->rank == QUEEN || iterator->Card->rank == KING || iterator->Card->rank == ACE)
					{
						checkForStraight++;
            		if(checkForStraight == 5)
	            	{
	            		player->Hand = Royal_Flush;
          		  	return iterator->Card->rank;
	            	}                        
					}
				}
			  iterator = iterator->Next;
			}	
		}



	}
	return 0;
}

int straightFlush(t_player *player, t_cardList *list)
{
  sortByRank(list);
  int clubs = 0;
  int hearts = 0;
  int diamonds = 0;
  int spades = 0;
  
  int highCard = 0;
  
  t_cardEntry *iterator = list->First;
  while(iterator != NULL)
  {
    switch(iterator->Card->suit)
    {
      case CLUBS:
        clubs++;
      	break;
      case HEARTS:
        hearts++;
      	break;
      case DIAMONDS:
        diamonds++;
      	break;
      case SPADES:
        spades++;
      	break; 
    }
    iterator = iterator->Next;
  }
  //^ flush check
  
  iterator = list->First;
  if(clubs == 5 || hearts == 5 || diamonds == 5 || spades == 5)
	{
		int rank = list->First->Card->rank;
		int counter = 1;
		if(clubs == 5)
		{
	while(iterator->Next != NULL)
	{
		if(rank != iterator->Next->Card->rank && iterator->Next->Card->suit == CLUBS)
		{
			if((rank+1) == iterator->Next->Card->rank)
			{
			  counter++;
     	  if(counter >= 5)
      	{
		      player->Hand = Straight_Flush;
          highCard = iterator->Next->Card->rank;
	      }
			}
      else
      {
        counter = 1;
      }
		}
   if(iterator->Next->Card->suit == CLUBS)
   {
    rank = iterator->Next->Card->rank;
   }
		iterator = iterator->Next;
	}
		}
		
		else if(hearts == 5)
		{
	while(iterator->Next != NULL)
	{
		if(rank != iterator->Next->Card->rank && iterator->Next->Card->suit == HEARTS)
		{
			if((rank+1) == iterator->Next->Card->rank)
			{
			  counter++;
     	  if(counter >= 5)
      	{
		      player->Hand = Straight_Flush;
          highCard = iterator->Next->Card->rank;
	      }
			}
      else
      {
        counter = 1;
      }
		}
   if(iterator->Next->Card->suit == HEARTS)
   {
    rank = iterator->Next->Card->rank;
   }
		iterator = iterator->Next;
	}
		}
		
		else if(diamonds == 5)
		{
	while(iterator->Next != NULL)
	{
		if(rank != iterator->Next->Card->rank && iterator->Next->Card->suit == DIAMONDS)
		{
			if((rank+1) == iterator->Next->Card->rank)
			{
			  counter++;
     	  if(counter >= 5)
      	{
		      player->Hand = Straight_Flush;
          highCard = iterator->Next->Card->rank;
	      }
			}
      else
      {
        counter = 1;
      }
		}
   if(iterator->Next->Card->suit == DIAMONDS)
   {
    rank = iterator->Next->Card->rank;
   }
		iterator = iterator->Next;
	}	
		}
		else if(spades == 5)
		{
	while(iterator->Next != NULL)
	{
		if(rank != iterator->Next->Card->rank && iterator->Next->Card->suit == SPADES)
		{
			if((rank+1) == iterator->Next->Card->rank)
			{
			  counter++;
     	  if(counter >= 5)
      	{
		      player->Hand = Straight_Flush;
          highCard = iterator->Next->Card->rank;
	      }
			}
      else
      {
        counter = 1;
      }
		}
   if(iterator->Next->Card->suit == SPADES)
   {
    rank = iterator->Next->Card->rank;
   }
		iterator = iterator->Next;
	}
 }
}
	return highCard;
}

int fourOfAKind(t_player *player, t_cardList *list)
{
  sortByRank(list);
  int rank = list->First->Card->rank;
  t_cardEntry* iterator = list->First;
  int highCard = 0;
  int counter = 0;
  while(iterator != NULL)
  {
    if(rank == iterator->Card->rank)
    {
      counter++;
  		if(counter == 4)
      {
		    player->Hand = Four_of_a_Kind;
		    highCard = iterator->Card->rank;
 	    }
    }
    else
    {
      counter = 1;
      rank = iterator->Card->rank;
    }
    iterator = iterator->Next;
  }
  return highCard;
} // EOF fourOfAKind

int fullHouse(t_player *player, t_cardList *list) //OK
{
  sortByRank(list);
  int rank = list->First->Card->rank;
  t_cardEntry* iterator = list->First;
  int counter = 0;
  int two = 0;
  int three = 0;
  int highThree = 0;
  int tempThree = 0;

  while(iterator != NULL)
  {
    if(rank == iterator->Card->rank)
    {
      counter++;
	if(counter == 2)
      {
        two++;
 	    }
      if(counter == 3)
      {
        three++;
        highThree = iterator->Card->rank;
        if(tempThree == 0)
        {
          tempThree = highThree;
        }
        
        if(highThree < tempThree)
        {
          highThree = tempThree;
        }
	    }
    }
    else
    {
      counter = 1;
      rank = iterator->Card->rank;
    }
    iterator = iterator->Next;
  }
  
  if(two >= 2 && three >= 1)
  {
    player->Hand = Full_House;
    return highThree;
  }

  return 0;
}//EOF fullHouse returns highest triple

int straight(t_player *player, t_cardList *list)
{
  sortByRank(list);
	t_cardEntry *iterator = list->First;
	int rank = list->First->Card->rank;
	int counter = 1;
  int highCard = 0;
	while(iterator->Next != NULL)
	{
		if(rank != iterator->Next->Card->rank)
		{
			if((rank+1) == iterator->Next->Card->rank)
			{
			  counter++;
     	  if(counter >= 5)
      	{
		      player->Hand = Straight;
          highCard = iterator->Next->Card->rank;
	      }
			}
      else
      {
        counter = 1;
      }
      rank = iterator->Next->Card->rank;
		}
		iterator = iterator->Next;
	}
 return highCard;
}

int threeOfAKind(t_player *player, t_cardList *list)
{
   sortByRank(list);
  int rank = list->First->Card->rank;
  t_cardEntry* iterator = list->First;
  int counter = 0;
  int highCard = 0;
  
  while(iterator != NULL)
  {
    if(rank == iterator->Card->rank)
    {
      counter++;
  		if(counter == 3)
      {
		    player->Hand = Three_of_a_Kind;
		    highCard = iterator->Card->rank;
 	    }
    }
    else
    {
      counter = 1;
      rank = iterator->Card->rank;
    }
    iterator = iterator->Next;
  }
  return highCard;
}

int twoPair(t_player *player, t_cardList *list)//OK
{
  sortByRank(list);
  t_cardEntry* iterator = list->First;
  int two = 0;
  int highCard = 0;
  
  while(iterator->Next != NULL)
  {
	  if(iterator->Card->rank == iterator->Next->Card->rank)
	  {
	  	two++;
        if(two >= 2)
        {
          player->Hand = Two_Pair;
          highCard = iterator->Card->rank;
        }
  	}
  	iterator = iterator->Next;
  }
  
  return highCard;
}  

int pair(t_player *player, t_cardList *list) //OK
{  
  sortByRank(list);
//  int rank = list->First->Card->rank;
  t_cardEntry* iterator = list->First;
//  int counter = 0;
  int highCard = 0;
  
  while(iterator->Next != NULL)
  {
	if(iterator->Card->rank == iterator->Next->Card->rank)
	{
//		counter = 0;
//    rank = iterator->Card->rank;
    player->Hand = One_Pair;
    highCard = iterator->Next->Card->rank;
	}
	iterator = iterator->Next;
  }
  return highCard;
}  

int highCard(t_player *player, t_cardList *list)
{
  sortByRank(list);
  player->Hand = High_Card;
  return list->Last->Card->rank;
}

void identifyHand(t_player *player, t_cardList *list)
{
  highCard(player, list);
  pair(player, list);
  twoPair(player, list);
  threeOfAKind(player, list);
  straight(player, list);
  flush(player, list);
  fullHouse(player, list);
  fourOfAKind(player, list);  
  straightFlush(player, list);
  royalFlush(player,list);
}

int twoPair_lowPairRank(t_cardList *list)
{
  sortByRank(list);
//  int rank = list->First->Card->rank;
  t_cardEntry* iterator = list->First;
//  int counter = 0;
  while(iterator->Next != NULL)
  {
	if(iterator->Card->rank == iterator->Next->Card->rank)
	{
//		counter = 0;
//    rank = iterator->Card->rank;
    return iterator->Next->Card->rank;
	}
	iterator = iterator->Next;
  }
  return 0;

}

int pairNotThree(t_cardList *list) 
{  
  sortByRank(list);
//  int rank = list->First->Card->rank;
  t_cardEntry* iterator = list->First;
  int highCard = 0;
  while(iterator->Next != NULL)
  {
	if(iterator->Card->rank == iterator->Next->Card->rank)
	{
    if(iterator->Next->Next != NULL)
    {
      if(iterator->Next->Next->Card->rank != iterator->Card->rank)
      {
//        rank = iterator->Card->rank;
        highCard = iterator->Next->Card->rank;
      }
    }
	}
	iterator = iterator->Next;
  }
  return highCard;
}  

t_cardList* determineKickerCards(t_player *player, t_cardList *list)
{
  sortByRank(list);
  t_cardList *kickerList = createList();
  t_cardEntry *kicker = NULL;
  switch(player->Hand)
  {
    case Undefined:;
      return NULL;
      break;
    case Royal_Flush:;
      return NULL;
    	break;
    case Straight_Flush:;
      return NULL;
    	break;
    case Four_of_a_Kind:;
      int fourKind = fourOfAKind(player, list);
      kicker = list->Last;
      while(kicker != NULL)
      {
        if(kicker->Card->rank != fourKind)
        {
          t_cardEntry *kC = createCardEntry(kicker->Card);
          appendCard(kickerList, kC);
          return kickerList;
        }
        kicker = kicker->Prev;
      }
      return NULL; //Will only occur if function does not work correctly    
    	break;
    case Full_House:;
      return NULL;
    	break;
    case Flush:;
      return NULL;
    	break;
    case Straight:;
      return NULL;
    	break;
    case Three_of_a_Kind:;
      int threeKind = threeOfAKind(player, list);
      kicker = list->Last;
      while(kicker != NULL)
      {
        if(kicker->Card->rank != threeKind)
        {
          t_cardEntry *kC = createCardEntry(kicker->Card);
          appendCard(kickerList, kC);
          if(kickerList->Length == 2)
          {
            return kickerList;
          }
        }
        kicker = kicker->Prev;
      }
      return kickerList;
    	break;
    case Two_Pair:;
         int highTwoPair = twoPair(player, list);
         int lowTwoPair = twoPair_lowPairRank(list);
      kicker = list->Last;
      while(kicker != NULL)
      {
        if(kicker->Card->rank != highTwoPair && kicker->Card->rank != lowTwoPair)
        {
          t_cardEntry *kC = createCardEntry(kicker->Card);
          appendCard(kickerList, kC);
            return kickerList;
        }
        kicker = kicker->Prev;
      }
      return kickerList;
    	break;
    case One_Pair:;
      int highPair = pair(player, list);
      kicker = list->Last;
      while(kicker != NULL)
      {
        if(kicker->Card->rank != highPair)
        {
          t_cardEntry *kC = createCardEntry(kicker->Card);
          appendCard(kickerList, kC);
          if(kickerList->Length == 3)
          {
            return kickerList;
          }
        }
        kicker = kicker->Prev;
      }
      return kickerList;
    	break;
    case High_Card:;
      kicker = list->Last;
      while(kicker != NULL)
      {
        t_cardEntry *kC = createCardEntry(kicker->Card);
        appendCard(kickerList, kC);
          if(kickerList->Length == 5)
          {
            return kickerList;
          }
          kicker = kicker->Prev;
      }
    break;
  }
  return NULL;
}

int compareHighest(t_cardList *list1, t_cardList *list2)//does not acccount for repeated ranks
{
    sortByRank(list1);
    sortByRank(list2);
   t_cardEntry* iterator1 = list1->Last;
   t_cardEntry* iterator2 = list2->Last;
  int length = list1->Length;
  int numbersToCheck = list1->Length;
  int listLength = list1->Length;
  while(iterator1 != NULL)
  {
    if(iterator1->Card->rank == iterator2->Card->rank)
    {
      length--;
      //printf("deck 1: %d deck 2: %d Length: %d", iterator1->Card->rank, iterator2->Card->rank, length);
    }
    iterator2 = iterator2->Prev;
    iterator1 = iterator1->Prev;
  }
  
  iterator1 = list1->Last;
  iterator2 = list2->Last;
  while(iterator1 != NULL)
  {
    if(numbersToCheck >= listLength)
    {
      if(iterator1->Card->rank > iterator2->Card->rank)
      {
        return 1;
      }
      else if(iterator1->Card->rank < iterator2->Card->rank)
      {
        return 2;
      }
    }
    listLength--;
    iterator1 = iterator1->Prev;
    iterator2 = iterator2->Prev;
  }
  return 0; 
}

int compareHand(t_player *player1, t_player *player2, t_cardList *list1, t_cardList *list2)
{
  sortByRank(list1);
  sortByRank(list2);
  int p1High = 0;
  int p2High = 0;
  int compareHighHand = 0;
  int compareHighCard = 0;
  t_cardList* p1Kickers = createList();
  t_cardList* p2Kickers = createList();
  switch(player1->Hand)
  {
    case Undefined:
      return -1;
      break;
    case Royal_Flush:
      return 0;
      break;
    case Straight_Flush:
      p1High = straightFlush(player1, list1);
      p2High = straightFlush(player2, list2);
      compareHighHand = comparing(p1High, p2High);
      if( compareHighHand == 1 || compareHighHand == 2)
      {
        return compareHighHand;
      }
      else//equal flush
      {
        return 0;
      }
      break;
    case Four_of_a_Kind:
      p1High = fourOfAKind(player1, list1);
      p2High = fourOfAKind(player2, list2);
      compareHighHand = comparing(p1High, p2High);
      if( compareHighHand == 1 || compareHighHand == 2)
      {
        return compareHighHand;
      }
      else
      {
        p1Kickers = determineKickerCards(player1, list1);
        p2Kickers = determineKickerCards(player2, list2);
        compareHighCard = compareHighest(p1Kickers, p2Kickers);
        return compareHighCard;
      }
      break;
    case Full_House:
      //compare triple threeOfAKind(p1, list) threeOfAKind(p2, list)
      p1High = threeOfAKind(player1, list1);
      p2High = threeOfAKind(player2, list2);
      compareHighHand = comparing(p1High, p2High);
      if(compareHighHand == 1 || compareHighHand == 2)
      {
        player1->Hand = Full_House;
        player2->Hand = Full_House;
        return compareHighHand; 
      }
      //compare double
      p1High = pairNotThree(list1);
      p2High = pairNotThree(list2);
      compareHighHand = comparing(p1High, p2High);
      if(compareHighHand == 1 || compareHighHand == 2)
      {
        player1->Hand = Full_House;
        player2->Hand = Full_House;
        return compareHighHand; 
      }
        return 0;
      break;
    case Flush: 
      p1High = flush(player1, list1);
      p2High = flush(player2, list2);
      compareHighHand = comparing(p1High, p2High);
      if( compareHighHand == 1 || compareHighHand == 2)
      {
        return compareHighHand;
      }
      else//equal flush
      {
        return 0;
      }
      break;
    case Straight:
      p1High = straight(player1, list1);
      p2High = straight(player2, list2);
      compareHighHand = comparing(p1High, p2High);
      if( compareHighHand == 1 || compareHighHand == 2)
      {
        return compareHighHand;
      }
      else
      {
        return 0;
      }
      break;
    case Three_of_a_Kind:
      p1High = threeOfAKind(player1, list1);
      p2High = threeOfAKind(player2, list2);
      compareHighHand = comparing(p1High, p2High);
      if( compareHighHand == 1 || compareHighHand == 2)
      {
        return compareHighHand;
      }
        p1Kickers = determineKickerCards(player1, list1);
        p2Kickers = determineKickerCards(player2, list2);
        compareHighCard = compareHighest(p1Kickers, p2Kickers);
        return compareHighCard;
      break;
    case Two_Pair:
      //compare higher pair
      p1High = twoPair(player1, list1);
      p2High = twoPair(player2, list2);
      compareHighHand = comparing(p1High, p2High);
      if( compareHighHand == 1 || compareHighHand == 2)
      {
        return compareHighHand;
      }
      
      p1High = twoPair_lowPairRank(list1);
      p2High = twoPair_lowPairRank(list2);
      compareHighHand = comparing(p1High, p2High);
      if( compareHighHand == 1 || compareHighHand == 2)
      {
        return compareHighHand;
      }
        p1Kickers = determineKickerCards(player1, list1);
        p2Kickers = determineKickerCards(player2, list2);
        compareHighCard = compareHighest(p1Kickers, p2Kickers);
        return compareHighCard;
      break;
    case One_Pair:
      p1High = pair(player1, list1);
      p2High = pair(player2, list2);
      compareHighHand = comparing(p1High, p2High);
      if( compareHighHand == 1 || compareHighHand == 2)//p1 higher flush
      {
        return compareHighHand;
      }
        p1Kickers = determineKickerCards(player1, list1);
        p2Kickers = determineKickerCards(player2, list2);
        compareHighCard = compareHighest(p1Kickers, p2Kickers);
        return compareHighCard;
      break;
    case High_Card:
        p1Kickers = determineKickerCards(player1, list1);
        p2Kickers = determineKickerCards(player2, list2);
        compareHighCard = compareHighest(p1Kickers, p2Kickers);
        return compareHighCard;
      break;
  }
  
  return 0;
}

  int comparing(int p1, int p2)
  {
    if(p1 > p2)
    {
      return 1;
    }
    else if (p1 < p2)
    {
      return 2;
    }
    return 0;
  }
  
  
