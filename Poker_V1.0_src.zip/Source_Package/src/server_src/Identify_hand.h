#include "List_of_cards.h"
#include "Poker_card.h"
#include "Player.h"


#ifndef IDENTIFY_HAND_H
#define IDENTIFY_HAND_H

int royalFlush(t_player *player, t_cardList *list);
int straightFlush(t_player *player, t_cardList *list);
int fourOfAKind(t_player *player, t_cardList *list);
int fullHouse(t_player *player, t_cardList *list);
int flush(t_player *player, t_cardList *list);
int straight(t_player *player, t_cardList *list);
int threeOfAKind(t_player *player, t_cardList *list);
int twoPair(t_player *player, t_cardList *list);
int pair(t_player *player, t_cardList *list);
int highCard(t_player *player, t_cardList *list);

//update the player's enum HAND type to what their best hand type
void identifyHand(t_player *player, t_cardList *list);

//special functions
int pairNotThree(t_cardList *list);
int twoPair_lowPairRank(t_cardList *list);
int compareHighest(t_cardList *list1, t_cardList *list2);
t_cardList* determineKickerCards(t_player *player, t_cardList *list);

int compareHand(t_player *player1, t_player *player2, t_cardList *list1, t_cardList *list2);
int comparing(int p1, int p2);
#endif