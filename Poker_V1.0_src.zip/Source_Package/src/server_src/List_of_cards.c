#include "Poker_card.h"
#include "List_of_cards.h"
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <assert.h>

/* 52 global card objects */
  t_pokerCard twoC = {TWO, CLUBS, false};
  t_pokerCard twoH = {TWO, HEARTS, false};
  t_pokerCard twoS = {TWO, SPADES, false};
  t_pokerCard twoD = {TWO, DIAMONDS, false};
  
  t_pokerCard threeC = {THREE, CLUBS, false};
  t_pokerCard threeH = {THREE, HEARTS, false};
  t_pokerCard threeS = {THREE, SPADES, false};
  t_pokerCard threeD = {THREE, DIAMONDS, false};
  
  t_pokerCard fourC = {FOUR, CLUBS, false};
  t_pokerCard fourH = {FOUR, HEARTS, false};
  t_pokerCard fourS = {FOUR, SPADES, false};
  t_pokerCard fourD = {FOUR, DIAMONDS, false};
  
  t_pokerCard fiveC = {FIVE, CLUBS, false};
  t_pokerCard fiveH = {FIVE, HEARTS, false};
  t_pokerCard fiveS = {FIVE, SPADES, false};
  t_pokerCard fiveD = {FIVE, DIAMONDS, false};
  
  t_pokerCard sixC = {SIX, CLUBS, false};
  t_pokerCard sixH = {SIX, HEARTS, false};
  t_pokerCard sixS = {SIX, SPADES, false};
  t_pokerCard sixD = {SIX, DIAMONDS, false};
  
  t_pokerCard sevenC = {SEVEN, CLUBS, false};
  t_pokerCard sevenH = {SEVEN, HEARTS, false};
  t_pokerCard sevenS = {SEVEN, SPADES, false};
  t_pokerCard sevenD = {SEVEN, DIAMONDS, false};
  
  t_pokerCard eightC = {EIGHT, CLUBS, false};
  t_pokerCard eightH = {EIGHT, HEARTS, false};
  t_pokerCard eightS = {EIGHT, SPADES, false};
  t_pokerCard eightD = {EIGHT, DIAMONDS, false};
  
  t_pokerCard nineC = {NINE, CLUBS, false};
  t_pokerCard nineH = {NINE, HEARTS, false};
  t_pokerCard nineS = {NINE, SPADES, false};
  t_pokerCard nineD = {NINE, DIAMONDS, false};
  
  t_pokerCard tenC = {TEN, CLUBS, false};
  t_pokerCard tenH = {TEN, HEARTS, false};
  t_pokerCard tenS = {TEN, SPADES, false};
  t_pokerCard tenD = {TEN, DIAMONDS, false};
  
  t_pokerCard JC = {JACK, CLUBS, false};
  t_pokerCard JH = {JACK, HEARTS, false};
  t_pokerCard JS = {JACK, SPADES, false};
  t_pokerCard JD = {JACK, DIAMONDS, false};
  
  t_pokerCard QC = {QUEEN, CLUBS, false};
  t_pokerCard QH = {QUEEN, HEARTS, false};
  t_pokerCard QS = {QUEEN, SPADES, false};
  t_pokerCard QD = {QUEEN, DIAMONDS, false};
  
  t_pokerCard KC = {KING, CLUBS, false};
  t_pokerCard KH = {KING, HEARTS, false};
  t_pokerCard KS = {KING, SPADES, false};
  t_pokerCard KD = {KING, DIAMONDS, false};
  
  t_pokerCard AC = {ACE, CLUBS, false};
  t_pokerCard AH = {ACE, HEARTS, false};
  t_pokerCard AS = {ACE, SPADES, false};
  t_pokerCard AD = {ACE, DIAMONDS, false};

t_cardList* createList()
{
	t_cardList *List = (t_cardList *)malloc(sizeof(t_cardList));
	List->First = NULL;
	List->Last = NULL;
	List->Length = 0;

	return List;
}

t_cardList *createInitialDeck()
{
  t_cardList *initDeck = (t_cardList *)malloc(sizeof(t_cardList));
  
  t_cardEntry *twoCI = createCardEntry(&twoC);
  appendCard(initDeck, twoCI);
  t_cardEntry *twoHI = createCardEntry(&twoH);
  appendCard(initDeck, twoHI);
  t_cardEntry *twoSI = createCardEntry(&twoS);
  appendCard(initDeck, twoSI);
  t_cardEntry *twoDI = createCardEntry(&twoD);
  appendCard(initDeck, twoDI);
  
  t_cardEntry *threeCI = createCardEntry(&threeC);
  appendCard(initDeck, threeCI);
  t_cardEntry *threeHI = createCardEntry(&threeH);
  appendCard(initDeck, threeHI);
  t_cardEntry *threeSI = createCardEntry(&threeS);
  appendCard(initDeck, threeSI);
  t_cardEntry *threeDI = createCardEntry(&threeD);
  appendCard(initDeck, threeDI);
  
  t_cardEntry *fourCI = createCardEntry(&fourC);
  appendCard(initDeck, fourCI);
  t_cardEntry *fourHI = createCardEntry(&fourH);
  appendCard(initDeck, fourHI);
  t_cardEntry *fourSI = createCardEntry(&fourS);
  appendCard(initDeck, fourSI);
  t_cardEntry *fourDI = createCardEntry(&fourD);
  appendCard(initDeck, fourDI);
  
  t_cardEntry *fiveCI = createCardEntry(&fiveC);
  appendCard(initDeck, fiveCI);
  t_cardEntry *fiveHI = createCardEntry(&fiveH);
  appendCard(initDeck, fiveHI);
  t_cardEntry *fiveSI = createCardEntry(&fiveS);
  appendCard(initDeck, fiveSI);
  t_cardEntry *fiveDI = createCardEntry(&fiveD);
  appendCard(initDeck, fiveDI);
  
  t_cardEntry *sixCI = createCardEntry(&sixC);
  appendCard(initDeck, sixCI);
  t_cardEntry *sixHI = createCardEntry(&sixH);
  appendCard(initDeck, sixHI);
  t_cardEntry *sixSI = createCardEntry(&sixS);
  appendCard(initDeck, sixSI);
  t_cardEntry *sixDI = createCardEntry(&sixD);
  appendCard(initDeck, sixDI);
  
  t_cardEntry *sevenCI = createCardEntry(&sevenC);
  appendCard(initDeck, sevenCI);
  t_cardEntry *sevenHI = createCardEntry(&sevenH);
  appendCard(initDeck, sevenHI);
  t_cardEntry *sevenSI = createCardEntry(&sevenS);
  appendCard(initDeck, sevenSI);
  t_cardEntry *sevenDI = createCardEntry(&sevenD);
  appendCard(initDeck, sevenDI);

  t_cardEntry *eightCI = createCardEntry(&eightC);
  appendCard(initDeck, eightCI);
  t_cardEntry *eightHI = createCardEntry(&eightH);
  appendCard(initDeck, eightHI);
  t_cardEntry *eightSI = createCardEntry(&eightS);
  appendCard(initDeck, eightSI);
  t_cardEntry *eightDI = createCardEntry(&eightD);
  appendCard(initDeck, eightDI);
  
  t_cardEntry *nineCI = createCardEntry(&nineC);
  appendCard(initDeck, nineCI);
  t_cardEntry *nineHI = createCardEntry(&nineH);
  appendCard(initDeck, nineHI);
  t_cardEntry *nineSI = createCardEntry(&nineS);
  appendCard(initDeck, nineSI);
  t_cardEntry *nineDI = createCardEntry(&nineD);
  appendCard(initDeck, nineDI);
  
  t_cardEntry *tenCI = createCardEntry(&tenC);
  appendCard(initDeck, tenCI);
  t_cardEntry *tenHI = createCardEntry(&tenH);
  appendCard(initDeck, tenHI);
  t_cardEntry *tenSI = createCardEntry(&tenS);
  appendCard(initDeck, tenSI);
  t_cardEntry *tenDI = createCardEntry(&tenD);
  appendCard(initDeck, tenDI);
  
  t_cardEntry *JCI = createCardEntry(&JC);
  appendCard(initDeck, JCI);
  t_cardEntry *JHI = createCardEntry(&JH);
  appendCard(initDeck, JHI);
  t_cardEntry *JSI = createCardEntry(&JS);
  appendCard(initDeck, JSI);
  t_cardEntry *JDI = createCardEntry(&JD);
  appendCard(initDeck, JDI);
  
  t_cardEntry *QCI = createCardEntry(&QC);
  appendCard(initDeck, QCI);
  t_cardEntry *QHI = createCardEntry(&QH);
  appendCard(initDeck, QHI);
  t_cardEntry *QSI = createCardEntry(&QS);
  appendCard(initDeck, QSI);
  t_cardEntry *QDI = createCardEntry(&QD);
  appendCard(initDeck, QDI);
  
  t_cardEntry *KCI = createCardEntry(&KC);
  appendCard(initDeck, KCI);
  t_cardEntry *KHI = createCardEntry(&KH);
  appendCard(initDeck, KHI);
  t_cardEntry *KSI = createCardEntry(&KS);
  appendCard(initDeck, KSI);
  t_cardEntry *KDI = createCardEntry(&KD);
  appendCard(initDeck, KDI);
  
  t_cardEntry *ACI = createCardEntry(&AC);
  appendCard(initDeck, ACI);
  t_cardEntry *AHI = createCardEntry(&AH);
  appendCard(initDeck, AHI);
  t_cardEntry *ASI = createCardEntry(&AS);
  appendCard(initDeck, ASI);
  t_cardEntry *ADI = createCardEntry(&AD);
  appendCard(initDeck, ADI);
  
  return initDeck;
}

t_cardList* generateListRandomCards(t_cardList *fullDeck, int n) 
{
	srand(time(NULL));
	t_cardEntry* card = (t_cardEntry *)malloc(sizeof(t_cardEntry));
	t_cardList *newDeck = (t_cardList *)malloc(sizeof(t_cardList));
	for(int i = 0; i < n; i++)
	{
		int k = (rand() % (fullDeck->Length)) + 1;
		card = selectAndRemove(fullDeck, k);
		appendCard(newDeck, card);	
	}
//  free(card);
  return newDeck;
}

void distributeCards(t_cardList *from, t_cardList *to, int n)
{
	for(int i = 0; i < n; i++)
	{
		t_cardEntry *card = popCard(from);
		appendCard(to, card);
	}
}

void sortByRank(t_cardList *list)
{
	t_cardEntry *iterator =  list->First;
	for(int i = 0; i <= list->Length; i++)
	{
    iterator = list->First;
		for(int j = 0; j < list->Length - i - 1; j++)
		{
		  	if(iterator->Card->rank > iterator->Next->Card->rank)
		  	{
			  	t_pokerCard *swapCard = iterator->Card;
			  	iterator->Card = iterator->Next->Card;
			  	iterator->Next->Card = swapCard;

		  	} 
       iterator = iterator->Next;
		}
	}
 
}

//done
t_cardEntry* createCardEntry(t_pokerCard *card)//remove prev and next
{
	t_cardEntry *newCard = NULL;
  newCard = (t_cardEntry *)malloc(sizeof(t_cardEntry));
	newCard->Prev = NULL;
	newCard->Next = NULL;
	newCard->Card = card;
  newCard->List = NULL;
  
  return newCard;
}

//done
void deleteCardEntry(t_cardEntry *entry)//(t_cardEntry *entry)
{
  assert(entry);
  entry->Prev = NULL;
  entry->Next = NULL;
  entry->Card = NULL;
  entry->List = NULL;
	free(entry);
  entry = NULL;
}

//done
void appendCard(t_cardList *list, t_cardEntry *entry) //void
{
  assert(list);
  //assert(entry);
  entry->List = list;
  entry->Next = NULL;
  if(list->Last != NULL)
  {
    list->Last->Next = entry;
    entry->Prev = list->Last;
    list->Last = entry;
  }
  else
  {
    list->First = entry;
    list->Last = entry;
  }
  list->Length++;
}

//deals card from top of shuffled pile
t_cardEntry* popCard(t_cardList *list)//returns pointer
{
//  t_cardEntry *card = NULL;
  if(list->First != NULL && list->Length != 0)
  {
    t_cardEntry *card = list->First;
    if(list->First->Next != NULL)
    {
      list->First = list->First->Next;
      list->First->Prev = NULL;
      card->Next = NULL;
    }
    list->Length--;
    return card;
  }
  return NULL;
}

void deleteCardList(t_cardList *list)
{
	assert(list);
 t_cardEntry *iterator = list->First;
 t_cardEntry *next = NULL;
  while(iterator)
	{
		next = iterator->Next;
		deleteCardEntry(iterator);
    iterator = next;
	}
 list->Length = 0;
 list->First = NULL;
 list->Last = NULL;  
	free(list);
}

t_cardEntry* selectAndRemove(t_cardList* list, int n)
{
	t_cardEntry* selectedCard = list->First;
	for(int i = 0; i < n; i++)
	{
    if(selectedCard->Next != NULL)
    {
		  selectedCard = selectedCard->Next;
    }
	}
	if(selectedCard->Next != NULL && selectedCard->Prev !=NULL)
  {
	  selectedCard->Next->Prev = selectedCard->Prev;
	  selectedCard->Prev->Next = selectedCard->Next;
	  selectedCard->Next = NULL;
	  selectedCard->Prev = NULL;
  }
  else if(selectedCard->Prev == NULL)
  {
  selectedCard->Next->Prev = NULL;
  list->First = selectedCard->Next;
  selectedCard->Next = NULL;
  }
    else if(selectedCard->Next == NULL)
  {
  selectedCard->Prev->Next = NULL;
  list->Last = selectedCard->Prev;
  selectedCard->Prev = NULL;
  }
	list->Length--;

	return selectedCard;
}

t_cardList* combinedList(t_cardList* list1, t_cardList* list2)
{
	t_cardList *combined = (t_cardList *)malloc(sizeof(t_cardList));
	
	t_cardEntry *iterator = list1->First;
	for(int i = 0; i < list1->Length; i++)
	{
    t_cardEntry *card = createCardEntry(iterator->Card);
		appendCard(combined, card);
		  iterator = iterator->Next;
	}
 
	
	iterator = list2->First;
	for(int i = 0; i < list2->Length; i++)
	{
    t_cardEntry *card = createCardEntry(iterator->Card);
		appendCard(combined, card);
    iterator = iterator->Next;		
	}
	
	return combined;
}

t_cardList* copyList(t_cardList* list1)
{
	t_cardList *newList = (t_cardList *)malloc(sizeof(t_cardList));
	
	t_cardEntry *iterator = list1->First;
	for(int i = 0; i < list1->Length; i++)
	{
    t_cardEntry *card = createCardEntry(iterator->Card);
		appendCard(newList, card);
		  iterator = iterator->Next;
	}
  return newList;
}