#include "Poker_card.h"

#ifndef LIST_OF_CARDS_H
#define LIST_OF_CARDS_H

typedef struct cardEntry
  t_cardEntry;
  
typedef struct cardList
  t_cardList;
  
struct cardEntry
{
  t_cardList *List;
  t_cardEntry *Prev;
  t_cardEntry *Next;
  t_pokerCard *Card;
};

struct cardList
{
  int Length;
  t_cardEntry *First;
  t_cardEntry *Last;
};

t_cardList* createList();

t_cardList* createInitialDeck();

t_cardList* generateListRandomCards(t_cardList *fullDeck, int n);

void distributeCards(t_cardList *from, t_cardList *to, int n);

void sortByRank(t_cardList *list);

t_cardEntry* createCardEntry(t_pokerCard *card);//remove prev and next

void deleteCardEntry(t_cardEntry *entry);

void appendCard(t_cardList *list, t_cardEntry *entry);

//deals card from anywhere in list
t_cardEntry* popCard(t_cardList *list);

void deleteCardList(t_cardList *list);

t_cardEntry* selectAndRemove(t_cardList *list, int n);

t_cardList *combinedList(t_cardList* list1, t_cardList *list2);

t_cardList *copyList(t_cardList* list1);
#endif
