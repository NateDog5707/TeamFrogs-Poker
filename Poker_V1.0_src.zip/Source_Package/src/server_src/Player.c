/* Player.c */

#include "Player.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include <math.h>

// creates a player and adds player to player list
// void createPlayer(t_player *PLAYER)
t_player *createPlayer(char NAME[50], int BALANCE, int PLAYER_SEAT)
{
	// initialize stuff?
	t_player *new_player;
	new_player = (t_player *)malloc(sizeof(t_player));
	
	strcpy(new_player -> Name, NAME);
	
	new_player -> Balance = BALANCE;
	new_player -> Seat = PLAYER_SEAT;
	
	new_player -> Pocket = NULL;
	new_player -> Folded = 0; //not folded at the start
	new_player -> Role = GENERIC; //everyone starts with generic
	new_player -> Hand = Undefined; //undefined at the start
	new_player -> Bot = 0; //is a bot

	return new_player;
}



// creates and initializes a bot player
t_player *createBot(int PLAYER_SEAT)
{
	// initialize stuff?
	t_player *new_bot;
	new_bot = (t_player *)malloc(sizeof(t_player));
	
	//new_bot -> Name = "Bot"; //name can decide later, could have different names
	
	strcpy(new_bot -> Name, "Bot");
	
	new_bot -> Balance = 1000;  //1000 for now, can decide later
	new_bot -> Seat = PLAYER_SEAT;
	
	new_bot -> Pocket = NULL;
	new_bot -> Folded = 0; //not folded at the start
	new_bot -> Role = GENERIC; //everyone starts with generic
	new_bot -> Hand = Undefined; //undefined at the start
	new_bot -> Bot = 1; //is a bot
	
	return new_bot;

}

