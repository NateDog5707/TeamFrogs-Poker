/* Player.h */

#include "Poker_card.h"
#include "List_of_cards.h"

#ifndef PLAYER_H
#define PLAYER_H

// enums
enum ROLE
{
  GENERIC, SB, BB
};

/*
enum SEAT
{
	SEAT_1, SEAT_2, SEAT_3, SEAT_4
};*/

enum HAND
{
	Undefined = 0,
	High_Card = 1,
	One_Pair = 2, 
	Two_Pair = 3,
	Three_of_a_Kind = 4,
	Straight = 5, 
	Flush = 6,
	Full_House = 7,
	Four_of_a_Kind = 8,
	Straight_Flush = 9,
	Royal_Flush = 10
};

// struct 
typedef struct player
{
	// Pocket Cards
	//t_pokerCard *Pocket_1
	//t_pokerCard *Pocket_2
	// Array of size 2 or two cards?
	t_cardList *Pocket;
	
	// Name
	char Name[50];
	
	// Individual Balance
	int Balance;
	
	// Folded
	//int Folded;  0 = not folded, 1 = folded (changed to bool)
	_Bool Folded;
	
	// Role
	enum ROLE Role;
	
	// Seat
	//enum SEAT Seat;
	int Seat;
	
	// Hand
	enum HAND Hand;
	
	// Bot?
	_Bool Bot;  // 0 = player, 1 = bot

} t_player;



// Functions
//void createPlayer(t_player *PLAYER); changed to the one below
t_player *createPlayer(char NAME[50], int BALANCE, int PLAYER_SEAT);
t_player *createBot(int PLAYER_SEAT);

#endif