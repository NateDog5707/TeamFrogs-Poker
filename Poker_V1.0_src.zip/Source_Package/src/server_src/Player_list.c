/* Player_list.c */

#include "Player_list.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include <math.h>


// creates a player list
/*
t_playerlist *CreatePlayerList(void)
{
	t_playerlist *l;
	l = (t_playerlist *)malloc(sizeof(t_playerlist));
	
	if(!l)
	{
		return NULL;
	}
	
	l -> First = NULL;
	l -> Last = NULL;
	l -> Length = 0; 
	// note: playerlist should have length = 4 when the game starts
	
	return l;
}*/

void CreatePlayerList(t_player* PLAYERLIST[4])
{
	//t_player* player_list[4];
	
	PLAYERLIST[0] = NULL;
	PLAYERLIST[1] = NULL;
	PLAYERLIST[2] = NULL;
	PLAYERLIST[3] = NULL;
	
	//return player_list;
}


// deletes a player list
/*
void DeletePlayerList(t_playerlist *PLAYERLIST)
{
	assert(PLAYERLIST);
	
	t_playerentry *current;
	current = PLAYERLIST -> First;
	
	t_playerentry *next = NULL;
	
	while(current)
	{
		next = current -> Next;
		delete_player_entry(current);
		
		current = next;
	}
	
	PLAYERLIST -> Length = 0;
	PLAYERLIST -> First = NULL;
	PLAYERLIST -> Last = NULL;

	free(PLAYERLIST);
}*/

void DeletePlayerList(t_player* PLAYERLIST[4])
{
	for(int i = 0; i < 4; i++)
	{
		if(PLAYERLIST[i] != NULL)
		{
			delete_player(PLAYERLIST, PLAYERLIST[i]);
		}
	}
}

// appends a player to the playerlist
// calls init_player_entry(PLAYER) and appends the entry to the list
int append_player(t_player* PLAYERLIST[4], t_player *PLAYER)
{
	int seat = PLAYER -> Seat;
	
	if(PLAYERLIST[seat - 1] != NULL)
	{
		printf("Seat Taken, Choose Again\n");
		return 1;
	}
	else if(seat < 1 || seat > 4)
	{
		printf("Invalid Seat Number, Choose Again\n");
		return 1;
	}
	else
	{
		PLAYERLIST[seat - 1] = PLAYER;
		return 0;
	}
	
	/*
	assert(PLAYERLIST);
	assert(PLAYER);
	
	
	t_playerentry *new_entry = NULL;
	new_entry = init_player_entry(PLAYER);
	
	assert(new_entry);
	
	new_entry -> List = PLAYERLIST;
	new_entry -> Prev = NULL;
	new_entry -> Next = NULL;
	new_entry -> Player = PLAYER;
	
	
	int player_seat = PLAYER -> Seat;
	
	t_playerentry *current;
	current = PLAYERLIST -> First;
	
	t_playerentry *next = NULL;
	
	t_playerentry *next_seat = NULL;

	
	while(current)
	{
		next = current -> Next;
	
		// finding the next seat after player_seat
		if(current -> Player -> Seat > player_seat)
		{	
			next_seat = current;
			break;
		}
		
		current = next;
	}
	
	
	// if list is empty
	if(PLAYERLIST -> Last == NULL)
	{
		new_entry -> Prev = NULL;
		new_entry -> Next = NULL;
		PLAYERLIST -> First = new_entry;
		PLAYERLIST -> Last = new_entry;
	}
	// if list is not empty
	else
	{
		//PLAYERLIST -> Last -> Next = new_entry;
		//new_entry -> Prev = PLAYERLIST -> Last;
		//PLAYERLIST -> Last = new_entry;
		
		next_seat -> Prev -> Next = new_entry;
		new_entry -> Prev = next_seat -> Prev;
		next_seat -> Prev = new_entry;
		new_entry -> Next = next_seat;
	
	}
	
	//printf("%d", PLAYERLIST -> Length);
	
	(PLAYERLIST -> Length) ++;
	
	//printf("%d", PLAYERLIST -> Length);
	*/
	

}



// deletes a player from the playerlist
// calls delete_player_entry
// used for removing player from game (exit, give up, etc.)
void delete_player(t_player* PLAYERLIST[4], t_player *PLAYER)
{
	
	int seat = PLAYER -> Seat;
	
	PLAYERLIST[seat - 1] = NULL;
	
	//free(PLAYER);

	/*
	assert(PLAYER);
	assert(PLAYERLIST);
	
	t_playerentry *deleted_playerentry = NULL;
	
	t_playerentry *current;
	current = PLAYERLIST -> First;

	t_playerentry *next = NULL;
	
	while(current)
	{
		next = current -> Next;
		
		// finding the player we want to remove in player list
		if(current -> Player == PLAYER)
		{
			deleted_playerentry = current;
			
			// previous' next should be current's next
			current -> Prev -> Next = current -> Next;
			
			// current's next's previous should be current's previous
			current -> Next -> Prev = current -> Prev;
			
			delete_player_entry(deleted_playerentry);
			
			break;
			
		}
		
		current = next;
	}
	
	
	PLAYERLIST -> Length--;
	*/

}

// checks if there are any empty seats and replace with bot
// i could also add a function that checks if the seats r full
void checkEmpty(t_player* PLAYERLIST[4])
{
	// loops through playerlist to check if there are any empty seats (out of 4) 
	// if there is, add bot
	
	int seat;

	for(int i = 0; i < 4; i++)
	{
		seat = i + 1;
	
		// if empty
		if(PLAYERLIST[i] == NULL)
		{
			t_player *BOT = createBot(seat);
			append_player(PLAYERLIST, BOT);
		}
		
	}
	
	/*
	// checks if player count is less than 4	
	if((PLAYERLIST -> Length) < 4)
	{
		int seat = 1;
	
		t_playerentry *current;
		current = PLAYERLIST -> First;
	
		t_playerentry *next = NULL;
	
		while(current)
		{
			next = current -> Next;
		
			if(current -> Player -> Seat == seat)
			{
				printf("player %d\n", seat);
				current = next;
			}
			else // for example, seat = 2, but current seat = 3, meaning missing seat 2 player
			{
				t_player *BOT = createBot(seat);
				append_player(PLAYERLIST, BOT);
				printf("bot %d\n", seat);
			}
			
			seat++;
		
		}
		
		// if still less than 4
		while((PLAYERLIST -> Length) < 4)
		{
			t_player *BOT = createBot(seat);
			append_player(PLAYERLIST, BOT);
			seat++;
		
		}
	}
	else if(PLAYERLIST -> Length > 4)
	{
		printf("Error: Player count exceeds 4\n");
	}
	*/

}

// empty bots from player list
void emptyBot(t_player* PLAYERLIST[4])
{
	//loops through player list to empty out all the bots
	//int seat;

	for(int i = 0; i < 4; i++)
	{
		//seat = i + 1;
		//printf("here1\n");
	
	
		// if player is bot
		if(PLAYERLIST[i] != NULL)
		{
			//printf("here2\n");
			if(PLAYERLIST[i] -> Bot == 1)
			{
				//printf("here3\n");
				delete_player(PLAYERLIST, PLAYERLIST[i]);
			}
		}
		
	}

	/*
	t_playerentry *current;
	current = PLAYERLIST -> First;
	
	t_playerentry *next = NULL;
	
	while(current)
	{
		next = current -> Next;
		
		if(current -> Player -> Bot == 1)
		{
			delete_player(PLAYERLIST, current -> Player);
		}
			
		current = next;
	}
	*/

}

/*
// initializes a player entry
t_playerentry *init_player_entry(t_player *PLAYER)
{
	t_playerentry *new_entry = NULL;
	new_entry = (t_playerentry *)malloc(sizeof(t_playerentry));
	
	new_entry -> List = NULL;
	new_entry -> Prev = NULL;
	new_entry -> Next = NULL;
	new_entry -> Player = PLAYER;
	
	return new_entry;
}


// deletes a player entry
void delete_player_entry(t_playerentry *PLAYERENTRY)
{
	assert(PLAYERENTRY);
	
	PLAYERENTRY -> List = NULL;
	PLAYERENTRY -> Prev = NULL;
	PLAYERENTRY -> Next = NULL;
	PLAYERENTRY -> Player = NULL;
	
	free(PLAYERENTRY);
	PLAYERENTRY = NULL;

}

*/
