/* Player_list.h */

#include "Player.h"

#ifndef PLAYER_LIST_H
#define PLAYER_LIST_H

/*
// Player List (doubly linked list)
typedef struct playerlist t_playerlist;

// Player Entry (doubly linked list)
typedef struct playerentry t_playerentry;

struct playerlist
{

	unsigned int Length;
	t_playerentry *First;
	t_playerentry *Last;
	
};

// Player Entry (doubly linked list)
struct playerentry
{

	t_playerlist *List;
	t_playerentry *Prev;
	t_playerentry *Next;
	t_player *Player;
	
};*/

/*
// Methods for entry
t_playerentry *init_player_entry(t_player *PLAYER); //creates new player entry, malloc()
void delete_player_entry(t_playerentry *PLAYERENTRY); //deletes player entry, free()
*/

// Methods for list
//t_player *CreatePlayerList(void);
void CreatePlayerList(t_player* PLAYERLIST[4]);
void DeletePlayerList(t_player* PLAYERLIST[4]);
int append_player(t_player* PLAYERLIST[4], t_player *PLAYER);
void delete_player(t_player* PLAYERLIST[4], t_player *PLAYER);
void checkEmpty(t_player* PLAYERLIST[4]);  // checks if there are empty seats and replace with bot
void emptyBot(t_player* PLAYERLIST[4]); // empty bots from the list

#endif