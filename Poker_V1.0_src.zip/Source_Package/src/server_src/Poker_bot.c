/* Poker_bot.c */

#include "Poker_bot.h"


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include <math.h>

void Bot_Turn(t_game *game, t_player *bot_player)
{
	int current_round = game -> round;
	//int current_bet = game -> current_bet;
	//int current_bet = 0;
	int raised = 1;
	
	switch(current_round)
	{
		case 1:
			raised = FirstBettingRound(bot_player, game, raised);
			break;
		case 2:
			raised = SecondBettingRound(bot_player, game, raised);
			break;
		case 3:
			raised = ThirdBettingRound(bot_player, game, raised);
			break;
		case 4:
			raised = FourthBettingRound(bot_player, game, raised);
			break;
	}
}


// First Betting Round
// Possible Actions: Call, Raise, Fold
int FirstBettingRound(t_player *bot_player, t_game *game, int raised)
{
	enum HAND botBestHand = bot_player -> Hand;

	if(firstMove == 0) 
	{
	    game->end_player = bot_player;
	}
	firstMove++;
	
	if(botBestHand >= 2 && raised == 0)
	{
		// bot should raise
		raised = 1;
		int raise_amount = (bot_player -> Balance) / 2;
		raise(bot_player, game, raise_amount);
	}
	else
	{
		// bot should call
		call(bot_player, game);
	} 

	// no folding?
	return raised;
}

// Second Third Fourth Betting Round
// Possible Actions: Check, Call, Raise, Fold
int SecondBettingRound(t_player *bot_player, t_game *game, int raised)
{
	enum HAND botBestHand = bot_player -> Hand;

	if(firstMove == 0) 
	{
	    game->end_player = bot_player;
	}
	firstMove++;
	
	// checks if bot can check
	int current_bet = game -> current_bet;
	
	if(botBestHand >= 3 && raised == 0)
	{
		// bot should raise
		raised = 1;
		int raise_amount = (bot_player -> Balance) / 3;
		raise(bot_player, game, raise_amount);
	}
	else if(botBestHand < 3 && botBestHand >= 2)
	{
		// bot should call
	  call(bot_player, game);
	} 
	else if(botBestHand < 2 && botBestHand >= 1 && current_bet == 0)
	{
		// bot should check
		check(bot_player, game);
	}
	else
	{
		// bot should fold
		fold(bot_player);
	}
	
	return raised;
}


// Third Betting Round
// Possible Actions: Check, Call, Raise, Fold
int ThirdBettingRound(t_player *bot_player, t_game *game, int raised)
{
	enum HAND botBestHand = bot_player -> Hand;

	if(firstMove == 0) 
	{
	    game->end_player = bot_player;
	}
	firstMove++;
	
	// checks if bot can check
	int current_bet = game -> current_bet;
	
	if(botBestHand >= 5 && raised == 0)
	{
		// bot should raise
		raised = 1;
		int raise_amount = (bot_player -> Balance) / 3;
		raise(bot_player, game, raise_amount);
	}
	else if(botBestHand < 5 && botBestHand >= 2)
	{
		// bot should call
		call(bot_player, game);
	} 
	else if(botBestHand < 2 && botBestHand >= 1 && current_bet == 0)
	{
		// bot should check
		check(bot_player, game);
	}
	else
	{
		// bot should fold
		fold(bot_player);
	}
	
	return raised;
}

// Fourth Betting Round
// Possible Actions: Check, Call, Raise, Fold
int FourthBettingRound(t_player *bot_player, t_game *game, int raised)
{
	enum HAND botBestHand = bot_player -> Hand;

	if(firstMove == 0) 
	{
	    game->end_player = bot_player;
	}
	firstMove++;
	
	// checks if bot can check
	int current_bet = game -> current_bet;
	
	if(botBestHand >= 6 && raised == 0)
	{
		// bot should raise
		raised = 1;
		int raise_amount = (bot_player -> Balance) / 3;
		raise(bot_player, game, raise_amount);
	}
	else if(botBestHand < 6 && botBestHand >= 4)
	{
		// bot should call
		call(bot_player, game);
	} 
	else if(botBestHand < 4 && botBestHand >= 2 && current_bet == 0)
	{
		// bot should check
		check(bot_player, game);
	}
	else
	{
		// bot should fold
		fold(bot_player);
	}

	return raised;
	
}


void fold(t_player *bot_player)
{
	//flagFirstMove++;

	char SendBuf[256];
  
  bot_player -> Folded = 1;
            
  strncpy(SendBuf, "ACTION ", sizeof(SendBuf)-1);
  
  strcat(SendBuf, "FOLD ");
  
  int seat = bot_player -> Seat;
  
  switch(seat)
  {
  	case 1:
  		strcat(SendBuf, "PLAYER_1");
  		break;
 		case 2:
  		strcat(SendBuf, "PLAYER_2");
  		break;
 		case 3:
  		strcat(SendBuf, "PLAYER_3");
  		break;
 		case 4:
  		strcat(SendBuf, "PLAYER_4");
  		break;
  }
  
  SendBuf[sizeof(SendBuf)-1] = 0;
  appendMessageAll(SendBuf);
  
  printf("fold\n");
}

void call(t_player *bot_player, t_game *game)
{
	//flagFirstMove++;
	
	char SendBuf[256];
	
 	add_to_pot(bot_player, game, game->current_bet);
              
  strncpy(SendBuf, "ACTION ", sizeof(SendBuf)-1);
  
  strcat(SendBuf, "CALL ");
  
  int seat = bot_player -> Seat;
  
  switch(seat)
  {
  	case 1:
  		strcat(SendBuf, "PLAYER_1");
  		break;
 		case 2:
  		strcat(SendBuf, "PLAYER_2");
  		break;
 		case 3:
  		strcat(SendBuf, "PLAYER_3");
  		break;
 		case 4:
  		strcat(SendBuf, "PLAYER_4");
  		break;
  }
  
  SendBuf[sizeof(SendBuf)-1] = 0;
  appendMessageAll(SendBuf);
  printf("call\n");
}

void raise(t_player *bot_player, t_game *game, int raise_amount)
{
	//flagFirstMove++; 
	
	char SendBuf[256];

 	if(raise_amount >= 0 && bot_player->Balance - raise_amount > 0) 
 	{ 
 		//need to get playerBal to determine if valid
  	add_to_pot(bot_player, game, raise_amount);
  	game -> current_bet = raise_amount;
              
    game->end_player = bot_player;
              
    strncpy(SendBuf, "ACTION ", sizeof(SendBuf)-1);
    
    strcat(SendBuf, "RAISE ");
    
    int seat = bot_player -> Seat;
  
    switch(seat)
    {
    	case 1:
    		strcat(SendBuf, "PLAYER_1 ");
    		break;
   		case 2:
    		strcat(SendBuf, "PLAYER_2 ");
    		break;
   		case 3:
    		strcat(SendBuf, "PLAYER_3 ");
    		break;
   		case 4:
    		strcat(SendBuf, "PLAYER_4 ");
    		break;
    }
    
    char raise_amount_str[10];
    sprintf(raise_amount_str, "%d", raise_amount);
    
    strcat(SendBuf, raise_amount_str);

    SendBuf[sizeof(SendBuf)-1] = 0;
    appendMessageAll(SendBuf);
 	} 
 	
 	
 	printf("raise\n");
}

void check(t_player *bot_player, t_game *game)
{ 
	//game -> end_player = bot_player;
	
	char SendBuf[256];
	
	strncpy(SendBuf, "ACTION ", sizeof(SendBuf)-1);
	
	strcat(SendBuf, "CHECK ");
	
	int seat = bot_player -> Seat;
  
  switch(seat)
  {
  	case 1:
  		strcat(SendBuf, "PLAYER_1 ");
  		break;
 		case 2:
  		strcat(SendBuf, "PLAYER_2 ");
  		break;
 		case 3:
  		strcat(SendBuf, "PLAYER_3 ");
  		break;
 		case 4:
  		strcat(SendBuf, "PLAYER_4 ");
  		break;
  }
	
	SendBuf[sizeof(SendBuf)-1] = 0;
	appendMessageAll(SendBuf);
	
	printf("check\n");
}



