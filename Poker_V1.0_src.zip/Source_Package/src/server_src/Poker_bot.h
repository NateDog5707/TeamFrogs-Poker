/* Poker_bot.h */

#include "Player.h"
#include "Poker_game.h"
#include "Buffer.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include <time.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <assert.h>

#ifndef POKER_BOT_H
#define POKER_BOT_H

// Called in main
void Bot_Turn(t_game *game, t_player *bot_player);


// First Betting Round
// Possible Actions: Call, Raise, Fold
int FirstBettingRound(t_player *bot_player, t_game *game, int raised);

// Second Betting Round
// Possible Actions: Check, Call, Raise, Fold
int SecondBettingRound(t_player *bot_player, t_game *game, int raised);

// Third Betting Round
// Possible Actions: Check, Call, Raise, Fold
int ThirdBettingRound(t_player *bot_player, t_game *game, int raised);

// Fourth Betting Round
// Possible Actions: Check, Call, Raise, Fold
int FourthBettingRound(t_player *bot_player, t_game *game, int raised);

// Check
void check(t_player *bot_player, t_game *game);

// Raise
void raise(t_player *bot_player, t_game *game, int raise_amount);

// Call
void call(t_player *bot_player, t_game *game);

// Fold
void fold(t_player *bot_player);


// MIGHT NOT NEED THESE




#endif