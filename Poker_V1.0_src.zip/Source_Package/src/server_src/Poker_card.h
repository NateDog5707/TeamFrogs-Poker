//#include "List_of_cards.h"
#include <stdbool.h>
#ifndef POKER_CARD_H
#define POKER_CARD_H

enum t_Rank
{
  TWO = 2, THREE= 3, FOUR = 4, FIVE = 5, SIX = 6, SEVEN = 7,
  EIGHT = 8, NINE = 9, TEN = 10, JACK = 11, QUEEN = 12, 
  KING = 13, ACE =14
};

enum t_Suit
{
  SPADES = 1, HEARTS = 2, DIAMONDS = 3, CLUBS = 4
};

//pokerCard objects hold the rank, suit, and side for each card
typedef struct pokerCard{
  enum t_Rank rank;
  enum t_Suit suit;
  _Bool is_faced_up; //Front shows the value of the card, each card will start initialized on back.
  
} t_pokerCard;

//moving this to new file, Identify_hand.h
/*
int royalFlush(t_player *player, t_cardList *list);
int straightFlush(t_player *player, t_cardList *list);
int fourOfAKind(t_player *player, t_cardList *list);
int fullHouse(t_player *player, t_cardList *list);
int flush(t_player *player, t_cardList *list);
int straight(t_player *player, t_cardList *list);
int threeOfAKind(t_player *player, t_cardList *list);
int twoPair(t_player *player, t_cardList *list);
int pair(t_player *player, t_cardList *list);
int highCard(t_player *player, t_cardList *list);

//update the player's enum HAND type to what their best hand type
int identifyHand(t_player *player, t_cardList *list);

*/

#endif