/* Poker_game.c */
#include "Poker_game.h"
#include "List_of_cards.h"
#include "Poker_card.h"
#include "Player_list.h"
#include "Identify_hand.h"
#include "Buffer.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

t_cardList* shuffled = NULL;

int firstMove = 1; //starts off as 1 to counteract preflop having a blinds
char cardName[25];

/* initializes the game module. Should be called on system start up */
 t_game *init_game() {
    t_game *init_game = malloc(sizeof(t_game));
    CreatePlayerList(init_game->player_list);
    init_game->deck = createList();
    init_game->community_cards = createList(); 
    init_game->current_player = NULL;
    init_game->end_player = NULL;  //changes whenever a player does one of these actions (check/raise) //Should be changed in server code
    init_game->pot = 0;
    init_game->side_pot = 0;
    init_game->round = 0;
    init_game->small_blind = 0;  //0: 1st seat, 1: 2nd seat...
    init_game->big_blind = 1;
    init_game->current_bet = 30; //set to value at big blind
    return init_game;
 }

/* deletes instance of the game. Should be called on system closing */
 void delete_game(t_game *game) {
    assert(game);
    DeletePlayerList(game->player_list);
    deleteCardList(game->deck);
    deleteCardList(game->community_cards);
    game->current_player = NULL;
    game->end_player = NULL;
    /*
    game->pot = NULL;
    game->round = NULL;
    game->small_blind = NULL;
    game->big_blind = NULL;
    game->current_bet = NULL;
    */
    free(game);
    game = NULL;
 }

/* Resets the game. Small blind, and big blind should be updated with all the other variables except player_list being reset.
Should be called after a game ends */
 void reset_game(t_game *game) {
    assert(game);
    printf("Resetting Game\n");
    game->deck = createList();
    game->community_cards = createList(); 
    game->current_player = NULL;
    game->end_player = NULL;
    game->pot = 0;
    game->side_pot = 0;
    game->round = 1;
    game->current_bet = 30; //initialized to value of big blind, use global var
    update_SB_BB(game);
    printf("Done resetting game\n");
    printf("Calling start_game inside reset_game\n");
    start_game(game);
    printf("Done calling start_game inside reset_game\n");
    firstMove = 1;   
    
    //reset folds back to unfolded
    for (int i = 0; i < 4; i++)
    {
    	game->player_list[i]->Folded = 0;
    }
 }

/* deals cards to each player and updates current_player */
void start_game(t_game *game) {
    assert(game);

    //creates a new deck
    game->deck = generateListRandomCards(createInitialDeck(), 13);
    shuffled = copyList(game->deck); //GLOBAL VAR IN Poker_game.h
    
    //after generating 13 deck list, send deck list to all clients
/*    for( int i = 1; i < 14; i++)
    {
    	cardToWrite(cardName, i);
    	appendMessageAll(cardName);
    
    }*/
    
    //add bots if needed
    checkEmpty(game->player_list);

    //initial bet for blinds
    add_to_pot(game->player_list[game->small_blind], game, 15);    //add global variable for small blind
    add_to_pot(game->player_list[game->big_blind], game, 30);  //add global variable for big blind
    
    //change values of current player and end player
    game->end_player = game->player_list[game->big_blind]; //end_player is initialized to player at big blind
    game->current_player = game->player_list[(game->big_blind + 1) % 4]; //points the games current player to player after big blind
    
//debug
		printf("inside start_game: end_player = %s\n", game->end_player->Name);
		printf("inside start_game: current_player = %s\n", game->current_player->Name);
    
    //distribute pocket cards for each player
    for (int i = 0; i < 4; i++) {
        game->player_list[i]->Pocket = createList();
        distributeCards(game->deck, game->player_list[i]->Pocket, 2);
        //after distribute cards, needs to add update cards to queues
    }

    //update hands for bots
    update_hands(game);

    game->round = 1;
    printf("Let's play poker!\n");
    //appendMessageAll("COMMUNITY PREFLOP"); //tells clients to display no cards in the middle
    //appendMessageAll("COMMUNITY PREFLOP");
}

/* Changes the games current player either to the next active player or back to end player */
void next_player(t_game *game) {
    //printf("next_player is called! \n");
    assert(game);

    //finds current players index in player_list
    int current_player_index = 0;
    for (int i = 0; game->player_list[i] != game->current_player; i++) {
        current_player_index = current_player_index + 1;
    }

    //points to next active player in player_list
    current_player_index++;
	current_player_index = current_player_index % 4;
    while (game->player_list[current_player_index] != game->end_player) { 
        //if the player is folded or all in, continue to the next player
        if (game->player_list[current_player_index]->Folded == true || game->player_list[current_player_index]->Balance == 0) {
            current_player_index++;
			current_player_index = current_player_index % 4;
        }
        else {
            break; //should exit loop with the next active player in player list or at end player
        }
    }
    game->current_player = game->player_list[current_player_index];

}

/* goes to the next betting round. Deals the appropriate amount of cards for the community cards and points to the appropriate 
first player */
void next_round(t_game *game) {
    assert(game);

    //sets end player to Null
    game->end_player = NULL; //end_player gets updated within processrequest() when a player raises

    //increments round counter
    game->round++;
    game->current_bet = 0; //Current_bet is set to NULL to help determine end_player (can be used to determine if its the first player to check)
    
    //sets up betting round. Deals cards to community and points to first player
    int round = game->round;
    if (round == 2) { //going to 2nd betting round
        //Flop
        distributeCards(game->deck, game->community_cards, 3);
        game->current_player = first_active_player(game, game->small_blind);
        update_hands(game);
        appendMessageAll("COMMUNITY FLOP"); //tells clients to show the turn
    }
    else if (round == 3 || round == 4) { //going to 3rd and 4th betting round
        //Turn, River
        distributeCards(game->deck, game->community_cards, 1);
        game->current_player = first_active_player(game, game->small_blind);
        update_hands(game);
        //after distributing cards, needs to add update to queues
        if (round == 3){
        	appendMessageAll("COMMUNITY TURN");//tells clients to show 4th card
       	}
       	else if (round == 4 ){
       		appendMessageAll("COMMUNITY RIVER"); //tells clients to show 5th card
       	}
       	
    }

    firstMove = 0;
}

//checks if the player is the last active player in the game (all other players have folded)
_Bool last_active_player(t_game *game) {
    int counter = 0;
    for (int i = 0; i < 4; i++) {
        if (game->player_list[i]->Folded == true) {
            counter++;
        }
    }

    return (counter == 3);
}

/* checks if all the active players are all in */
_Bool other_players_all_in(t_game *game) {
    int counter = 0;
    for (int i = 0; i < 4; i++) {
        if (game->player_list[i]->Balance == 0 || game->player_list[i]->Folded == true) {
            counter++;
        }
    }

    return (counter >= 3);
}

/* Displays active players' pocket cards and awards pot to the player with the best hand */
void showdown(t_game *game) {
    assert(game);
		
    for (int i = 0; i < 4; i++) {
        if (game->player_list[i]->Folded == false) {
            t_cardEntry *current_card_entry = game->player_list[i]->Pocket->First;
            
            //displays pocket cards
            current_card_entry->Card->is_faced_up = true;
            current_card_entry = current_card_entry->Next;
            current_card_entry->Card->is_faced_up = true;
            
        }
    }

    //award pot to winner
    award_pot_during_showdown(game);
}

/* Takes bet amount away from players balance and adds bet amount to the pot. */
void add_to_pot(t_player *player, t_game *game, int bet_amount) {
    assert(game);
    assert(player);
    
    //this case should only be used for blinds (player does not have enough balance for small blind or big blind)
    //client should not send bet amounts greater than players balance
    if (bet_amount > player->Balance) {
        game->pot = game->pot + player->Balance;
        player->Balance = 0;
    		//player is all in
    }
    else {
        player->Balance = player->Balance - bet_amount;
        game->pot = game->pot + bet_amount;
    }
}

/* awards pot to player */
void award_pot(t_player *player, t_game *game) {
    assert(game);
    assert(player);

    player->Balance = player->Balance + game->pot;
    //pot should be reset with reset_game()
}

///////////////////////////////////////////////////////////
/*                                                       */
/*                    LOCAL FUNCTIONS                    */
/*                                                       */
///////////////////////////////////////////////////////////

/* change small blind and big blind to rotate clockwise around the table. If it reaches the last seat
point back to the first seat */
void update_SB_BB(t_game *game){
    assert(game);

    game->small_blind++;
    game->big_blind++;
    game->small_blind = game->small_blind % 4;
    game->big_blind = game->big_blind % 4;
}

/* Points to the first active player (player that has not folded or is not all in) starting with small blind*/
t_player *first_active_player(t_game *game, int start_index) {
    assert(game);

    //point to player with small blind
    int current_player_index = start_index;

    //looks for the player that has not folded and still has a balance
    while (game->player_list[current_player_index]->Balance == 0 || game->player_list[current_player_index]->Folded == true) {
        current_player_index++;
		current_player_index = current_player_index % 4;
        if (current_player_index == start_index) { //used for when all players are all in
            break;
        }
    }  
    return game->player_list[current_player_index];
}

/* loops through player list and identifies hand for each player */
void update_hands(t_game *game) {
    assert(game);
    for (int i = 0; i < 4; i++) {
        t_cardList *seven_card_hand = combinedList(game->player_list[i]->Pocket, game->community_cards);
        identifyHand(game->player_list[i], seven_card_hand);
    }
}

/* Compares everyones cards to determine winner/winners and awards the pot */
void award_pot_during_showdown(t_game *game) {
    assert (game);
    //finds the player with the best hand
    t_player *temp = first_active_player(game, 0); //temp is initialized to first active player
    for (int i = 0; i < 4; i++) {
        if (game->player_list[i] != temp && game->player_list[i]->Folded == 0) {
            if (temp->Hand < game->player_list[i]->Hand ) {
                temp = game->player_list[i];
            }
            else if (temp->Hand == game->player_list[i]->Hand) {
                t_cardList *seven_card_hand_1 = combinedList(game->player_list[i]->Pocket, game->community_cards);
                t_cardList *seven_card_hand_2 = combinedList(temp->Pocket, game->community_cards);
                int better_hand = compareHand(game->player_list[i], temp, seven_card_hand_1, seven_card_hand_2);
                if (better_hand == 1) {
                    temp = game->player_list[i];
                }
            }
        }
    }//temp should be the player with the best hand
    printf("Best hand belongs to player %s with a hand %d\n", temp->Name, temp->Hand);
    
    //compare hands to see if there are other players with equal hands
    int amount_of_winners = 1;
    t_player *array_of_winners[4] = {temp};
    for (int i = 0; i < 4; i++) {
        t_cardList *seven_card_hand_1 = combinedList(game->player_list[i]->Pocket, game->community_cards);
        t_cardList *seven_card_hand_2 = combinedList(temp->Pocket, game->community_cards);
        if (game->player_list[i]->Hand == temp->Hand) {
            if (compareHand(game->player_list[i], temp, seven_card_hand_1, seven_card_hand_2) == 0 && game->player_list[i] != temp
            && game->player_list[i]->Folded == 0) {
                amount_of_winners++;
                array_of_winners[amount_of_winners-1] = game->player_list[i];
            }
        }
    }
    
    //award the pot depending on how many winners there are
    for (int i = 0; i < amount_of_winners; i++) {
        array_of_winners[i]->Balance = array_of_winners[i]->Balance + game->pot / amount_of_winners;
        //pot should be reset with reset_game()
    }
    //should award pot to winner / winners
}






   