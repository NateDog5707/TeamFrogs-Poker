/* Poker_game.h */
#include "List_of_cards.h"
#include "Player_list.h"
#include "Identify_hand.h"
#include "Buffer.h"
#include <stdbool.h>
#include <assert.h>
#include <stdio.h>

#ifndef POKER_GAME_H
#define POKER_GAME_H

//typedef struct t_game t_game;

//GLOBAL VAR FOR 13 CARD DECK
extern t_cardList* shuffled; //thirteen card shuffled deck
extern int firstMove; //starts off as 1 to counteract preflop having a blinds
extern char cardName[25];

typedef struct t_game {
    t_player *player_list[4];
    t_cardList *deck;
    t_cardList *community_cards;
    int pot;
    int side_pot;
    t_player *current_player;
    t_player *end_player;
    int round;
    int small_blind;
    int big_blind;
    int current_bet;
} t_game;

//Functions to use
t_game *init_game();
void delete_game(t_game *game);
void reset_game(t_game *game);
void start_game(t_game *game);
void next_player(t_game *game); 
void next_round(t_game *game);
void showdown(t_game *game);
_Bool last_active_player(t_game *game);
_Bool other_players_all_in(t_game *game);
void award_pot(t_player *player, t_game *game);
void add_to_pot(t_player *player, t_game *game, int bet_amount);

//Local Functions (Called by functions above)
void update_SB_BB(t_game *game);
t_player *first_active_player(t_game *game, int start_index);
void update_hands(t_game *game);
void award_pot_during_showdown(t_game *game); //WIP


#endif
