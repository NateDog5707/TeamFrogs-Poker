#include "Poker_game.h"
#include "Poker_bot.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

char get_suit(t_pokerCard *card);
char get_rank(t_pokerCard *card);

int main(void) {
    int input;
    _Bool firstCheck = false;
    t_game *game = init_game(); 

    /* //TESTING FOR INIT GAME
    printf("Round is: %d \n", game->round);
    printf("Small blind is: %d \n", game->small_blind);
    printf("Big blind is: %d \n", game->big_blind);
    printf("Length of deck: %d", game->deck->Length);
    printf("Length of community cards: %d", game->community_cards->Length);
    */
    
    while (input != 9999) {

    t_player *player1 = createPlayer("P1", 1000, 1);
    t_player *player2 = createPlayer("P2", 1000, 2);
    t_player *player3 = createPlayer("P3", 1000, 3);
    //t_player *player4 = createPlayer("P4", 1000, 4);
    append_player(game->player_list, player1);
    append_player(game->player_list, player2);
    append_player(game->player_list, player3);
    //append_player(game->player_list, player4);
    
    start_game(game);
    printf("START GAME \n");

    for (int i = 0; i < 4; i++) {
        printf ("Player %s has cards %c %c and %c %c\n", game->player_list[i]->Name, 
        get_rank(game->player_list[i]->Pocket->First->Card), get_suit(game->player_list[i]->Pocket->First->Card), 
        get_rank(game->player_list[i]->Pocket->First->Next->Card), get_suit(game->player_list[i]->Pocket->First->Next->Card));
    }
    /* //TESTING FOR START GAME
    printf("Player 1 Balance: %d\n", game->player_list[0]->Balance);
    printf("Player 2 Balance: %d\n", game->player_list[1]->Balance);
    printf("Player 3 Balance: %d\n", game->player_list[2]->Balance);
    printf("Player 4 Balance: %d\n", game->player_list[3]->Balance);
    printf("Small blind is: %d \n", game->small_blind);
    printf("Big blind is: %d \n", game->big_blind);
    printf("Community card length is: %d\n", game->community_cards->Length);
    printf("Player 1 Pocket length: %d\n", game->player_list[0]->Pocket->Length);
    printf("Player 2 Pocket length: %d\n", game->player_list[1]->Pocket->Length);
    printf("Player 3 Pocket length: %d\n", game->player_list[2]->Pocket->Length);
    printf("Player 4 Pocket length: %d\n", game->player_list[3]->Pocket->Length);
    
    
    printf("Current Player is %s \n", game->current_player->Name);
    printf("P3 action\n");
    next_player(game);
    printf("Current Player is %s \n", game->current_player->Name);
    printf("P4 action\n");
    next_player(game);
    printf("Current Player is %s \n", game->current_player->Name);
    printf("P1 action\n");
    next_player(game);
    printf("Current Player is %s \n", game->current_player->Name);
    */

   
   int bet;
    while (game->current_player != NULL) {
        if (game->current_player->Bot == 1) {
            printf("Player %s\n", game->current_player->Name);
            Bot_Turn(game, game->current_player);
            printf("This is where the bot will move\n");
        }
        else { //do player stuff
            printf("Does Player %s wanna Fold? (1 for yes)\n", game->current_player->Name);
            scanf("%d", &input);
            if (input == 1) {
                game->current_player->Folded = 1;
                input = 0;
            }
            else {
                printf("Input action for Player %s with Balance: %d\n", game->current_player->Name, game->current_player->Balance);
                scanf("%d", &bet);
                add_to_pot(game->current_player, game, bet);
                printf("Pot is now %d\n", game->pot);
                if (game->current_bet < bet) { //Raise
                    printf("New End Player\n");
                    game->current_bet = bet;
                    game->end_player = game->current_player;
                }
                if (firstCheck) {
                    game->end_player = game->current_player;
                    firstCheck = false;
                }
            }
        }
        
        next_player(game);
            
        //checks active players, if everyone else has folded, award pot to the player
        if (last_active_player(game)) {
            printf("last active player \n");
            award_pot(game->current_player, game);
            reset_game(game); //next player becomes NULL, program needs to call start game
        }
        //forces showdown if all other active players are all in / folded
        else if (game->current_player == game->end_player) {
            if (other_players_all_in(game)) {
                printf("all other players are all in \n");
                //distributes remaining cards to community
                distributeCards(game->deck, game->community_cards, game->deck->Length);
                update_hands(game);
                game->round = 5;
            }
            else {
                printf("next round \n");
                next_round(game); //next player becomes first active player after small blind of next round
                printf("First Player is: %s\n", game->current_player->Name);
                printf("Community card length is: %d\n", game->community_cards->Length);
                printf("Round is: %d \n", game->round);
                firstCheck = true;
            }
        }

        if (game->round == 5) {
            //update_hands(game);
            showdown(game);
            printf("Community Cards \n");\
            t_cardEntry *current_card_entry = game->community_cards->First;
            while (current_card_entry != NULL){
                printf ("%c %c \n", get_rank(current_card_entry->Card), get_suit(current_card_entry->Card));
                current_card_entry = current_card_entry->Next;
            }
            reset_game(game);
            emptyBot(game->player_list);
        }
    }

    
    
    printf("Player %s with Balance: %d\n", game->player_list[0]->Name, game->player_list[0]->Balance);
    printf("Player %s with Balance: %d\n", game->player_list[1]->Name, game->player_list[1]->Balance);
    printf("Player %s with Balance: %d\n", game->player_list[2]->Name, game->player_list[2]->Balance);
    //printf("Player %s with Balance: %d\n", game->player_list[3]->Name, game->player_list[3]->Balance);
   
    printf("Round is: %d \n", game->round);
    printf("Small blind is: %d \n", game->small_blind);
    printf("Big blind is: %d \n", game->big_blind);

    delete_player(game->player_list, player1);
    delete_player(game->player_list, player2);
    delete_player(game->player_list, player3);
    //delete_player(game->player_list, player4);

    }
    
    return 0;
}

char get_rank(t_pokerCard *card) {
    switch (card->rank) {
        case TWO:
            return '2';
        break; 
        case THREE:
            return '3';
        break;
        case FOUR:
            return '4';
        break;
        case FIVE:
            return '5';
        break;
        case SIX:
            return '6';
        break;
        case SEVEN:
            return '7';
        break;
        case EIGHT:
            return '8';
        break;
        case NINE:
            return '9';
        break;
        case TEN:
            return 'T';
        break;
        case JACK:
            return 'J';
        break;
        case QUEEN: 
            return 'Q';
        break;
        case KING:
            return 'K';
        break;
        case ACE:
            return 'A';
        break;
        default:
            return 'X';
            break;
    }
}

char get_suit(t_pokerCard *card) {
    switch (card->suit) {
        case SPADES:
            return 'S';
            break; 
        case HEARTS:
            return 'H';
            break;
        case DIAMONDS:
            return 'D';
            break;
        case CLUBS: 
            return 'C';
            break;
        default:
            return 'X';
            break;
    }
}