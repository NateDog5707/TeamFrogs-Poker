#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include <time.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <assert.h>

#include "parse.h"
#include "Poker_game.h"
#include "Player.h"
#include "Buffer.h"
#include "Poker_bot.h"

//#include "../client/global_variables.h"

// #define TESTING_WANT_TO_WRITE

/* #define DEBUG */	/* be verbose */

/*** global variables ****************************************************/

const char *Program	/* program name for descriptive diagnostics */
	= NULL;
int Shutdown		/* keep running until Shutdown == 1 */
	= 0;
int justStarted = 1;

int readyUp[4] = {1, 1, 1, 1};
int clientHasStarted[4] = {1, 1, 1, 1};
int ableToStart = 0;
/*** global functions ****************************************************/

void cardToWrite(char* SendBuf, int shuffledIndex);

void FatalError(		/* print error diagnostics and abort */
	const char *ErrorMsg)
{
    fputs(Program, stderr);
    fputs(": ", stderr);
    perror(ErrorMsg);
    fputs(Program, stderr);
    fputs(": Exiting!\n", stderr);
    exit(20);
} /* end of FatalError */

int MakeServerSocket(		/* create a socket on this server */
	uint16_t PortNo)
{
    int ServSocketFD;
    struct sockaddr_in ServSocketName;

    /* create the socket */
    ServSocketFD = socket(PF_INET, SOCK_STREAM, 0);
    if (ServSocketFD < 0)
    {   FatalError("service socket creation failed");
    }
    /* bind the socket to this server */
    ServSocketName.sin_family = AF_INET;
    ServSocketName.sin_port = htons(PortNo);
    ServSocketName.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(ServSocketFD, (struct sockaddr*)&ServSocketName,
		sizeof(ServSocketName)) < 0)
    {   FatalError("binding the server to a socket failed");
    }
    /* start listening to this socket */
    if (listen(ServSocketFD, 5) < 0)	/* max 5 clients in backlog */
    {   FatalError("listening on socket failed");
    }
    return ServSocketFD;
} /* end of MakeServerSocket */



//--------------------------------------------------------------


int ProcessRequest(		/* process a request by a client */
	int DataSocketFD, t_game* game)
{
		int goodInput = 0; //true initially, turns off if error- 
		int wantToWrite = 0;
    int  l, n;
    char RecvBuf[256];	/* message buffer for receiving a message */
    char SendBuf[256];	/* message buffer for sending a response */
    char tempBuf[32];
    int pendingUpdate = 0;

		parsed = mallocParsed(parsed);

    n = read(DataSocketFD, RecvBuf, sizeof(RecvBuf)-1);
    if (n < 0) 
    {   FatalError("reading from data socket failed");
    }
    RecvBuf[n] = 0;
#ifdef DEBUG
    printf("%s: Received message: %s\n", Program, RecvBuf);
#endif

		//parsed is defined in header parse.h
    
    parsed = parseString(RecvBuf, parsed);
    
#ifdef DEBUG

#endif
    int c = 0;
		//---------- DEBUG, PRINGING parsed IN SERVER SO WE MAY USE THE ARRAY
		printf("I AM SCREAMING, THIS IS FROM CLOCKSERVER\n");
		while (parsed[c] != NULL){
			printf("parsed[%d]: %s \n", c, parsed[c]);
			c++;
		}
		
		
		
		
		
		
		printf("Start comparing the parsed strings\n");
    //printf("\n");
    //Check for REQUEST and ACTION first -> specific actions
    
    int seatNumber;
	    
		if (0 == strcmp(parsed[0], "TEST"))
		{
			strcpy(SendBuf, "SUCCESS");
			wantToWrite = 1;
		}
		
		else if (0 == strcmp(parsed[0], "RESETGAME"))
		{
			reset_game(game);
			strcpy(SendBuf, "RESTARTEDGAME");
			justStarted = 1;
		}

    else if (0 == strcmp(parsed[0], "GIVE"))
    {
      //printf("MADE IT TO GIVE\n");
    	if (0 == strcmp(parsed[1], "CARD"))
    	{
        //printf("MADE IT TO CARD\n");
    		int shuffledIndex = atoi(parsed[2]);
        //printf("SHUFFLED INDEX BE: %d\n", shuffledIndex);
    		strcpy(SendBuf, "CARD "); //prepares the write message "CARD [Rank] [Suit]"
        SendBuf[sizeof(SendBuf)-1] = 0;
				//seperate function, supposed to return the card at index i of 1-13 of our "shuffled" array of cards
    		
        cardToWrite(SendBuf, shuffledIndex); //defined down below
        
        //Queue stuff
        
				
    	}//if end
   		goodInput = 1;
    }//GIVE end

    
    else if (0 == strcmp(parsed[0], "CURRPLAYER")) //FOR DEBUG
    {
			strncpy(SendBuf, "CURRENT PLAYER IS: ", sizeof(SendBuf)-1);
      strcat(SendBuf, game->current_player->Name);
			SendBuf[sizeof(SendBuf)-1] = 0;
			//appendMessageAll(SendBuf);
      goodInput = 1;
    } //CURRPLAYER end
    

    
    //--- temp function for easy testing
    else if (0 == strcmp(parsed[0], "SKIP")){
  	 
    	
    }
    

        
    //keyword update: Receives "UPDATE PLAYER_X" , X is seat #, pops out first message in queue to empty it
    else if(0 == strcmp(parsed[0], "UPDATE")) 
	{

		if(0 == strcmp(parsed[1], "PLAYER_1")) 
		{
			printf("update from player 1\n");

			if(queueOne->Length != 0)
			{
				n = write(DataSocketFD, popMessage(queueOne), 50);
				//temporary pops
				popMessage(queueTwo);
				popMessage(queueThree);
				popMessage(queueFour);
			}
			else
			{
				n = write(DataSocketFD, "NOUPDATE", 50);
			}

			return 1;
		}
	  	else if(0 == strcmp(parsed[1], "PLAYER_2")) 
		{
      		printf("update from player 2\n");

			if(queueOne->Length != 0)
			{
				n = write(DataSocketFD, popMessage(queueTwo), 50); 
			}
			else
			{
				n = write(DataSocketFD, "NOUPDATE", 50);
			}

			return 1;
      	}
      	else if(0 == strcmp(parsed[1], "PLAYER_3")) 
		{
			printf("update from player 3\n");

	      	if(queueOne->Length != 0)
			{
				n = write(DataSocketFD, popMessage(queueThree), 50); 
			}
			else
			{
				n = write(DataSocketFD, "NOUPDATE", 50);
			}

	      	return 1;
      	}
		else if(0 == strcmp(parsed[1], "PLAYER_4")) 
		{
      		printf("update from player 4\n");

			if(queueOne->Length != 0)
			{
				n = write(DataSocketFD, popMessage(queueFour), 50); 
			}
			else
			{
				n = write(DataSocketFD, "NOUPDATE", 50);
			}

			return 1;
      	}

		goodInput = 1;
		wantToWrite = 1;
    }
    
    //pregame actions --------------------------------------------------
    else if(game->round == 0) {
      if (0 == strcmp(parsed[0], "REQUEST")) { 
        if (0 == strcmp(parsed[1], "SEAT")) { 
          /*if(0 == strcmp(parsed[2], "SEAT_NUM") {
          
          	if(0 == strcmp(parsed[3], "USERNAME") {

            }
          }  */

          seatNumber = atoi(parsed[2]);
          t_player *tempPlayer = createPlayer(parsed[3], 1000, seatNumber);
          //tempPlayer->Bot = 0;      
          
          //printf("PLAYER BOT: %d\n", tempPlayer->Bot);
          if ( 0 == append_player(game->player_list, tempPlayer)){
          //printf("HELP\n");

						strncpy(SendBuf, "SEAT ", sizeof(SendBuf)-1);
  
	          switch (tempPlayer->Seat){
	          	case 1:
	     					strcpy(tempBuf, "1 ");
	     					readyUp[0] = 0;
	     					//appendMessage(queueOne, "SEAT GRANTED");
	     					n = write(DataSocketFD, "SEAT GRANTED", 50); 
	     					return 1;
	     					break;
	 						case 2:
	     					strcpy(tempBuf, "2 ");
	     					readyUp[1] = 0;
	     					//appendMessage(queueTwo, "SEAT GRANTED");
	     					n = write(DataSocketFD, "SEAT GRANTED", 50); 
	     					return 1;
	     					break; 	
							case 3:
	     					strcpy(tempBuf, "3 ");
	     					readyUp[2] = 0;
	     					//appendMessage(queueThree, "SEAT GRANTED");
	     					n = write(DataSocketFD, "SEAT GRANTED", 50); 
	     					return 1;
	     					break; 	
							case 4:
	     					strcpy(tempBuf, "4 ");
	     					readyUp[3] = 0;
	     					//appendMessage(queueFour, "SEAT GRANTED");
	     					n = write(DataSocketFD, "SEAT GRANTED", 50); 
	     					return 1;
	     					break; 						
	          }//switch end
     		
	          strcat(SendBuf, tempBuf);
	          strcat(SendBuf, tempPlayer->Name);
						
						//--------------------------        everything above this is being overwritten here
						//strcpy(SendBuf, "SEAT GRANTED");

						//--------------------------
	      	  SendBuf[sizeof(SendBuf)-1] = 0;
	         	//printf("inside REQUEST SEAT X {USERNAME}\n\tSendBuf = '%s'\n", SendBuf);
	             
	          printf("\nUSERNAME: %s\n", parsed[3]);
					} //if appendplayer == 0 end					
					
					else { //append player did not work, either seat was filled or out of bounds
						//print an error to the client?
						goodInput = 1;
					}
          
        } 
				else{
					goodInput = 1;
				} 
      } //if "REQUEST" end
      
    else if (0 == strcmp(parsed[0], "STARTGAME")){
      	//if everyone ready up
      	for (int i = 0; i < 4; i++){
      		if(readyUp[i] != 1){
      			//cannot readyup
      			ableToStart = 1;
      		}
      	}
      	if (ableToStart == 0)
      	{
      		
					// strcpy(SendBuf, "STARTEDGAME");
					printf("STARTING THE GAME!\n");
					appendMessageAll("STARTEDGAME");
      				start_game(game); //does checkEmpty, to add bots in empty seats
      				for (int m = 1; m < 14; m++){
      					strcpy(SendBuf, "CARD ");
      					cardToWrite(SendBuf, m);
      					appendMessageAll(SendBuf);
      				}
      				appendMessageAll("COMMUNITY PREFLOP");
      				appendMessageAll("DEAL");
					for (int m = 0; m < 4; m++)
					{
						strcpy(SendBuf, "REQUEST SEAT ");
						strcat(SendBuf, game->player_list[m]->Name);
						
						char temp_str[50];
						sprintf(temp_str, " %d", m + 1);

						strcat(SendBuf, temp_str);
						appendMessageAll(SendBuf);
					}
					wantToWrite = 1;
					
      		//appendMessageAll("STARTEDGAME");
      		justStarted = 1;
	     		//goodInput = 1;
   			}// if ableToStart end
   			else{
   				ableToStart = 0; //reset the flag
   				goodInput = 1;
   			}
   			
      }//if "STARTGAME" end
      
      else if (0 == strcmp(parsed[0], "READYUP")){
      	if (0 == strcmp(parsed[1], "1")){
      		readyUp[0] = 1;
      		printf("Seat 1 readied up!\n");
      	}
      	else if (0 == strcmp(parsed[1], "2")){
      		readyUp[1] = 1;
      		printf("Seat 2 readied up!\n");
      	}
      	else if (0 == strcmp(parsed[1], "3")){
      		readyUp[2] = 1;
      		printf("Seat 3 readied up!\n");
      	}
      	else if (0 == strcmp(parsed[1], "4")){
      		readyUp[3] = 1;
      		printf("Seat 4 readied up!\n");
      	}	
     		strcpy(SendBuf, "READYUP CONFIRMED");
      	goodInput = 1;
      	//wantToWrite = 1;
      }
      
		} //if ROUND is 0 end
        
    //---------within rounds 1-4-------------------------------------------------
    //---------------------------------------------------------------------------
    else if(game->round > 0 && game->round < 5)
	 	{ 
    	printf("MADE IT IN WITHIN ROUNDS 1-4\n");
    
//DEBUG
/*
		int c =0;
    while (parsed[c] != NULL){
			printf("parsed[%d]: %s \n", c, parsed[c]);
			c++;
		}
*/

			printf("game->current_player->Seat : %d\n", game->current_player->Seat);
        
        
      if (0 == strcmp(parsed[0], "ACTION")) {
      
        //printf("parsed[2]: %s\n", parsed[2]);
        char *tempPlayerSeat = parsed[2]; //tempPlayerSeat[7] takes the last char (seat number)
        //printf("tempPlayerSeat : %c\n", tempPlayerSeat[sizeof(tempPlayerSeat)-1]);
        //printf("tempPlayerSeat[sizeof(tempPlayerSeat)-1] - '0': %d\n", (tempPlayerSeat[sizeof(tempPlayerSeat)-1]));
        switch (tempPlayerSeat[sizeof(tempPlayerSeat)-1] ) {
          case '1' : 
            seatNumber = 1;
            break;
          case '2' : 
            seatNumber = 2;
            break;
          case '3' : 
            seatNumber = 3;
            break;
          case '4' : 
            seatNumber = 4;
            break;
        }
        int seat = game->current_player->Seat;
        char *seatNum;
        switch(seat)
          {
              case 1:
                  seatNum = "PLAYER_1";
                  break;
              case 2:
                  seatNum = "PLAYER_2";
                  break;
              case 3:
                  seatNum = "PLAYER_3";
                  break;
              case 4:
                  seatNum = "PLAYER_4";
                  break;
          }
        printf("seatNumber : %d\n", seat);
        //printf("game->current_player->Seat : %d\n", game->current_player->Seat);
        if(seatNumber == game->current_player->Seat) { //comparing seat number from client to current_player->seat
        	printf("seatnumber == current_player->seat , checking 2nd parameter\n");
        	
			if (0 == strcmp(parsed[1], "FOLD")) { 
            firstMove++;
            //printf("FLAG VALUE: %d\n", firstMove);
            game->current_player->Folded = 1;
            
				strncpy(SendBuf, "ACTION FOLD ", sizeof(SendBuf)-1);
				strcat(SendBuf, seatNum);
				SendBuf[sizeof(SendBuf)-1] = 0;
				
								appendMessageAll("NOUPDATE"); 
								
				#ifdef TESTING_WANT_TO_WRITE
					wantToWrite = 0;
					n = write(DataSocketFD, SendBuf, l);
				#endif
        	
			}//if FOLD end
        	else if (0 == strcmp(parsed[1], "CALL"))
			{ 
				if(firstMove == 0) {
                //printf("MADE IT INTO FLAG\n");
	              game->end_player = game->current_player;
	            }
				firstMove++;
				
				add_to_pot(game->current_player, game, game->current_bet);
	            strncpy(SendBuf, "ACTION CALL ", sizeof(SendBuf)-1);
              	strcat(SendBuf, seatNum);
            	SendBuf[sizeof(SendBuf)-1] = 0;
				
				appendMessageAll("NOUPDATE"); 
				#ifdef TESTING_WANT_TO_WRITE
					wantToWrite = 0;
					n = write(DataSocketFD, SendBuf, l);
				#endif
              
   		} //if CALL end
          	else if (0 == strcmp(parsed[1], "RAISE")) 
			{
            //if(atoi(parsed[3] == x) maybe keep to check if what's inputted is actually an integer
            int raise = atoi(parsed[3]);
            if(raise > 0 && game->current_player->Balance - raise > 0) { //need to get playerBal to determine if valid
              firstMove++;
              
              				appendMessageAll("NOUPDATE"); 
              				
              add_to_pot(game->current_player, game, raise);
              
              
              char tempRaise[32];
              //UPDATE INDIVIDUAL POTS
              strncpy(tempRaise, "UPDATE POT ", sizeof(tempRaise)-1);
              strcat(tempRaise, seatNum);
              strcat(tempRaise, " ");
              strcat(tempRaise, parsed[3]);
              printf("tempRaise ind pot: %s\n", tempRaise);
              appendMessageAll(tempRaise);
              
              //UPDATE MAIN POT
              strncpy(tempRaise, "UPDATE POT MAIN ", sizeof(tempRaise)-1);
              strcat(tempRaise, parsed[3]);
              printf("tempRaise main pot: %s\n", tempRaise);
              appendMessageAll(tempRaise);
              
              game->end_player = game->current_player;
              
              char itos[100];
              sprintf(itos, "%d", game->current_player->Seat);   
              
	            strncpy(SendBuf, "ACTION RAISE ", sizeof(SendBuf)-1);
              strcat(SendBuf, seatNum);
              strcat(SendBuf, " ");
              strcat(SendBuf, parsed[3]);
          	  SendBuf[sizeof(SendBuf)-1] = 0;
            }
						else {
							printf("player is raising $0, do nothing!\n");
							wantToWrite = 1;
							return 1;
						}         
          } //if RAISE end    
          else if (0 == strcmp(parsed[1], "CHECK")) { 
          	//if (game->current_bet != 0){ //if no one has made a bet yet, check is legal //------------Nathan 6/4/2023 THIS IS COMMENTED OUT FOR NOW FOR EASY TESTING PURPOSES
	            //printf("FLAG VALUE: %d\n", firstMove);
              if(firstMove == 0) {
                //printf("MADE IT INTO FLAG\n");
	              game->end_player = game->current_player;
	            }
             
              char itos[100];
              sprintf(itos, "%d", game->current_player->Seat);   
             	
	            firstMove++;
	            strncpy(SendBuf, "ACTION CHECK ", sizeof(SendBuf)-1);
              strcat(SendBuf, seatNum);
	         	  SendBuf[sizeof(SendBuf)-1] = 0;
	         	  appendMessageAll("NOUPDATE"); 
	         	  
           } //if CHECK end
           
           else{ //check isnt legal when a bet has occurred
           	goodInput = 1;
           }
           
        } //if current_player's turn end
       	
				 else //input from not current_player
				{ 
					printf("EE ACTION FROM INCORRECT PLAYER\n");
    			goodInput = 1; 
    		 	strncpy(SendBuf, "ACTION FROM INCORRECT PLAYER", sizeof(SendBuf)-1); //DEBUG
 					SendBuf[sizeof(SendBuf)-1] = 0;
    		}
      } //if inside ACTION end
      else{
			 goodInput = 1;
			 wantToWrite = 1;
		  }
    } //ROUND is 1-4 else if end
   
    else if (0 == strcmp(parsed[0], "SHUTDOWN"))
    {   Shutdown = 1;
				strncpy(SendBuf, "OK SHUTDOWN", sizeof(SendBuf)-1);
				SendBuf[sizeof(SendBuf)-1] = 0;
    } //SHUTDOWN end
    
    else
    {   strncpy(SendBuf, "ERROR unknown command ", sizeof(SendBuf)-1);
				SendBuf[sizeof(SendBuf)-1] = 0;
				strncat(SendBuf, RecvBuf, sizeof(SendBuf)-1-strlen(SendBuf));
				goodInput = 1;
    } //UNKNOWN COMMAND end
    


  //CHECK IF GOOD INPUT
    if(wantToWrite == 0) { //if the protocol is a good input, append message to all queues
    	printf("Hey, we want to write!\n");
      appendMessageAll(SendBuf);
      if (game->round >0){
      	strcpy(SendBuf, "");
      }
    }
    else{
    	wantToWrite = 0;
    }
    

    
////// sending message back to client------------------------------
//----------------------------------------------------------------


  

//debug
printf("hey we starting send back thing\n");


      
    l = strlen(SendBuf);
#ifdef DEBUG
    printf("%s: Sending response: %s.\n", Program, SendBuf);
#endif


//	char thisIsTemp[100];
	
	
		if (game->round > 0) //use buffers only if we are in game and have 4 different client
		{
			if (clientHasStarted[0] == 1 || clientHasStarted[1] == 1 || clientHasStarted[2] == 1 || clientHasStarted[3] == 1){
				if(clientHasStarted[0] == 1){
				  if(game->player_list[0]->Bot == 0 && 0 == strcmp(parsed[0], "UPDATE") && 0 == strcmp(parsed[1], "PLAYER_1") ){
						n = write(DataSocketFD, popMessage(queueOne), l);
					}
					clientHasStarted[0] = 0;
				}
				else if(clientHasStarted[1] == 1){
				  if(game->player_list[1]->Bot == 0 && 0 == strcmp(parsed[0], "UPDATE") && 0 == strcmp(parsed[1], "PLAYER_2")){
						n = write(DataSocketFD, popMessage(queueTwo), l);
					}
					clientHasStarted[1] = 0;
				}
				else if(clientHasStarted[2] == 1){
				  if(game->player_list[2]->Bot == 0 && 0 == strcmp(parsed[0], "UPDATE") && 0 == strcmp(parsed[1], "PLAYER_3")){
						n = write(DataSocketFD, popMessage(queueThree), l);
					}
					clientHasStarted[2] = 0;
				}
				else if(clientHasStarted[3] == 1){
				  if(game->player_list[3]->Bot == 0 && 0 == strcmp(parsed[0], "UPDATE") && 0 == strcmp(parsed[1], "PLAYER_4")){
						n = write(DataSocketFD, popMessage(queueFour), l);
					}
					clientHasStarted[3] = 0;
				}
			
			} 
			
		
			//pop message from the queue of whoever called sent the request in (MUST'VE BEEN CURRENT PLAYER if they are acting their turn, or MUST BE A GUI UPDATE CALL)
	    // *****for testing purposes, also pop the message from the other queues, but dont write
	    if(1 == game->current_player->Seat || pendingUpdate == 1) { //check if current player is player 1
	printf("Going to popMessage queue ONE\n");
	
	      n = write(DataSocketFD, popMessage(queueOne), l); //write to queue 1
				popMessage(queueTwo);
				popMessage(queueThree);
				popMessage(queueFour);
				//clientHasStarted[0] = 0; //needs to get the STARTEDGAME thing after start_game moves round->1
	    }
	    else if(2 == game->current_player->Seat || pendingUpdate == 2) { //check if current player is player 2
	printf("Going to popMessage queue TWO\n");
	      n = write(DataSocketFD, popMessage(queueTwo), l); //write to queue 2
				popMessage(queueOne);
				popMessage(queueThree);
				popMessage(queueFour);
				
	    }
	    else if(3 == game->current_player->Seat || pendingUpdate == 3) { //check if current player is player 3
	printf("Going to popMessage queue THREE\n");
	      n = write(DataSocketFD, popMessage(queueThree), l); //write to queue 3
				popMessage(queueOne);
				popMessage(queueTwo);
				popMessage(queueFour);
	    }
	    else if(4 == game->current_player->Seat || pendingUpdate == 4) { //check if current player is player 4     
	printf("Going to popMEssage queue FOUR\n");
				n = write(DataSocketFD, popMessage(queueFour), l); //write to queue 4
				popMessage(queueOne);
				popMessage(queueTwo);
				popMessage(queueThree);
				//clientHasStarted[0] = 0;
	    }
	    
	    pendingUpdate = 0; //reset flag
 	  }
	  
	else if (game->round == 0) //in pregame, we dont need buffers, so write normally back
	{
    	n = write(DataSocketFD, SendBuf, l);
    	
		popMessage(queueOne);
    	popMessage(queueTwo);
  		popMessage(queueThree);
  		popMessage(queueFour);
	}

    
    if (n < 0)
    {   
		FatalError("writing to data socket failed");
    }
 
//DEBUG   
/*
    printf("round_count: %d\n", game->round);
		printf("small blind : %d\n", game->small_blind);
		printf("big blind : %d\n",  game->big_blind);
		if (game->round > 0){
			printf("current player : %s\n", game->current_player->Name);
    	printf("Folded: %d\n", game->current_player->Folded);
    }
*/
    //reset sendBuf
    //strcpy(SendBuf, "");

    return goodInput; //if user input made a valid command, we can accept the request
} /* end of ProcessRequest */


//-----------------------------------------------------------------
//
//-----------------------------------------------------------------

void ServerMainLoop(		/* simple server main loop */
	int ServSocketFD,		/* server socket to wait on */
	int Timeout)			/* timeout in micro seconds */
{
    int DataSocketFD;	/* socket for a new client */
    socklen_t ClientLen;
    struct sockaddr_in
	ClientAddress;	/* client address we connect with */
    fd_set ActiveFDs;	/* socket file descriptors to select from */
    fd_set ReadFDs;	/* socket file descriptors ready to read from */
    struct timeval TimeVal;
    int res, i;
//    int winner_seat;
    int didShowdownHappen = 0;

    FD_ZERO(&ActiveFDs);		/* set of active sockets */
    FD_SET(ServSocketFD, &ActiveFDs);	/* server socket is active */
    
    //setup 4 buffers, global vars in Buffer.c
    queueOne = createMessageList();
    queueTwo = createMessageList();
    queueThree = createMessageList();
    queueFour = createMessageList();
    
    
    
    //poker game initialization stuff
    t_game* game = init_game();
		
		
    /*
    //temp players
    game->player_list[0] = createPlayer("PLAYER_1", 1000, 1);
    game->player_list[1] = createPlayer("PLAYER_2", 1000, 2);
    game->player_list[2] = createPlayer("PLAYER_3", 1000, 3);
    game->player_list[3] = createPlayer("PLAYER_4", 1000, 4);
    */
//debug
//    printf("idle state\n");
//    printf("round_count: %d\n", game->round);
    //temp start game
//    start_game(game);
    
    while(!Shutdown)
    {   
			//debug
      /*
			printf("round_count: %d\n", game->round);
			printf("small blind : %d\n", game->small_blind);
			printf("big blind : %d\n",  game->big_blind);
			printf("current player : %s\n", game->current_player->Name);
			//assert(game->end_player->Name);
      */
			//printf("end player : %s\n", game->end_player->Name);
			
			
			//if a round is pregame or betting round, we look for user input
			if (game->round >= 0 && game->round <= 4)
			{

				//BOT STUFF
 				if (game->round >= 1 && game->round <= 4){ //only here can we call bot stuff
 					if (game->current_player->Bot == 1){
					 //BOT STUFF()
						Bot_Turn(game, game->current_player); ///<--- bot turn
						printf("bot made its action\n");

						//append message?
						next_player(game);
						continue;
 					}// bot is true END
 								printf("current player is now: %s\n", game->current_player->Name);
  								if (game->end_player != NULL){
							  		printf("end player is : %s\n", game->end_player->Name);
 									}	
				
				
 				}

		
				
				
				ReadFDs = ActiveFDs;
				TimeVal.tv_sec  = Timeout / 1000000;	/* seconds */
				TimeVal.tv_usec = Timeout % 1000000;	/* microseconds */
				/* block until input arrives on active sockets or until timeout */
				res = select(FD_SETSIZE, &ReadFDs, NULL, NULL, &TimeVal);
				if (res < 0)
				{   
					FatalError("wait for input or timeout (select) failed");
				}
				if (res == 0)	/* timeout occurred */
				{
					
				}
				
				else		/* some FDs have data ready to read */
				{   for(i=0; i<FD_SETSIZE; i++)
	   		 {   if (FD_ISSET(i, &ReadFDs))
					{   if (i == ServSocketFD)
		   			 {	/* connection request on server socket */
#ifdef DEBUG
			printf("%s: Accepting new client %d...\n", Program, i);
#endif
									ClientLen = sizeof(ClientAddress);
									DataSocketFD = accept(ServSocketFD,
									(struct sockaddr*)&ClientAddress, &ClientLen);
							if (DataSocketFD < 0) 
							{   FatalError("data socket creation (accept) failed");
							}
#ifdef DEBUG
			printf("%s: Client %d connected from %s:%hu.\n",
				Program, i,
				inet_ntoa(ClientAddress.sin_addr),
				ntohs(ClientAddress.sin_port));
#endif
								FD_SET(DataSocketFD, &ActiveFDs);
   						}

   						//PROCESS THAT REQUEST BB
		    			else
		    			{   /* active communication with a client */
#ifdef DEBUG
			printf("%s: Dealing with client %d...\n", Program, i);
#endif

					
//DEBUG
printf("gonna call process request inside main \n");
  							if (ProcessRequest(i, game) == 0 && game->round > 0) ///THE GOOD STUFF
  							{
  								if (justStarted == 0){
  									printf("hey next player\n");
  									next_player(game); //should change game->current_player to next in the player_list array
  								}
  								else{
  									justStarted = 0;
									}
									
  								printf("current player is now: %s\n", game->current_player->Name);
  								if (game->end_player != NULL){
							  		printf("end player is : %s\n", game->end_player->Name);
 									}
 									
 									
  								//after moving to the next player,
  								//check if everyone else has folded (the immediate previous player should have entered FOLDED for this to ever be true)
  								if (last_active_player(game)){
  									game->round = 6; //end game. award pot to last remaining player
  									//winner_seat = game->current_player->Seat; //this MIGHT not work :) -nathan	
  								}
									//else if (game->current_player == game->end_player) {
   								else if (other_players_all_in(game)) {
											game->round = 5;
	  										didShowdownHappen = 1;
	  										distributeCards(game->deck, game->community_cards, 5-game->community_cards->Length);
											update_hands(game);
										}
									else if (game->current_player == game->end_player){
											next_round(game);
							    		firstMove = 0;
											printf("HEY, NEXT ROUND!\n");
										}
									//}
								
								
  							}//processrequest if end
  							else{ //cannot move on to next player b/c goodInput ==1
  								printf("Cannot move on to the next player, good Input == 1 or game round = 0\n");
  								if (game->round > 0){
 										if (game->current_player == game->end_player){
											next_round(game);
											printf("HEY, NEXT ROUND!\n");
										}
									}
  							}// else
#ifdef DEBUG
			printf("%s: Closing client %d connection.\n", Program, i);
#endif
							close(i);
							FD_CLR(i, &ActiveFDs);
		   		 		}
						}
	   		 	}			
	   		 	
				}// ELSE END - FD's ready to read
				

			} //IF END "round_count >=0 && <=4" --- betting round section end
			
			if( game->round == 5 ){ //------showdown
				
				//showdown - calls compareHands, appoints a winner
			
				//DEBUG
				printf("hey it's showdown\n");
				showdown(game);
				didShowdownHappen = 1;
				
				award_pot_during_showdown(game);
				game->round = 6;

			} //---else if RC == 5 END
			
			if ( game->round == 6){ //---end game, award pot and reset
			
				if (didShowdownHappen == 0){ //showdown didn't happen, award pot to current_player based on different criteria
					award_pot(game->current_player, game);
				}
				else{
					
				}
				
				reset_game(game); //sets round -> 0
				
				clientHasStarted[0] = 1;
				clientHasStarted[1] = 1;
				clientHasStarted[2] = 1;
				clientHasStarted[3] = 1;
				
				appendMessageAll("COMMUNITY PREFLOP");				
				//appendMessageAll("RESTARTEDGAME");
				char yesTemp[25];
				for (int m = 1; m < 14; m++){
								strcpy(yesTemp, "CARD ");
      					cardToWrite(yesTemp, m);
      					appendMessageAll(yesTemp);
      				}
				//appendMessageAll("COMMUNITY PREFLOP");
				appendMessageAll("DEAL"); 
				justStarted = 1;
			}//--- else if RC == 6  end
		
		
		
			
    }// WHILE END
    
    
    
} /* end of ServerMainLoop */



void cardToWrite(char* SendBuf, int shuffledIndex){
	printf("ayo we in cardToWrite\n");
	//use switch case to determine what card needs to show up
	//"CARD [RANK] [SUIT]"
	//rn it's "CARD "
	int pain_count = 1;
printf("shuffled length = %d\n", shuffled->Length);
	assert(shuffled);
printf("A\n");
	t_cardEntry *curr = shuffled->First;
	assert(curr);
printf("B\n");
	while (pain_count < shuffledIndex){
		assert(curr->Next);
		curr = curr->Next;
		pain_count++;
	}
printf("C\n");
	switch (curr->Card->rank){
		case 2:
			strcat(SendBuf, "TWO ");
			break;
		case 3:
			strcat(SendBuf, "THREE ");
			break;
		case 4:
			strcat(SendBuf, "FOUR ");
			break;
		case 5:
			strcat(SendBuf, "FIVE ");
			break;
		case 6:
			strcat(SendBuf, "SIX ");
			break;
		case 7:
			strcat(SendBuf, "SEVEN ");
			break;
		case 8:
			strcat(SendBuf, "EIGHT ");
			break;
		case 9:
			strcat(SendBuf, "NINE ");
			break;
		case 10:
			strcat(SendBuf, "TEN ");
			break;
		case 11:
			strcat(SendBuf, "JACK ");
			break;
		case 12:
			strcat(SendBuf, "QUEEN ");
			break;
		case 13:
			strcat(SendBuf, "KING ");
			break;
		case 14:
			strcat(SendBuf, "ACE ");
			break;
	}//switch rank end
	
	switch(curr->Card->suit){
		case 1:
			strcat(SendBuf, "SPADES");
			break;
		case 2:
			strcat(SendBuf, "DIAMONDS");
			break;
		case 3:
			strcat(SendBuf, "HEARTS");
			break;
		case 4:
			strcat(SendBuf, "CLUBS");
			break;
	}//switch suit end
	
}





/*** main function *******************************************************/

int main(int argc, char *argv[])
{

    
    int ServSocketFD;	/* socket file descriptor for service */
    int PortNo;		/* port number */

    Program = argv[0];	/* publish program name (for diagnostics) */
#ifdef DEBUG
    printf("%s: Starting...\n", Program);
#endif
    if (argc < 2)
    {   fprintf(stderr, "Usage: %s port\n", Program);
	exit(10);
    }
    PortNo = atoi(argv[1]);	/* get the port number */
    if (PortNo <= 2000)
    {   fprintf(stderr, "%s: invalid port number %d, should be >2000\n",
		Program, PortNo);
        exit(10);
    }
#ifdef DEBUG
    printf("%s: Creating the server socket...\n", Program);
#endif
    ServSocketFD = MakeServerSocket(PortNo);
    printf("%s: Client connected to port %d...\n", Program, PortNo);
    ServerMainLoop(ServSocketFD, 250000);
    printf("\n%s: Shutting down.\n", Program);
    close(ServSocketFD);
    
    deleteMessageList(queueOne);
    deleteMessageList(queueTwo);
    deleteMessageList(queueThree);
    deleteMessageList(queueFour);

    return 0;
}

