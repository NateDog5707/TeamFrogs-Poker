#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include <time.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <assert.h>

#include "server/parse.h"
#include "Poker_game.h"
#include "Player.h"
#include "Buffer.h"
#include "Poker_bot.h"

int main(int argc, char *argv[])
{
    queueOne = createMessageList();
    queueTwo = createMessageList();
    queueThree = createMessageList();
    queueFour = createMessageList();

    appendMessageAll("TEST");
    appendMessageAll("");
    print_messages_in_queue(queueOne);
    // popMessage(queueOne);
    // popMessage(queueTwo);
    // popMessage(queueThree);
    // popMessage(queueFour);

    return 0;
}