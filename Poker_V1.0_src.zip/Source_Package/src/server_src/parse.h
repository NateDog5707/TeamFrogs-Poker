#include <stdio.h>
#include <string.h>


#ifndef PARSE_H
    #define PARSE_H


    //GLOBAL VARS
    extern char** parsed;   //array of parsed strings, can be changed to hold more or less words.


    //parses a string(buffer) w/ delimineters as space ONLY. returns the list of parsed strings in 2nd parameter (which is a global var)
    char** parseString(char* buffer, char** parsed);

		char** mallocParsed(char** parsed);
		void freeParsed(char** parsed);

#endif